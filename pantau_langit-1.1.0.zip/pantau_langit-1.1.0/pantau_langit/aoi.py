"""Widget Area of Interest (AOI) + utilitas klip geospasial."""

import os
import tempfile

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QFileDialog,
    QGridLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

AOI_FILE_FILTER = (
    "Polygon (*.shp *.geojson *.json *.gpkg *.kml);;Semua file (*.*)"
)


class AoiSelector(QWidget):
    """Pemilih AOI: layer poligon QGIS atau muat dari file, dengan opsi klip."""

    changed = pyqtSignal()

    def __init__(self, title="Area of Interest (AOI)", clip_text=None,
                 clip_default=True, parent=None):
        super().__init__(parent)
        self._file_layers = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        grid = QGridLayout()
        from qgis.core import QgsMapLayerProxyModel
        from qgis.gui import QgsMapLayerComboBox

        self.combo = QgsMapLayerComboBox()
        self.combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.combo.setAllowEmptyLayer(True, "(tanpa AOI)")
        grid.addWidget(QLabel("Layer poligon"), 0, 0)
        grid.addWidget(self.combo, 0, 1)

        self.btn_load = QPushButton("Muat AOI dari File...")
        self.btn_load.clicked.connect(self.load_from_file)
        grid.addWidget(self.btn_load, 0, 2)

        self.bbox_label = QLabel("Bbox (W,S,E,N): -")
        self.bbox_label.setWordWrap(True)
        self.bbox_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        grid.addWidget(self.bbox_label, 1, 0, 1, 3)
        layout.addLayout(grid)

        if clip_text:
            self.clip_check = QCheckBox(clip_text)
            self.clip_check.setChecked(clip_default)
            self.clip_check.toggled.connect(self.changed)
            layout.addWidget(self.clip_check)
        else:
            self.clip_check = None

        self.combo.layerChanged.connect(self._update_preview)
        self._update_preview()

    # ------------------------------------------------------------------ API
    def current_layer(self):
        return self.combo.currentLayer()

    def clip_enabled(self):
        return bool(self.clip_check and self.clip_check.isChecked())

    def bbox(self):
        """Bbox AOI dalam EPSG:4326 [W, S, E, N]; None bila tidak ada AOI."""
        from qgis.core import (
            QgsCoordinateReferenceSystem,
            QgsCoordinateTransform,
            QgsProject,
        )

        layer = self.current_layer()
        if layer is None:
            return None
        if layer.selectedFeatureCount() > 0:
            extent = layer.boundingBoxOfSelected()
        else:
            extent = layer.extent()
        if extent is None or extent.isEmpty():
            return None
        if layer.crs().isValid() and layer.crs().authid().upper() != "EPSG:4326":
            xform = QgsCoordinateTransform(
                layer.crs(),
                QgsCoordinateReferenceSystem("EPSG:4326"),
                QgsProject.instance(),
            )
            extent = xform.transformBoundingBox(extent)
        return [extent.xMinimum(), extent.yMinimum(),
                extent.xMaximum(), extent.yMaximum()]

    def geometries(self):
        """List QgsGeometry poligon AOI (seleksi bila ada)."""
        layer = self.current_layer()
        if layer is None:
            return []
        feats = layer.getSelectedFeatures() if layer.selectedFeatureCount() > 0 \
            else layer.getFeatures()
        geoms = []
        for f in feats:
            g = f.geometry()
            if g is not None and not g.isEmpty():
                geoms.append(g)
        return geoms

    def load_from_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Muat AOI (poligon)", "", AOI_FILE_FILTER)
        if not path:
            return
        from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
        from qgis.PyQt.QtWidgets import QMessageBox

        name = os.path.splitext(os.path.basename(path))[0]
        layer = QgsVectorLayer(path, f"AOI | {name}", "ogr")
        if not layer.isValid():
            QMessageBox.warning(self, "AOI", f"Gagal membuka file:\n{path}")
            return
        if QgsWkbTypes.geometryType(layer.wkbType()) != QgsWkbTypes.PolygonGeometry:
            QMessageBox.warning(self, "AOI", "File AOI harus berupa layer poligon.")
            return
        QgsProject.instance().addMapLayer(layer)
        self._file_layers.append(layer)
        self.combo.setLayer(layer)
        self.changed.emit()

    # ---------------------------------------------------------------- private
    def _update_preview(self, *args):
        bbox = self.bbox()
        if bbox:
            self.bbox_label.setText(
                "Bbox (W,S,E,N): " + ", ".join(f"{v:.3f}" for v in bbox))
        else:
            self.bbox_label.setText("Bbox (W,S,E,N): - (pilih/muat layer poligon)")
        self.changed.emit()


# ---------------------------------------------------------------------------
# Utilitas klip
# ---------------------------------------------------------------------------
def _repair_cutline_geometries(path):
    """Perbaiki geometri tidak valid pada file cutline sementara.

    gdal.Warp menolak cutline bila ada ring self-intersection; geometri
    diperbaiki dengan MakeValid() (fallback Buffer(0)) di file sementara
    ini saja — data asli pengguna tidak diubah.
    """
    try:
        from osgeo import gdal, ogr
    except Exception:
        return 0
    fixed = 0
    gdal.PushErrorHandler("CPLQuietErrorHandler")
    try:
        ds = ogr.Open(path, 1)   # mode update
        if ds is None:
            return 0
        try:
            for i in range(ds.GetLayerCount()):
                lyr = ds.GetLayer(i)
                for feat in lyr:
                    geom = feat.GetGeometryRef()
                    if geom is None or geom.IsValid():
                        continue
                    new = None
                    try:
                        new = geom.MakeValid()
                    except Exception:
                        new = None
                    if new is None or new.IsEmpty():
                        try:
                            new = geom.Buffer(0)
                        except Exception:
                            new = None
                    if new is not None and not new.IsEmpty():
                        feat.SetGeometry(new)
                        lyr.SetFeature(feat)
                        fixed += 1
        finally:
            ds = None
    except Exception:
        return fixed
    finally:
        gdal.PopErrorHandler()
    return fixed


def export_cutline(layer, workdir=None):
    """Simpan geometri layer ke GPKG sementara untuk gdal cutline.

    Geometri tidak valid (mis. ring self-intersection) diperbaiki otomatis
    agar klip raster tidak gagal. return (path, layer_name) atau None.
    """
    from qgis.core import QgsVectorFileWriter, QgsProject

    if layer is None:
        return None
    workdir = workdir or tempfile.gettempdir()
    path = os.path.join(workdir, f"aoi_cutline_{id(layer) & 0xffff:04x}.gpkg")
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = "aoi"
    err = QgsVectorFileWriter.writeAsVectorFormat(
        layer, path, options)
    code = err[0] if isinstance(err, tuple) else err
    if code != QgsVectorFileWriter.NoError:
        return None
    _repair_cutline_geometries(path)
    return path, "aoi"


def filter_points_in_aoi(csv_path, aoi_geoms, out_path):
    """Filter CSV titik (kolom latitude/longitude) agar hanya di dalam AOI.

    return jumlah baris yang lolos.
    """
    import csv

    if not aoi_geoms:
        return None

    from qgis.core import QgsGeometry, QgsPointXY

    xs, ys = [], []
    for g in aoi_geoms:
        env = g.boundingBox()
        xs.append((env.xMinimum(), env.xMaximum()))
        ys.append((env.yMinimum(), env.yMaximum()))

    kept = 0
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        rows = list(reader)

    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            try:
                lon = float(row.get("longitude", ""))
                lat = float(row.get("latitude", ""))
            except (TypeError, ValueError):
                continue
            inside = False
            for (x0, x1), (y0, y1), g in zip(xs, ys, aoi_geoms):
                if x0 <= lon <= x1 and y0 <= lat <= y1 and \
                        g.contains(QgsGeometry.fromPointXY(QgsPointXY(lon, lat))):
                    inside = True
                    break
            if inside:
                writer.writerow(row)
                kept += 1
    return kept
