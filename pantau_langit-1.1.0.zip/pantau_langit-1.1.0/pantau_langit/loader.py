"""Konversi hasil download menjadi layer QGIS (GeoTIFF, CSV titik, WMTS)."""

import os
import re
from datetime import datetime, timedelta

import numpy as np

from .symbology import (
    build_default_ramp,
    build_ramp_items,
    effective_scale_offset,
    get_layer_name,
    get_symbology,
    write_qml,
)

NODATA = -9999.0

LAT_NAMES = ("latitude", "lat", "y")
LON_NAMES = ("longitude", "lon", "x")
TIME_NAMES = ("time", "forecast_reference_time", "valid_time")
LEADTIME_NAMES = ("forecast_period", "leadtime")
COORD_VARS = (
    "latitude", "longitude", "lat", "lon", "time",
    "forecast_period", "forecast_reference_time", "valid_time",
    "level", "pressure_level", "height",
)

# Deskripsi band baku: "YYYY-MM-DD HH:MM" = waktu valid langkah data.
BAND_TIME_RE = re.compile(r"(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})")
LEAD_RE = re.compile(r"\+(\d+)h")


def _to_datetime(value):
    """Nilai koordinat waktu (datetime64/datetime/str) -> datetime|None."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    try:
        delta = np.datetime64(value, "s") - np.datetime64("1970-01-01T00:00:00")
        return datetime(1970, 1, 1) + timedelta(
            seconds=int(delta / np.timedelta64(1, "s")))
    except Exception:
        pass
    s = str(value)[:16].replace("T", " ")
    try:
        return datetime.strptime(s, "%Y-%m-%d %H:%M")
    except ValueError:
        return None


def parse_band_datetime(description):
    """Waktu valid band dari deskripsi ('YYYY-MM-DD HH:MM [+Nh]')."""
    if not description:
        return None
    m = BAND_TIME_RE.search(str(description))
    if not m:
        return None
    try:
        dt = datetime.strptime(f"{m.group(1)} {m.group(2)}", "%Y-%m-%d %H:%M")
    except ValueError:
        return None
    m2 = LEAD_RE.search(str(description))
    if m2:
        dt += timedelta(hours=int(m2.group(1)))
    return dt


# ---------------------------------------------------------------------------
# Pembacaan NetCDF CAMS
# ---------------------------------------------------------------------------
def read_cams_netcdf(filepath, variable_name=None):
    """Baca NetCDF CAMS -> data per langkah waktu + bounds WGS84 [W,S,E,N]."""
    try:
        import xarray as xr

        ds = xr.open_dataset(filepath)

        if variable_name is None:
            data_vars = [v for v in ds.data_vars if v not in COORD_VARS]
            if not data_vars:
                ds.close()
                return {"error": "Tidak ada variabel data dalam file"}
            variable_name = data_vars[0]

        if variable_name not in ds.data_vars:
            candidates = {}
            low = {v.lower().replace("_", ""): v for v in ds.data_vars}
            want = str(variable_name).lower().replace("_", "")
            if want in low:
                candidates["match"] = low[want]
            else:
                for v in ds.data_vars:
                    if want in v.lower().replace("_", ""):
                        candidates["partial"] = v
                        break
                if not candidates and ds.data_vars:
                    candidates["first"] = [v for v in ds.data_vars][0]
            if candidates:
                variable_name = list(candidates.values())[0]
            else:
                ds.close()
                return {
                    "error": f"Variabel '{variable_name}' tidak ditemukan. "
                             f"Tersedia: {list(ds.data_vars)}"
                }

        da = ds[variable_name]
        units = da.attrs.get("units", "")

        lat_name = next((n for n in LAT_NAMES if n in da.dims or n in ds.coords), None)
        lon_name = next((n for n in LON_NAMES if n in da.dims or n in ds.coords), None)
        if lat_name is None or lon_name is None:
            ds.close()
            return {"error": f"Koordinat lat/lon tidak ditemukan. Dims: {list(da.dims)}"}

        lats = np.array(ds.coords[lat_name].values, dtype=np.float64).flatten()
        lons = np.array(ds.coords[lon_name].values, dtype=np.float64).flatten()

        reverse_lat = False
        if len(lats) > 1 and lats[0] > lats[-1]:
            lats = lats[::-1]
            reverse_lat = True

        reverse_lon = False
        if len(lons) > 1 and lons[0] > lons[-1]:
            if np.max(lons) > 180:
                lons = np.where(lons > 180, lons - 360, lons)
                sort_idx = np.argsort(lons)
                lons = lons[sort_idx]
            else:
                lons = lons[::-1]
            reverse_lon = True

        time_name = next((n for n in TIME_NAMES if n in da.dims or n in ds.coords), None)
        leadtime_name = next((n for n in LEADTIME_NAMES if n in da.dims or n in ds.coords), None)

        times = []
        if time_name:
            times = [str(t) for t in ds.coords[time_name].values]
        raw_times = (list(ds.coords[time_name].values) if time_name else [])
        leadtimes = []
        if leadtime_name:
            leadtimes = list(ds.coords[leadtime_name].values)

        def lead_hours(lt):
            try:
                if hasattr(lt, "dtype") and np.issubdtype(type(lt), np.timedelta64):
                    return int(lt / np.timedelta64(1, "h"))
                return int(float(lt))
            except Exception:
                return 0

        # Label band = waktu VALID (run + leadtime) agar Temporal Control QGIS
        # dan pemilihan rentang waktu analisis langsung benar.
        time_labels, valid_times, ref_times = [], [], []
        if times and leadtimes:
            for t_str, t_raw in zip(times, raw_times):
                ref_dt = _to_datetime(t_raw)
                for lt in leadtimes:
                    lh = lead_hours(lt)
                    vt = ref_dt + timedelta(hours=lh) if ref_dt else None
                    if vt is not None:
                        time_labels.append(vt.strftime("%Y-%m-%d %H:%M"))
                    else:
                        time_labels.append(
                            f"{t_str[:16].replace('T', ' ')} +{lh}h")
                    valid_times.append(vt)
                    ref_times.append(ref_dt)
        elif times:
            for t_str, t_raw in zip(times, raw_times):
                ref_dt = _to_datetime(t_raw)
                valid_times.append(ref_dt)
                ref_times.append(ref_dt)
                time_labels.append(
                    ref_dt.strftime("%Y-%m-%d %H:%M") if ref_dt
                    else t_str[:16].replace("T", " "))
        else:
            time_labels = ["default"]
            valid_times = [None]
            ref_times = [None]

        def finalize(data):
            while data.ndim > 2:
                data = data[0]
            if data.ndim < 2:
                return None
            if reverse_lat:
                data = data[::-1]
            if reverse_lon:
                data = data[:, ::-1]
            return data

        data_slices = []
        if time_name and leadtime_name:
            for t_idx in range(len(ds.coords[time_name])):
                for lt_idx in range(len(ds.coords[leadtime_name])):
                    data = finalize(np.array(da.isel({time_name: t_idx, leadtime_name: lt_idx}).values,
                                             dtype=np.float64))
                    if data is not None:
                        data_slices.append(data)
        elif time_name:
            for t_idx in range(len(ds.coords[time_name])):
                data = finalize(np.array(da.isel({time_name: t_idx}).values, dtype=np.float64))
                if data is not None:
                    data_slices.append(data)
        else:
            data = finalize(np.array(da.values, dtype=np.float64))
            if data is not None:
                data_slices.append(data)

        bounds = [
            float(np.min(lons)), float(np.min(lats)),
            float(np.max(lons)), float(np.max(lats)),
        ]
        ds.close()

        return {
            "data_slices": data_slices,
            "bounds": bounds,
            "lats": lats,
            "lons": lons,
            "variable": variable_name,
            "units": units,
            "time_labels": time_labels,
            "valid_times": valid_times,
            "ref_times": ref_times,
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Penulisan GeoTIFF
# ---------------------------------------------------------------------------
def write_geotiff(path, data_list, lats, lons, labels=None, unit=None):
    """Tulis list array 2D (lat ascending) sebagai multi-band GeoTIFF EPSG:4326."""
    from osgeo import gdal, osr

    h, w = data_list[0].shape
    dx = float(lons[1] - lons[0]) if len(lons) > 1 else 0.1
    dy = float(lats[1] - lats[0]) if len(lats) > 1 else 0.1
    west = float(lons[0]) - dx / 2.0
    north = float(lats[-1]) + dy / 2.0

    drv = gdal.GetDriverByName("GTiff")
    ds = drv.Create(path, w, h, len(data_list), gdal.GDT_Float32,
                    options=["COMPRESS=LZW", "TILED=NO"])
    ds.SetGeoTransform((west, dx, 0.0, north, 0.0, -dy))
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(4326)
    ds.SetProjection(srs.ExportToWkt())

    for i, arr in enumerate(data_list, start=1):
        out = np.array(arr, dtype=np.float32, copy=True)
        out[~np.isfinite(out)] = NODATA
        band = ds.GetRasterBand(i)
        band.WriteArray(np.flipud(out))
        band.SetNoDataValue(NODATA)
        if labels and i - 1 < len(labels):
            desc = str(labels[i - 1])
            if unit and unit not in ("-", "~"):
                desc = f"{desc} [{unit}]"
            band.SetDescription(desc)
        if unit:
            band.SetUnitType(str(unit))
    ds.FlushCache()
    ds = None
    return path


def _resolve_nc_file(path):
    """Kembalikan path file .nc; ekstrak dari .zip bila perlu."""
    if not str(path).lower().endswith(".zip"):
        return path, None
    import zipfile

    out_dir = os.path.dirname(path)
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if n.lower().endswith(".nc")]
        if not names:
            return None, f"Tidak ada file .nc dalam arsip {os.path.basename(path)}"
        target = os.path.join(
            out_dir, os.path.splitext(os.path.basename(path))[0] + ".nc"
        )
        with z.open(names[0]) as src, open(target, "wb") as dst:
            dst.write(src.read())
    return target, None


def convert_cams(nc_path, param_key, nc_var=None, out_dir=None,
                 progress_callback=None):
    """NetCDF CAMS (atau zip, bisa beberapa file) -> GeoTIFF multi-band.

    nc_path bisa berupa satu path atau list path (mis. file "tanggal
    sebelumnya" + file "tanggal terkini"). Semua langkah waktu digabung
    menjadi satu GeoTIFF multi-waktu; duplikasi waktu valid antar run
    dibuang (run terbaru menang), lalu band diurutkan menurut waktu valid.
    Deskripsi band = "YYYY-MM-DD HH:MM" (waktu valid) untuk Temporal
    Control QGIS dan pemilihan rentang waktu analisis.
    """
    progress = progress_callback
    nc_paths = list(nc_path) if isinstance(nc_path, (list, tuple)) else [nc_path]
    if not nc_paths:
        return {"error": "Tidak ada file NetCDF untuk dikonversi"}

    merged = {}       # valid_time -> {"data", "ref", "label"}
    unlabeled = []    # langkah waktu tanpa waktu valid
    first = None
    resolved_dir = out_dir

    for p in nc_paths:
        p, err = _resolve_nc_file(p)
        if err:
            return {"error": err}
        if resolved_dir is None:
            resolved_dir = os.path.dirname(p)
        if progress:
            progress(5, f"Membaca NetCDF {os.path.basename(p)}...")
        result = read_cams_netcdf(p, nc_var)
        if "error" in result:
            return result
        if first is None:
            first = result

        slices = result["data_slices"]
        valid_times = result.get("valid_times") or [None] * len(slices)
        ref_times = result.get("ref_times") or [None] * len(slices)
        labels = result["time_labels"]
        for i, data in enumerate(slices):
            vt = valid_times[i] if i < len(valid_times) else None
            rt = ref_times[i] if i < len(ref_times) else None
            label = labels[i] if i < len(labels) else ""
            if vt is None:
                unlabeled.append((data, label))
                continue
            cur = merged.get(vt)
            # duplikat waktu valid antar run -> run terbaru menang
            if cur is None or (rt or datetime.min) >= (cur["ref"] or datetime.min):
                merged[vt] = {"data": data, "ref": rt, "label": label}

    if first is None or not (merged or unlabeled):
        return {"error": "Tidak ada langkah waktu dalam data NetCDF"}

    nc_var = first["variable"]
    sym_key = nc_var
    scale, offset = effective_scale_offset(first.get("units", ""), sym_key)

    out_dir = resolved_dir or os.path.dirname(nc_paths[0])
    safe = param_key.replace("_", "-")
    tif_path = os.path.join(out_dir, f"{safe}.tif")

    ordered = sorted(merged.items(), key=lambda kv: kv[0])
    bands, labels_out, times_out = [], [], []
    for vt, rec in ordered:
        bands.append(np.array(rec["data"], dtype=np.float64) * scale + offset)
        labels_out.append(vt.strftime("%Y-%m-%d %H:%M"))
        times_out.append(vt)
    for data, label in unlabeled:
        bands.append(np.array(data, dtype=np.float64) * scale + offset)
        labels_out.append(label or f"band {len(bands)}")
        times_out.append(None)

    if progress:
        progress(60, f"Menulis GeoTIFF ({len(bands)} band)...")
    unit = (get_symbology(sym_key) or {}).get("display_unit", "")
    write_geotiff(tif_path, bands, first["lats"], first["lons"],
                  labels_out, unit=unit)

    valid = [b[np.isfinite(b)] for b in bands]
    vmin = float(np.min([v.min() for v in valid])) if valid else None
    vmax = float(np.max([v.max() for v in valid])) if valid else None

    try:
        write_qml(tif_path, sym_key, vmin, vmax)
    except Exception:
        pass

    return {
        "file": tif_path,
        "bounds": first["bounds"],
        "labels": labels_out,
        "times": times_out,
        "band_count": len(bands),
        "variable": nc_var,
        "min": vmin,
        "max": vmax,
    }


def _grib_valid_datetime(band):
    """Waktu valid band GRIB dari metadata GDAL (GRIB_VALID_TIME dst.)."""
    raw = band.GetMetadataItem("GRIB_VALID_TIME")
    m = re.match(r"\s*(\d+)", str(raw)) if raw else None
    if m:
        try:
            return datetime(1970, 1, 1) + timedelta(seconds=int(m.group(1)))
        except (ValueError, OverflowError):
            pass
    raw = band.GetMetadataItem("GRIB_REF_TIME")
    m = re.match(r"\s*(\d+)", str(raw)) if raw else None
    if m:
        try:
            dt = datetime(1970, 1, 1) + timedelta(seconds=int(m.group(1)))
        except (ValueError, OverflowError):
            return None
        fs = band.GetMetadataItem("GRIB_FORECAST_SECONDS") or "0"
        try:
            dt += timedelta(seconds=int(str(fs).split()[0]))
        except (ValueError, IndexError):
            pass
        return dt
    return None


def convert_grib(grib_path, out_dir=None, sym_key=None, progress_callback=None):
    """GRIB2 -> GeoTIFF multi-band (skala satuan diterapkan bila dikenal).

    Deskripsi band diberi awalan waktu valid ("YYYY-MM-DD HH:MM | ...")
    bila tersedia pada metadata GRIB, agar Temporal Control QGIS bisa
    memakai hasil unduhan cuaca.
    """
    from osgeo import gdal, osr

    progress = progress_callback
    if progress:
        progress(10, "Membaca GRIB...")
    src = gdal.Open(grib_path)
    if src is None:
        return {"error": f"GDAL tidak dapat membuka {os.path.basename(grib_path)}"}

    out_dir = out_dir or os.path.dirname(grib_path)
    tif_path = os.path.join(
        out_dir, os.path.splitext(os.path.basename(grib_path))[0] + ".tif"
    )

    bands = []
    labels = []
    times = []
    for b in range(1, src.RasterCount + 1):
        band = src.GetRasterBand(b)
        arr = band.ReadAsArray()
        if arr is None:
            continue
        units = band.GetUnitType() or band.GetMetadataItem("GRIB_UNIT") or ""
        scale, offset = effective_scale_offset(units, sym_key)
        bands.append(np.array(arr, dtype=np.float64) * scale + offset)
        desc = band.GetDescription() or band.GetMetadataItem("GRIB_COMMENT") or f"band {b}"
        vt = _grib_valid_datetime(band)
        times.append(vt)
        if vt is not None:
            desc = f"{vt.strftime('%Y-%m-%d %H:%M')} | {desc}"
        labels.append(desc)

    if not bands:
        src = None
        return {"error": "Tidak ada band pada file GRIB"}

    drv = gdal.GetDriverByName("GTiff")
    dst = drv.Create(tif_path, src.RasterXSize, src.RasterYSize, len(bands),
                     gdal.GDT_Float32, options=["COMPRESS=LZW", "TILED=NO"])
    gt = src.GetGeoTransform()
    dst.SetGeoTransform(gt)
    proj = src.GetProjection()
    if not proj:
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(4326)
        proj = srs.ExportToWkt()
    dst.SetProjection(proj)

    unit = (get_symbology(sym_key) or {}).get("display_unit", "")
    for i, arr in enumerate(bands, start=1):
        out = np.array(arr, dtype=np.float32, copy=True)
        out[~np.isfinite(out)] = NODATA
        band = dst.GetRasterBand(i)
        band.WriteArray(out)
        band.SetNoDataValue(NODATA)
        desc = labels[i - 1]
        if unit and unit not in ("-", "~"):
            desc = f"{desc} [{unit}]"
        band.SetDescription(desc)
        if unit:
            band.SetUnitType(str(unit))
    dst.FlushCache()
    dst = None
    src = None

    valid = [b[np.isfinite(b)] for b in bands]
    vmin = float(np.min([v.min() for v in valid])) if valid else None
    vmax = float(np.max([v.max() for v in valid])) if valid else None

    try:
        write_qml(tif_path, sym_key, vmin, vmax)
    except Exception:
        pass

    return {
        "file": tif_path,
        "labels": labels,
        "times": times,
        "band_count": len(bands),
        "min": vmin,
        "max": vmax,
    }


# ---------------------------------------------------------------------------
# Mosaic raster & klip ke poligon AOI
# ---------------------------------------------------------------------------
def mosaic_tifs(folder, out_path):
    """Gabungkan (mosaic) semua file TIF di folder menjadi satu raster.

    Pencarian rekursif ke subfolder. return {"file", "count"} atau {"error"}.
    """
    from osgeo import gdal

    files = []
    for root, _dirs, names in os.walk(folder):
        for name in sorted(names):
            if name.lower().endswith((".tif", ".tiff")):
                files.append(os.path.join(root, name))
    if not files:
        return {"error": f"Tidak ada file .tif/.tiff di folder: {folder}"}
    files.sort()

    tmp = out_path + ".mosaic.tmp.tif"
    ds = gdal.Warp(tmp, files, format="GTiff", resampleAlg="near",
                   creationOptions=["COMPRESS=LZW", "TILED=NO"])
    if ds is None:
        return {"error": "Gagal melakukan mosaic file TIF"}
    ds = None
    os.replace(tmp, out_path)
    return {"file": out_path, "count": len(files)}


def clip_raster_to_aoi(tif_path, cutline, out_path=None):
    """Potong raster mengikuti poligon AOI (gdal cutline).

    cutline: (path_datasource, layer_name|None) dari aoi.export_cutline.
    return {"file": ...} atau {"error": ...}.
    """
    from osgeo import gdal, ogr

    if not cutline:
        return {"error": "Cutline AOI tidak tersedia"}
    cut_path, cut_layer = cutline
    target = out_path or tif_path
    tmp = target + ".clip.tif"
    kwargs = dict(
        format="GTiff", cutlineDSName=cut_path, cropToCutline=True,
        creationOptions=["COMPRESS=LZW"],
    )
    if cut_layer:
        kwargs["cutlineLayer"] = cut_layer
    try:
        # SRS cutline dibaca dari datasource agar akurat lintas-CRS
        cut_ds = ogr.Open(cut_path)
        if cut_ds is not None:
            lyr = cut_ds.GetLayerByName(cut_layer) if cut_layer \
                else cut_ds.GetLayer(0)
            if lyr is not None and lyr.GetSpatialRef() is not None:
                kwargs["cutlineSRS"] = lyr.GetSpatialRef().ExportToWkt()
            cut_ds = None
    except Exception:
        pass
    try:
        ds = gdal.Warp(tmp, tif_path, **kwargs)
        if ds is None:
            return {"error": "Gagal memotong raster dengan AOI"}
        ds = None
        os.replace(tmp, target)
        return {"file": target}
    except Exception as e:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
        return {"error": f"Gagal memotong raster: {e}"}


# ---------------------------------------------------------------------------
# Pembuatan layer QGIS
# ---------------------------------------------------------------------------
def _ramp_type(name):
    from qgis.core import Qgis, QgsColorRampShader

    value = getattr(QgsColorRampShader, name, None)
    if value is not None:
        return value
    enum = getattr(QgsColorRampShader, "Type", None)
    if enum is not None:
        value = getattr(enum, name, None)
        if value is not None:
            return value
    interp = getattr(Qgis, "ShaderInterpolationMethod", None)
    if interp is not None:
        value = getattr(interp, name, None)
        if value is None and name == "Interpolated":
            value = getattr(interp, "Linear", None)
        if value is not None:
            return value
    return getattr(QgsColorRampShader.Type, name)


def _band_min_max(layer):
    """Min/max nyata dari seluruh band (fallback: band 1)."""
    try:
        from qgis.core import QgsRasterBandStats

        prov = layer.dataProvider()
        vmin = vmax = None
        for b in range(1, prov.bandCount() + 1):
            stats = prov.bandStatistics(b, QgsRasterBandStats.All, layer.extent(), 256)
            lo, hi = stats.minimumValue, stats.maximumValue
            if lo == lo and hi == hi:  # bukan NaN
                vmin = lo if vmin is None else min(vmin, lo)
                vmax = hi if vmax is None else max(vmax, hi)
        return vmin, vmax
    except Exception:
        return None, None


def apply_raster_style(layer, param_name, vmin=None, vmax=None):
    """Terapkan symbology gradasi halus seperti chart web CAMS.

    Warna bergradasi antar breakpoint kelas legenda resmi (bukan min-max
    data); nilai di bawah kelas terendah tidak diwarnai (transparan).
    Interpolasi spasial bilinear diterapkan agar piksel kasar data CAMS
    tampil halus seperti chart web.
    """
    import math

    from qgis.core import (
        QgsBilinearRasterResampler,
        QgsColorRampShader,
        QgsRasterShader,
        QgsSingleBandPseudoColorRenderer,
    )

    if vmin is None or vmax is None:
        smin, smax = _band_min_max(layer)
        vmin = smin if vmin is None else vmin
        vmax = smax if vmax is None else vmax
    try:
        vmin, vmax = float(vmin), float(vmax)
    except (TypeError, ValueError):
        vmin, vmax = 0.0, 1.0
    if not (math.isfinite(vmin) and math.isfinite(vmax)) or vmax <= vmin:
        vmax = vmin + 1.0

    ramp_type, items, opacity = build_ramp_items(param_name, vmin=vmin,
                                                 vmax=vmax)
    if ramp_type is None or not items:
        ramp_type, items, opacity = build_default_ramp(vmin, vmax)

    fn = QgsColorRampShader()
    fn.setColorRampType(_ramp_type(
        "Interpolated" if ramp_type == "interpolated" else "Discrete"))
    fn.setColorRampItemList(items)

    # legenda tampil sebagai daftar kelas (bukan gradien min-max), sementara
    # peta tetap bergradasi halus seperti chart web
    try:
        from qgis.core import QgsColorRampLegendNodeSettings

        legend = QgsColorRampLegendNodeSettings()
        legend.setUseContinuousLegend(False)
        fn.setLegendSettings(legend)
    except Exception:
        pass

    shader = QgsRasterShader()
    shader.setRasterShaderFunction(fn)
    shader.setMinimumValue(vmin)
    shader.setMaximumValue(vmax)

    renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader)
    renderer.setOpacity(opacity)
    renderer.setClassificationMin(vmin)
    renderer.setClassificationMax(vmax)

    # Interpolasi spasial agar tampilan halus seperti chart web:
    # 1) resample nilai raster (bilinear) di level provider bila didukung
    try:
        from qgis.core import Qgis

        prov = layer.dataProvider()
        method_enum = getattr(Qgis, "RasterResamplingMethod", None)
        bilinear = getattr(method_enum, "Bilinear", None) if method_enum else None
        if bilinear is not None and prov is not None:
            try:
                prov.setZoomedInResamplingMethod(bilinear)
                prov.setZoomedOutResamplingMethod(bilinear)
            except Exception:
                pass
            try:
                prov.setMaxOversampling(16.0)
            except Exception:
                pass
            stage_enum = getattr(Qgis, "RasterResamplingStage", None)
            stage = getattr(stage_enum, "Provider", None) if stage_enum else None
            if stage is not None:
                try:
                    layer.setResamplingStage(stage)
                except Exception:
                    pass
    except Exception:
        pass
    # 2) resample gambar hasil render (bilinear) pada semua skala zoom
    try:
        resample_filter = layer.pipe().resampleFilter()
        if resample_filter is not None:
            resample_filter.setZoomedInResampler(QgsBilinearRasterResampler())
            resample_filter.setZoomedOutResampler(QgsBilinearRasterResampler())
            try:
                resample_filter.setMaxOversampling(16.0)
            except Exception:
                pass
    except Exception:
        pass

    layer.setRenderer(renderer)
    layer.triggerRepaint()
    return layer


# ---------------------------------------------------------------------------
# Temporal Control QGIS (waktu valid per band)
# ---------------------------------------------------------------------------
def band_datetimes(path):
    """Waktu valid per band dari deskripsi band raster (None bila tak ada)."""
    from osgeo import gdal

    try:
        ds = gdal.Open(str(path))
    except Exception:
        return []
    if ds is None:
        return []
    out = []
    for b in range(1, ds.RasterCount + 1):
        out.append(parse_band_datetime(ds.GetRasterBand(b).GetDescription()))
    ds = None
    return out


def _infer_time_step(times):
    """Langkah waktu tipikal dari daftar waktu valid (fallback: 1 hari)."""
    uniq = sorted({t for t in times if t})
    if not uniq:
        return None
    diffs = [(b - a).total_seconds() for a, b in zip(uniq, uniq[1:]) if b > a]
    if diffs:
        return timedelta(seconds=min(diffs))
    return timedelta(days=1)


def _qdt(dt):
    from qgis.PyQt.QtCore import QDate, QDateTime, QTime

    return QDateTime(QDate(dt.year, dt.month, dt.day),
                     QTime(dt.hour, dt.minute))


def apply_temporal_properties(layer, tif_path=None):
    """Aktifkan Temporal Control QGIS untuk raster multi-waktu.

    Waktu valid per band dibaca dari deskripsi band ("YYYY-MM-DD HH:MM").
    - QGIS >= 3.38: mode "Fixed Range Per Band" -> Temporal Controller
      otomatis menampilkan band sesuai waktu animasi.
    - QGIS lebih lama: fallback "Fixed Temporal Range" (rentang seluruh data).
    Mengembalikan True bila properti temporal berhasil diaktifkan.
    """
    from qgis.core import Qgis, QgsDateTimeRange

    path = tif_path or layer.source()
    times = band_datetimes(path)
    if not any(times):
        return False

    step = _infer_time_step(times) or timedelta(hours=3)
    uniq = sorted({t for t in times if t})

    tp = layer.temporalProperties()
    mode_enum = getattr(Qgis, "RasterTemporalMode", None)
    per_band = (getattr(mode_enum, "FixedRangePerBand", None)
                if mode_enum else None)

    if per_band is not None:
        ranges = {}
        for i, t in enumerate(times):
            if t is None:
                continue
            later = [u for u in uniq if u > t]
            end = later[0] if later else t + step
            ranges[i + 1] = QgsDateTimeRange(_qdt(t), _qdt(end))
        if not ranges:
            return False
        tp.setMode(per_band)
        tp.setFixedRangePerBand(ranges)
    else:
        fixed = (getattr(mode_enum, "FixedTemporalRange", None)
                 if mode_enum else None)
        if fixed is None:
            return False
        tp.setMode(fixed)
        tp.setFixedTemporalRange(
            QgsDateTimeRange(_qdt(uniq[0]), _qdt(uniq[-1] + step)))

    tp.setIsActive(True)
    layer.triggerRepaint()
    return True


def configure_temporal_controller(iface, times):
    """Setel Temporal Controller QGIS ke rentang & langkah waktu data.

    Dipanggil setelah layer temporal dimuat agar panel Temporal Control
    langsung siap diputar (langkah animasi = langkah waktu tipikal data).
    """
    ts = sorted({t for t in times if t})
    if not ts or iface is None:
        return False
    try:
        from qgis.core import (
            QgsDateTimeRange,
            QgsInterval,
            QgsTemporalNavigationObject,
        )

        step = _infer_time_step(ts) or timedelta(hours=3)
        tc = iface.mapCanvas().temporalController()
        nav_mode = getattr(QgsTemporalNavigationObject, "Animated", None)
        if nav_mode is not None:
            tc.setNavigationMode(nav_mode)
        tc.setTemporalExtents(
            QgsDateTimeRange(_qdt(ts[0]), _qdt(ts[-1] + step)))
        tc.setFrameDuration(QgsInterval(step.total_seconds()))
        tc.setFramesPerSecond(1.0)
        tc.setLooping(True)
        tc.rewindToStart()
        return True
    except Exception:
        return False


def make_raster_layer(tif_path, layer_name, param_name=None, vmin=None, vmax=None):
    from qgis.core import QgsRasterLayer

    layer = QgsRasterLayer(tif_path, layer_name, "gdal")
    if not layer.isValid():
        return None
    try:
        apply_raster_style(layer, param_name, vmin, vmax)
    except Exception:
        pass
    try:
        apply_temporal_properties(layer, tif_path)
    except Exception:
        pass
    return layer


def make_hotspot_layer(csv_path, layer_name):
    from qgis.PyQt.QtGui import QColor
    from qgis.core import (
        QgsGraduatedSymbolRenderer,
        QgsGradientColorRamp,
        QgsMarkerSymbol,
        QgsSingleSymbolRenderer,
        QgsVectorLayer,
    )

    path = csv_path.replace("\\", "/")
    uri = f"file:///{path}?delimiter=,&xField=longitude&yField=latitude&crs=epsg:4326"
    layer = QgsVectorLayer(uri, layer_name, "delimitedtext")
    if not layer.isValid():
        return None
    if layer.featureCount() == 0:
        # provider delimitedtext tidak memberi geometry/renderer untuk CSV kosong
        return None

    symbol = QgsMarkerSymbol.createSimple({
        "name": "circle", "color": "#FF4500", "size": "3",
        "outline_color": "#7A1B00", "outline_width": "0.2",
    })

    try:
        field_names = [f.name() for f in layer.fields()]
        attr = "frp" if "frp" in field_names else (
            "brightness" if "brightness" in field_names else None)
        if attr and layer.featureCount() >= 10:
            mode = getattr(QgsGraduatedSymbolRenderer, "Quantile", None)
            if mode is None:
                mode = QgsGraduatedSymbolRenderer.Mode.Quantile
            ramp = QgsGradientColorRamp(QColor("#FFEDA0"), QColor("#800026"))
            renderer = QgsGraduatedSymbolRenderer.createRenderer(
                layer, attr, 5, mode, symbol, ramp
            )
            layer.setRenderer(renderer or QgsSingleSymbolRenderer(symbol))
        else:
            layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    except Exception:
        layer.setRenderer(QgsSingleSymbolRenderer(symbol))

    layer.triggerRepaint()
    return layer


def make_wmts_layer(gibs_key, date_str, time_str="00:00"):
    from qgis.core import QgsRasterLayer

    from .downloaders.wmts import build_wmts_uri, layer_display_name

    uri = build_wmts_uri(gibs_key, date_str, time_str)
    if not uri:
        return None

    name = layer_display_name(gibs_key, date_str)
    layer = QgsRasterLayer(uri, name, "wms")
    if not layer.isValid():
        base = uri.split("&time=")[0] if "&time=" in uri else uri
        layer = QgsRasterLayer(base, name, "wms")
    return layer if layer.isValid() else None


# ---------------------------------------------------------------------------
# Layer panah arah angin
# ---------------------------------------------------------------------------
def _wind_arrow_symbol():
    """Simbol anak panah arah angin (SVG panah QGIS -> font -> segitiga)."""
    from qgis.core import (
        QgsApplication,
        QgsFontMarkerSymbolLayer,
        QgsMarkerSymbol,
        QgsSvgMarkerSymbolLayer,
    )
    from qgis.PyQt.QtGui import QColor

    fill = QColor("#1F4E79")
    outline = QColor("#10304A")

    # 1) SVG panah bawaan QGIS (Arrow_06 = panah tegak; fallback Arrow_01)
    svg_path = None
    try:
        candidates = []
        for base in QgsApplication.svgPaths():
            for name in ("arrows/Arrow_06.svg", "arrows/Arrow_01.svg"):
                candidates.append(os.path.join(base, name))
        for cand in candidates:
            if os.path.isfile(cand):
                svg_path = cand
                break
    except Exception:
        svg_path = None
    if svg_path:
        try:
            svg_layer = QgsSvgMarkerSymbolLayer(svg_path)
            svg_layer.setSize(6.0)
            svg_layer.setFillColor(fill)
            svg_layer.setStrokeColor(outline)
            return QgsMarkerSymbol([svg_layer])
        except Exception:
            pass

    # 2) glyph panah font (U+2191)
    try:
        font_layer = QgsFontMarkerSymbolLayer("DejaVu Sans", "\u2191", 9.0,
                                             fill, 0.0)
        return QgsMarkerSymbol([font_layer])
    except Exception:
        pass

    # 3) fallback segitiga
    return QgsMarkerSymbol.createSimple({
        "name": "triangle", "color": "#1F4E79",
        "outline_color": "#10304A", "outline_width": "0.2", "size": "5",
    })


def make_wind_arrow_layer(tif_path, layer_name, max_points=1000):
    """Buat layer titik berisi panah arah angin dari raster arah (derajat).

    Konvensi arah angin meteorologi = arah DATANG (clockwise dari utara).
    Panah digambar mengarah ke arah GERAK angin (datang + 180 derajat).
    """
    from osgeo import gdal

    from qgis.core import (
        QgsFeature, QgsGeometry, QgsPointXY, QgsProperty,
        QgsVectorLayer,
    )

    ds = gdal.Open(tif_path)
    if ds is None:
        return None
    band = ds.GetRasterBand(1)
    arr = band.ReadAsArray().astype(np.float64)
    nodata = band.GetNoDataValue()
    if nodata is not None:
        arr[arr == nodata] = np.nan
    arr[~np.isfinite(arr)] = np.nan
    gt = ds.GetGeoTransform()
    height, width = arr.shape

    step = max(1, int(np.ceil(np.sqrt(height * width / max_points))))
    rows, cols = np.mgrid[0:height:step, 0:width:step]
    vals = arr[rows, cols]
    ok = np.isfinite(vals)
    rows, cols, vals = rows[ok], cols[ok], vals[ok]

    layer = QgsVectorLayer(
        "Point?crs=epsg:4326&field=arah:double&field=arah_gerak:double",
        layer_name, "memory")
    if not layer.isValid():
        return None
    prov = layer.dataProvider()
    feats = []
    for r, c, v in zip(rows.tolist(), cols.tolist(), vals.tolist()):
        lon = gt[0] + (c + 0.5) * gt[1]
        lat = gt[3] + (r + 0.5) * gt[5]
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
        direction = float(v) % 360.0
        f.setAttribute("arah", direction)
        f.setAttribute("arah_gerak", (direction + 180.0) % 360.0)
        feats.append(f)
    prov.addFeatures(feats)
    layer.updateExtents()

    symbol = _wind_arrow_symbol()
    # rotasi simbol QGIS searah jarum jam; panah = arah gerak (datang + 180)
    symbol.setDataDefinedAngle(
        QgsProperty.fromExpression('"arah_gerak"'))
    renderer = layer.renderer()
    if renderer is not None:
        renderer.setSymbol(symbol)
    layer.triggerRepaint()
    return layer


def default_layer_name(param_key, nc_var=None):
    return get_layer_name(nc_var or param_key)


def sym_key_for_weather(weather_key, weather_params):
    cfg = weather_params.get(weather_key) or {}
    return cfg.get("sym")
