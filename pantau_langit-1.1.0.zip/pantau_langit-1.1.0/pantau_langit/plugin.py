import os

from qgis.core import QgsApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

PLUGIN_MENU = "Pantau Langit Indonesia"


class PantauLangitPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.action_download = None
        self.action_settings = None

    # -------------------------------------------------------------- lifecycle
    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action_download = QAction(
            icon, "Unduh Data...", self.iface.mainWindow()
        )
        self.action_download.triggered.connect(self.open_download_dialog)

        self.action_settings = QAction(
            "Pengaturan API...", self.iface.mainWindow()
        )
        self.action_settings.triggered.connect(self.open_settings)

        self.iface.addPluginToMenu(PLUGIN_MENU, self.action_download)
        self.iface.addPluginToMenu(PLUGIN_MENU, self.action_settings)
        self.iface.addToolBarIcon(self.action_download)

        from .processing.provider import PantauLangitProvider

        self.provider = PantauLangitProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        for action in (self.action_download, self.action_settings):
            if action is not None:
                self.iface.removePluginMenu(PLUGIN_MENU, action)
                self.iface.removeToolBarIcon(action)
        self.action_download = None
        self.action_settings = None

        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None

    # ----------------------------------------------------------------- slots
    def open_download_dialog(self):
        from .dialogs.download_dialog import DownloadDialog

        dialog = DownloadDialog(self.iface, self.iface.mainWindow())
        dialog.exec_()

    def open_settings(self):
        from .dialogs.settings_dialog import SettingsDialog

        dialog = SettingsDialog(self.iface.mainWindow())
        dialog.exec_()
