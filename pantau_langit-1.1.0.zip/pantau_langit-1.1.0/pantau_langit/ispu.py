"""Perhitungan ISPU sesuai Permen LHK No. P.14/MENLHK/SETJEN/KUM.1/7/2020.

Sumber: Lampiran I (tata cara perhitungan) dan Lampiran II (penentuan kategori).

Lampiran I - breakpoint konsentrasi (SEMUA dalam µg/m3, data rata-rata 24 jam):

  ISPU     PM10   PM2.5   SO2    CO      O3     NO2    HC
  0        0      0       0      0       0      0      0
  50       50     15,5    52     4000    120    80     45
  100      150    55,4    180    8000    235    200    100
  200      350    150,4   400    15000   400    1130   215
  300      420    250,4   800    30000   800    2260   432
  500      500    500     1200   45000   1000   3000   648

Rumus (interpolasi linier bertahap):
    I = I_bawah + (I_atas - I_bawah) * (C - C_bawah) / (C_atas - C_bawah)

Lampiran II - kategori dan status warna:
    Baik              Hijau   1 - 50
    Sedang            Biru    51 - 100
    Tidak Sehat       Kuning  101 - 200
    Sangat Tidak Sehat Merah  201 - 300
    Berbahaya         Hitam   >= 301

ISPU suatu wilayah ditentukan oleh parameter dengan nilai ISPU tertinggi.
"""

import numpy as np

ISPU_VALUES = np.array([0.0, 50.0, 100.0, 200.0, 300.0, 500.0])

BREAKPOINTS = {
    "pm10": np.array([0.0, 50.0, 150.0, 350.0, 420.0, 500.0]),
    "pm25": np.array([0.0, 15.5, 55.4, 150.4, 250.4, 500.0]),
    "so2": np.array([0.0, 52.0, 180.0, 400.0, 800.0, 1200.0]),
    "co": np.array([0.0, 4000.0, 8000.0, 15000.0, 30000.0, 45000.0]),
    "o3": np.array([0.0, 120.0, 235.0, 400.0, 800.0, 1000.0]),
    "no2": np.array([0.0, 80.0, 200.0, 1130.0, 2260.0, 3000.0]),
    "hc": np.array([0.0, 45.0, 100.0, 215.0, 432.0, 648.0]),
}

PARAM_LABELS = {
    "pm10": "PM10",
    "pm25": "PM2.5",
    "so2": "SO2",
    "co": "CO",
    "o3": "O3",
    "no2": "NO2",
    "hc": "Hidrokarbon (HO)",
}

# Kategori: (nama, status warna Permen, kode, batas bawah ISPU, warna peta)
CATEGORIES = [
    ("Baik", "Hijau", 1, 0, "#00A651"),
    ("Sedang", "Biru", 2, 51, "#2196F3"),
    ("Tidak Sehat", "Kuning", 3, 101, "#FFD500"),
    ("Sangat Tidak Sehat", "Merah", 4, 201, "#E53935"),
    ("Berbahaya", "Hitam", 5, 301, "#212121"),
]

# Batas antar kelas untuk klasifikasi (edge kiri inklusif)
CLASS_EDGES = np.array([0.0, 51.0, 101.0, 201.0, 301.0])
NODATA = -9999.0

# Konversi satuan input -> µg/m3 (gas pada 25 C, 1 atm; 1 mol = 24.45 L)
_MOLAR_MASS = {"co": 28.0101, "no2": 46.0055, "so2": 64.066,
               "o3": 47.998, "hc": 16.0425, "pm10": 1.0, "pm25": 1.0}

UNIT_CHOICES = ["µg/m3", "mg/m3", "ppm", "ppb"]


def unit_factor(param_key, unit):
    """Pengali untuk mengubah satuan input menjadi µg/m3."""
    unit = (unit or "µg/m3").strip().lower()
    if unit in ("ug/m3", "ugm3", "µg/m3", "μg/m3"):
        return 1.0
    if unit in ("mg/m3", "mgm3"):
        return 1000.0
    mm = _MOLAR_MASS.get(param_key, 1.0)
    if unit == "ppm":
        return mm / 24.45 * 1000.0
    if unit == "ppb":
        return mm / 24.45
    raise ValueError(f"Satuan tidak dikenal: {unit}")


def compute_ispu(conc, param_key):
    """Konsentrasi (µg/m3) -> nilai ISPU 0-500 (interpolasi linier bertahap)."""
    bp = BREAKPOINTS[param_key]
    conc = np.asarray(conc, dtype=np.float64)
    ispu = np.interp(conc, bp, ISPU_VALUES)
    # nilai > breakpoint teratas tetap 500 (clamp), negatif menjadi 0
    ispu = np.clip(ispu, 0.0, 500.0)
    ispu[~np.isfinite(conc)] = np.nan
    return ispu


def classify_ispu(ispu):
    """Nilai ISPU -> kelas 1-5 (Baik..Berbahaya), hemat memori (uint8)."""
    x = np.asarray(ispu)
    klass = np.zeros(x.shape, dtype=np.uint8)
    finite = np.isfinite(x)
    for i in range(len(CLASS_EDGES)):
        lo = CLASS_EDGES[i]
        hi = CLASS_EDGES[i + 1] if i + 1 < len(CLASS_EDGES) else np.inf
        if i == 0:
            m = finite & (x < hi)          # kelas terbawah mencakup nilai < 0
        else:
            m = finite & (x >= lo) & (x < hi)
        klass[m] = i + 1
    return klass


def category_names():
    return [c[0] for c in CATEGORIES]


def category_colors():
    return [c[4] for c in CATEGORIES]


def category_labels():
    return [_cat_label(c) for c in CATEGORIES]


def _cat_label(cat):
    name, warna, kode, bawah, _ = cat
    if kode == 1:
        rentang = "1 - 50"
    elif kode == 5:
        rentang = ">= 301"
    else:
        atas = {2: 100, 3: 200, 4: 300}[kode]
        rentang = f"{bawah} - {atas}"
    return f"{name} ({warna}) | ISPU {rentang}"


def detect_admin_fields(layer):
    """Deteksi field desa/kecamatan/kabupaten/provinsi pada layer admin.

    Mendukung field BPS/BIG (WADMKD=desa, WADMKC=kecamatan, WADMKK=kabupaten,
    WADMPR=provinsi), GADM (NAME_1..NAME_4), dan nama umum lainnya.
    """
    lower = {f.name().lower(): f.name() for f in layer.fields()}

    def find(*keys):
        # kecocokan persis diutamakan
        for key in keys:
            if key in lower:
                return lower[key]
        for key in keys:
            for low, orig in lower.items():
                if key in low:
                    return orig
        return None

    return {
        "desa": find("wadmkd", "desa", "village", "kelurahan", "name_4", "name4"),
        "kecamatan": find("wadmkc", "kecamatan", "kec_", "district",
                          "name_3", "name3"),
        "kabupaten": find("wadmkk", "kabupaten", "kab_", "kota", "regency",
                          "kabkot", "name_2", "name2"),
        "provinsi": find("wadmpr", "provinsi", "prov_", "province",
                         "name_1", "name1"),
    }


# ---------------------------------------------------------------------------
# Styling QGIS
# ---------------------------------------------------------------------------
def class_shader_items():
    """Item shader diskrit raster ISPU: (batas atas kelas, warna, label).

    Batas atas (bukan batas bawah!) karena semantik mode Discrete QGIS:
    nilai <= batas atas item memperoleh warna item tersebut. Dengan ini
    kelas raster persis sama dengan definisi (0-50 Baik, 51-100 Sedang,
    101-200 Tidak Sehat, 201-300 Sangat Tidak Sehat, >= 301 Berbahaya)
    sehingga warna raster sama dengan warna layer admin.
    """
    items = []
    edges = list(CLASS_EDGES) + [float("inf")]
    for i, cat in enumerate(CATEGORIES):
        hi = edges[i + 1]
        if hi == float("inf"):
            value = float("inf")
        else:
            value = hi - max(hi * 1e-9, 1e-9)
        items.append((value, cat[4], _cat_label(cat)))
    return items


def style_ispu_raster(layer):
    """Raster ISPU 0-500 -> 5 kelas dengan status warna Permen (diskrit)."""
    from qgis.core import (
        QgsColorRampShader, QgsRasterShader,
        QgsSingleBandPseudoColorRenderer,
    )
    from qgis.PyQt.QtGui import QColor

    items = []
    for value, hexcol, label in class_shader_items():
        items.append(QgsColorRampShader.ColorRampItem(
            float(value), QColor(hexcol), label))
    fn = QgsColorRampShader()
    fn.setColorRampType(_discrete())
    fn.setColorRampItemList(items)

    shader = QgsRasterShader()
    shader.setRasterShaderFunction(fn)
    stats = _minmax(layer)
    if stats:
        shader.setMinimumValue(stats[0])
        shader.setMaximumValue(stats[1])

    renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader)
    renderer.setOpacity(1.0)
    if stats:
        renderer.setClassificationMin(stats[0])
        renderer.setClassificationMax(stats[1])
    layer.setRenderer(renderer)
    layer.triggerRepaint()
    return layer


def style_class_raster(layer):
    """Raster kelas 1-5 -> renderer palet kategori."""
    from qgis.core import QgsPalettedRasterRenderer
    from qgis.PyQt.QtGui import QColor

    classes = []
    for name, warna, kode, bawah, hexcol in CATEGORIES:
        classes.append(QgsPalettedRasterRenderer.Class(
            kode, QColor(hexcol), _cat_label((name, warna, kode, bawah, hexcol))))
    renderer = QgsPalettedRasterRenderer(layer.dataProvider(), 1, classes)
    layer.setRenderer(renderer)
    layer.triggerRepaint()
    return layer


def style_admin_layer(layer, field="kls_ISPU"):
    """Layer admin -> warna kategori ISPU, identik dengan raster ISPU.

    Default memakai field "kls_ISPU" (kategori dari nilai majority) agar
    warna poligon sama dengan warna dominan raster di dalamnya. Field
    "kategori" (kode 1-5, dari ISPU tertinggi) juga didukung. Wilayah
    tanpa data ISPU tampil transparan (hanya garis batas).
    """
    from qgis.core import (
        QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsFillSymbol,
    )

    def fill_symbol(color):
        symbol = QgsFillSymbol.createSimple({
            "color": color, "outline_color": "#555555", "outline_width": "0.2",
        })
        symbol.setOpacity(0.75)
        return symbol

    use_names = (field != "kategori")
    categories = []
    for name, warna, kode, bawah, hexcol in CATEGORIES:
        value = name if use_names else kode
        categories.append(QgsRendererCategory(
            value, fill_symbol(hexcol), _cat_label((name, warna, kode,
                                                    bawah, hexcol))))
    renderer = QgsCategorizedSymbolRenderer(field, categories)
    try:
        renderer.setSourceSymbol(fill_symbol("0,0,0,0"))
    except Exception:
        pass
    layer.setRenderer(renderer)
    layer.triggerRepaint()
    return layer


def _discrete():
    from qgis.core import QgsColorRampShader

    value = getattr(QgsColorRampShader, "Discrete", None)
    if value is not None:
        return value
    return QgsColorRampShader.Type.Discrete


def _minmax(layer):
    try:
        from qgis.core import QgsRasterBandStats

        stats = layer.dataProvider().bandStatistics(
            1, QgsRasterBandStats.All, layer.extent(), 256)
        lo, hi = stats.minimumValue, stats.maximumValue
        if lo == lo and hi == hi:
            return float(lo), float(hi)
    except Exception:
        pass
    return None
