"""Downloader hotspot kebakaran NASA FIRMS (area CSV API)."""

import csv
import io
import os
import tempfile

from ..params import FIRMS_BASE_URL, FIRMS_SOURCES, INDONESIA_BBOX


class FIRMSDownloader:
    def __init__(self, map_key=None, output_dir=None):
        self.map_key = map_key
        self.output_dir = output_dir or tempfile.mkdtemp()

    def download_hotspot(self, area_coords=None, day_range=1, source="VIIRS_SNPP_NRT",
                         date=None, progress_callback=None):
        import requests

        if not self.map_key:
            return {
                "error": "NASA FIRMS MAP_KEY belum dikonfigurasi!\n\n"
                         "Cara mendapatkan MAP_KEY:\n"
                         "1. Buka https://firms.modaps.eosdis.nasa.gov/api/map_key\n"
                         "2. Daftar atau login\n"
                         "3. Generate MAP_KEY\n"
                         "4. Masukkan melalui menu Pantau Langit > Pengaturan API"
            }

        if area_coords is None:
            area_coords = INDONESIA_BBOX

        area_str = ",".join(str(c) for c in area_coords)

        if date:
            url = f"{FIRMS_BASE_URL}/csv/{self.map_key}/{source}/{area_str}/{day_range}/{date}"
        else:
            url = f"{FIRMS_BASE_URL}/csv/{self.map_key}/{source}/{area_str}/{day_range}"

        try:
            if progress_callback:
                progress_callback(10, "Menghubungi NASA FIRMS API...")

            response = requests.get(url, timeout=180)

            if response.status_code == 400:
                return {"error": f"Permintaan tidak valid: {response.text[:200]} "
                                 f"(rentang hari FIRMS NRT: 1-5)"}
            if response.status_code == 401:
                return {"error": "MAP_KEY tidak valid. Silakan periksa MAP_KEY Anda."}
            if response.status_code == 429:
                return {"error": "Batas request tercapai. Tunggu 10 menit dan coba lagi."}
            if response.status_code == 500:
                return {"error": "Server FIRMS sedang bermasalah. Coba lagi nanti."}
            response.raise_for_status()

            if progress_callback:
                progress_callback(50, "Memproses data hotspot...")

            csv_text = response.text
            reader = csv.DictReader(io.StringIO(csv_text))
            hotspots = []
            for row in reader:
                try:
                    hotspots.append({
                        "lat": float(row.get("latitude", 0)),
                        "lng": float(row.get("longitude", 0)),
                        "brightness": float(row.get("brightness", 0) or 0),
                        "frp": float(row.get("frp", 0) or 0),
                        "confidence": row.get("confidence", ""),
                        "acq_date": row.get("acq_date", ""),
                        "acq_time": row.get("acq_time", ""),
                        "satellite": row.get("satellite", ""),
                        "daynight": row.get("daynight", ""),
                    })
                except (ValueError, TypeError):
                    continue

            if progress_callback:
                progress_callback(80, f"Ditemukan {len(hotspots)} hotspot...")

            stamp = date or "latest"
            output_file = os.path.join(
                self.output_dir,
                f"hotspot_{source}_{stamp}.csv",
            )
            with open(output_file, "w", newline="", encoding="utf-8") as f:
                f.write(csv_text)

            if progress_callback:
                progress_callback(100, f"Download hotspot selesai ({len(hotspots)} titik)")

            return {
                "file": output_file,
                "hotspots": hotspots,
                "count": len(hotspots),
            }
        except requests.exceptions.ConnectionError:
            return {"error": "Gagal terhubung ke server FIRMS. Periksa koneksi internet Anda."}
        except requests.exceptions.Timeout:
            return {"error": "Koneksi timeout. Periksa koneksi internet Anda."}
        except Exception as e:
            return {"error": f"Gagal mengunduh hotspot: {str(e)[:300]}"}

    @staticmethod
    def source_list():
        """Daftar (id, label) sumber FIRMS untuk UI."""
        return [(v[0], v[1]) for v in FIRMS_SOURCES.values()]
