"""Downloader Copernicus CAMS (Atmosphere Data Store) via cdsapi."""

import os
import tempfile
import threading
import time
from datetime import datetime, timedelta

from ..params import (
    CAMS_DATASET_CONFIG,
    CAMS_LEADTIME_HIST,
    CAMS_LEADTIME_KINI,
    CAMS_PARAM_DEFS,
    cams_area,
)

# CDS memproses request dalam antrian; status "accepted/queued" bisa bertahan
# lama tanpa pesan apa pun. Heartbeat menampilkan proses tetap berjalan dan
# RETRIEVE_TIMEOUT_S membatasi waktu tunggu agar tidak macet selamanya.
RETRIEVE_TIMEOUT_S = 60 * 60      # batas tunggu 1 request CDS (detik)
HEARTBEAT_S = 15                  # interval indikator "masih hidup" (detik)
HEARTBEAT_LOG_S = 60              # interval pesan log "masih berjalan" (detik)


class CAMSDownloader:
    def __init__(self, api_key=None, api_url=None, output_dir=None):
        self.api_key = api_key
        self.api_url = api_url
        self.output_dir = output_dir or tempfile.mkdtemp()
        self._client = None
        self._info_hook = None   # callable(msg): penerima pesan status CDS

    def _dispatch(self, *args, **kwargs):
        """Teruskan pesan info/warning/error cdsapi ke hook parameter aktif."""
        try:
            msg = args[0] % args[1:] if len(args) > 1 else str(args[0])
        except Exception:
            msg = " ".join(str(a) for a in args)
        hook = self._info_hook
        if hook:
            try:
                hook(str(msg)[:200])
            except Exception:
                pass

    def _get_client(self):
        if self._client is None:
            if not self.api_key:
                raise RuntimeError(
                    "CDS API Key belum dikonfigurasi!\n\n"
                    "Cara mendapatkan API Key:\n"
                    "1. Buka https://cds.climate.copernicus.eu/how-to-api\n"
                    "2. Login atau buat akun Copernicus\n"
                    "3. Copy API Key Anda\n"
                    "4. Masukkan melalui menu Pantau Langit > Pengaturan API"
                )
            try:
                import cdsapi
            except ImportError as e:
                raise RuntimeError(
                    f"Modul cdsapi tidak tersedia di Python QGIS: {e}\n"
                    "Pastikan folder vendor plugin terpasang dengan benar."
                )

            kwargs = dict(
                key=self.api_key,
                retry_max=3,
                sleep_max=30,
                timeout=300,
                quiet=True,
                progress=False,
                info_callback=self._dispatch,
                warning_callback=self._dispatch,
                error_callback=self._dispatch,
            )
            if self.api_url:
                kwargs["url"] = self.api_url
            try:
                self._client = cdsapi.Client(**kwargs)
            except Exception as e:
                raise RuntimeError(f"Gagal membuat CDS API client: {e}")
        return self._client

    @staticmethod
    def build_request(param_key, start_date, end_date, area=None,
                      leadtime_hour=None, time=None):
        """Susun request CDS untuk satu parameter.

        leadtime_hour / time menimpa nilai bawaan dataset (dipakai untuk
        pembagian tanggal sebelumnya vs tanggal terkini).
        Mengembalikan (request_params, dataset, (nc_var, label)).
        """
        if param_key not in CAMS_PARAM_DEFS:
            return None, None, None
        variable, pressure_level, nc_var, label, dataset = CAMS_PARAM_DEFS[param_key]
        ds_cfg = CAMS_DATASET_CONFIG.get(dataset, {})

        request_params = {
            "variable": [variable],
            "date": f"{start_date}/{end_date}",
            "leadtime_hour": list(leadtime_hour or ds_cfg.get(
                "leadtime_hour",
                ["0", "3", "6", "9", "12", "24", "36", "48", "72", "96"],
            )),
            "data_format": ds_cfg.get("data_format", "netcdf"),
        }
        if ds_cfg.get("include_time_type", True):
            request_params["time"] = list(time or ["00:00", "12:00"])
            request_params["type"] = ["forecast"]
        if area:
            request_params["area"] = cams_area(area) if len(area) == 4 else area
        if pressure_level:
            request_params["pressure_level"] = [pressure_level]
        return request_params, dataset, (nc_var, label)

    @staticmethod
    def _error_message(label, error_msg):
        """Terjemahkan error HTTP/umum ke pesan yang bisa ditindaklanjuti."""
        low = str(error_msg).lower()
        detail = ""
        if "400" in str(error_msg):
            detail = str(error_msg)
        if "invalid key names" in low:
            return (f"Request {label} tidak cocok dengan dataset CDS: {detail[:300]}")
        if "not produced a valid combination" in low:
            return (f"Kombinasi nilai request {label} tidak valid menurut CDS. "
                    f"Pastikan parameter level tekanan/varian produk sudah benar. "
                    f"Detail: {detail[:300]}")
        if "401" in str(error_msg) or "unauthorized" in low or "invalid key" in low:
            return "API Key tidak valid. Silakan periksa API Key Anda."
        if "404" in str(error_msg) or "not found" in low:
            return ("Dataset tidak ditemukan. Pastikan Anda sudah terdaftar "
                    "dan menerima syarat lisensi dataset di CDS.")
        if "terms" in low or "licen" in low:
            return (f"Anda perlu menerima syarat lisensi dataset di CDS: "
                    f"{str(error_msg)[:300]}")
        if "500" in str(error_msg):
            return "Server CDS sedang bermasalah. Coba lagi nanti."
        if "timed out" in low or "timeout" in low:
            return "Koneksi timeout. Periksa koneksi internet Anda."
        return f"Gagal mengunduh {label}: {str(error_msg)[:400]}"

    def _retrieve_with_heartbeat(self, dataset, request_params, output_file,
                                 label, state, progress_callback=None,
                                 log_callback=None, base_pct=15):
        """Jalankan client.retrieve dengan indikator hidup + batas waktu.

        Selama request berada di antrian CDS (accepted/queued/running) tidak
        ada pesan dari cdsapi; heartbeat menampilkan status + waktu tunggu
        agar proses terlihat berjalan, dan melempar TimeoutError bila melewati
        RETRIEVE_TIMEOUT_S.
        """
        result = {}

        def run():
            try:
                result["data"] = self._get_client().retrieve(
                    dataset, request_params, output_file)
            except BaseException as e:  # noqa: BLE001 - diteruskan ke pemanggil
                result["error"] = e

        thread = threading.Thread(target=run, daemon=True)
        thread.start()

        start = time.time()
        last_log = 0.0
        while thread.is_alive():
            thread.join(HEARTBEAT_S)
            if not thread.is_alive():
                break
            elapsed = time.time() - start
            mm, ss = divmod(int(elapsed), 60)
            status = state.get("text") or "dikirim"
            if progress_callback:
                progress_callback(
                    base_pct,
                    f"{label}: menunggu CDS {mm}m{ss:02d}s — {status}")
            if log_callback and elapsed - last_log >= HEARTBEAT_LOG_S:
                last_log = elapsed
                log_callback(f"   {label}: masih berjalan ({mm} menit) — {status}")
            if elapsed >= RETRIEVE_TIMEOUT_S:
                raise TimeoutError(
                    f"CDS tidak menyelesaikan request dalam "
                    f"{RETRIEVE_TIMEOUT_S // 60} menit (status terakhir: "
                    f"{status}). Coba lagi nanti atau perkecil rentang tanggal.")
        if "error" in result:
            raise result["error"]
        return result.get("data")

    def download_parameter(self, param_key, start_date, end_date, area=None,
                           progress_callback=None, log_callback=None):
        if param_key not in CAMS_PARAM_DEFS:
            return {"error": f"Parameter tidak dikenal: {param_key}"}

        # Pembagian tanggal: tanggal sebelumnya -> waktu valid s/d 21.00
        # (run 00 & 12 UTC, leadtime s/d +9h); tanggal terakhir (terkini)
        # -> leadtime s/d +96h (prediksi kurang lebih 3 hari ke depan).
        d0 = datetime.strptime(start_date, "%Y-%m-%d")
        d1 = datetime.strptime(end_date, "%Y-%m-%d")
        if d1 < d0:
            return {"error": "Tanggal mulai harus sebelum tanggal akhir."}
        os.makedirs(self.output_dir, exist_ok=True)
        groups = []
        if d0 < d1:
            groups.append((start_date,
                           (d1 - timedelta(days=1)).strftime("%Y-%m-%d"),
                           CAMS_LEADTIME_HIST, "hist"))
        groups.append((end_date, end_date, CAMS_LEADTIME_KINI, "kini"))

        _req, dataset, (nc_var, label) = self.build_request(
            param_key, start_date, end_date, area
        )

        ds_cfg = CAMS_DATASET_CONFIG.get(dataset, {})
        ext = ".zip" if ds_cfg.get("data_format") == "netcdf_zip" else ".nc"
        safe_name = param_key.replace("_", "-")

        state = {"text": "mengirim request"}

        def info(msg):
            text = str(msg)[:200]
            state["text"] = text
            if progress_callback:
                progress_callback(15, text)
            if log_callback and text.lower().startswith("request is"):
                log_callback(f"   CDS: {text}")

        self._info_hook = info
        try:
            if progress_callback:
                progress_callback(5, f"Menghubungi CDS API untuk {label}...")
            self._get_client()

            files = []
            windows = []
            for gi, (g_start, g_end, lead, suffix) in enumerate(groups):
                request_params, _ds, _nc = self.build_request(
                    param_key, g_start, g_end, area, leadtime_hour=lead)
                output_file = os.path.join(
                    self.output_dir, f"{safe_name}-{suffix}{ext}")
                if progress_callback:
                    progress_callback(
                        10 + gi * 40,
                        f"Mengunduh {label} [{g_start} s/d {g_end}]...")
                self._retrieve_with_heartbeat(
                    dataset, request_params, output_file,
                    f"{label} [{g_start} s/d {g_end}]", state,
                    progress_callback=progress_callback,
                    log_callback=log_callback, base_pct=10 + gi * 40)

                if not os.path.exists(output_file):
                    return {"error": f"File hasil tidak ditemukan untuk {label}"}
                files.append(output_file)
                max_lead = max(int(x) for x in lead)
                if suffix == "hist":
                    desc = "waktu valid 00:00 s/d 21:00"
                else:
                    desc = (f"waktu valid s/d +{max_lead}h "
                            f"(prediksi kurang lebih 3 hari ke depan)")
                windows.append(f"{g_start} s/d {g_end} | {desc}")

            if progress_callback:
                progress_callback(100, f"Download {label} selesai")

            return {
                "file": files[0],
                "files": files,
                "param_key": param_key,
                "nc_var": nc_var,
                "label": label,
                "dataset": dataset,
                "time_windows": windows,
            }
        except RuntimeError as e:
            return {"error": str(e)}
        except Exception as e:
            error_msg = str(e)
            resp = getattr(e, "response", None)
            if resp is not None:
                try:
                    body = resp.json()
                    detail = body.get("detail") or body.get("title") or body.get("message")
                    if detail:
                        error_msg = f"{error_msg} | {detail}"
                except Exception:
                    try:
                        if resp.text:
                            error_msg = f"{error_msg} | {resp.text[:300]}"
                    except Exception:
                        pass
            return {"error": self._error_message(label, error_msg)}
        finally:
            self._info_hook = None

    def download_selected(self, selected_params, start_date, end_date, area=None,
                          progress_callback=None, log_callback=None):
        results = {}
        total = max(len(selected_params), 1)
        for i, param_key in enumerate(selected_params):
            if progress_callback:
                pct = int(i / total * 100)
                progress_callback(pct, f"Mengunduh {param_key} ({i + 1}/{total})...")
            results[param_key] = self.download_parameter(
                param_key, start_date, end_date, area,
                progress_callback=lambda p, m, _i=i, _t=total: (
                    progress_callback(int((_i + p / 100.0) / _t * 100), m)
                    if progress_callback else None
                ),
                log_callback=log_callback,
            )
        return results
