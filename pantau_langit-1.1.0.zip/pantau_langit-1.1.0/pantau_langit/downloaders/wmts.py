"""Pembuat URI WMTS NASA GIBS + unduh citra AOI menjadi GeoTIFF."""

import math
import os

import numpy as np

from ..params import GIBS_LAYERS, GIBS_WMTS_URL

# Web-Mercator / GoogleMapsCompatible
MERC_HALF = 20037508.342789244
TILE_PX = 256
MAX_TILES = 256


def gibs_groups():
    """Kelompokkan layer GIBS untuk UI: [(group, [(key, label), ...]), ...]."""
    groups = {}
    for key, cfg in GIBS_LAYERS.items():
        groups.setdefault(cfg["group"], []).append((key, cfg["label"]))
    return list(groups.items())


def time_value(gibs_key, date_str, time_str="00:00"):
    cfg = GIBS_LAYERS.get(gibs_key) or {}
    if cfg.get("time_type") == "date":
        return date_str
    return f"{date_str}T{time_str or '00:00'}:00Z"


def build_wmts_uri(gibs_key, date_str, time_str="00:00"):
    """Susun data-source URI QGIS (provider 'wms') untuk layer GIBS."""
    cfg = GIBS_LAYERS.get(gibs_key)
    if not cfg:
        return None

    return (
        f"contextualWMSLegend=0&crs=EPSG:3857&format={cfg['format']}"
        f"&layers={cfg['layer']}&styles=&tileMatrixSet={cfg['matrix_set']}"
        f"&time={time_value(gibs_key, date_str, time_str)}&url={GIBS_WMTS_URL}"
    )


def layer_display_name(gibs_key, date_str):
    cfg = GIBS_LAYERS.get(gibs_key) or {}
    group = (cfg.get("group") or "").split("(")[0].strip()
    return f"Satelit | {group} | {cfg.get('label', gibs_key)} ({date_str})"


# ---------------------------------------------------------------------------
# Jam pengamatan yang tersedia (dari katalog WMTS GIBS)
# ---------------------------------------------------------------------------
_CAPS_CACHE = {"xml": None}


def _gibs_capabilities():
    import requests

    if _CAPS_CACHE["xml"] is None:
        resp = requests.get(
            GIBS_WMTS_URL,
            params={"SERVICE": "WMTS", "REQUEST": "GetCapabilities"},
            timeout=120,
        )
        resp.raise_for_status()
        _CAPS_CACHE["xml"] = resp.text
    return _CAPS_CACHE["xml"]


def _parse_ts(text):
    """Parse ISO timestamp (dengan/tanpa 'Z' & milidetik)."""
    from datetime import datetime

    t = str(text).strip().rstrip("Z")
    if "." in t:
        t = t.split(".")[0]
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(t[:19] if "T" in fmt else t[:10], fmt)
        except ValueError:
            continue
    raise ValueError(f"timestamp tidak dikenal: {text}")


def _parse_iso_duration(text):
    from datetime import timedelta
    import re

    m = re.match(r"^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$",
                 str(text).strip())
    if not m:
        raise ValueError(f"durasi tidak dikenal: {text}")
    days, hours, mins, secs = (int(g) if g else 0 for g in m.groups())
    return timedelta(days=days, hours=hours, minutes=mins, seconds=secs)


def _expand_on_date(value, want_date):
    """Nilai dimensi waktu GIBS -> daftar datetime pada tanggal tertentu.

    Format nilai: 'instant' | 'awal/akhir' | 'awal/akhir/PERIOD' (ISO8601).
    """
    import math
    from datetime import datetime, timedelta

    parts = [p.strip() for p in str(value).split("/")]
    try:
        if len(parts) == 1:
            dt = _parse_ts(parts[0])
            return [dt] if dt.date() == want_date else []
        start, end = _parse_ts(parts[0]), _parse_ts(parts[1])
        delta = (_parse_iso_duration(parts[2]) if len(parts) >= 3
                 else timedelta(days=1))
        if delta.total_seconds() <= 0:
            return []
        day_start = datetime.combine(want_date, datetime.min.time())
        day_end = day_start + timedelta(days=1)
        out = []
        if delta < timedelta(days=1):
            # grid sub-harian: mulai dari kelipatan terdekat <= awal hari
            gap = (day_start - start).total_seconds()
            k = math.floor(gap / delta.total_seconds())
            t = start + delta * k
            while t < day_end and t <= end and len(out) < 2000:
                if t >= day_start and t >= start:
                    out.append(t)
                t += delta
        else:
            t = start
            while t <= end and len(out) < 2000:
                if t.date() == want_date:
                    out.append(t)
                t += delta
        return out
    except Exception:
        return []


def fetch_available_times(gibs_key, date_str):
    """Daftar jam pengamatan (HH:MM UTC) yang tersedia untuk layer & tanggal.

    Sumber: dimensi waktu pada GetCapabilities WMTS GIBS. Untuk layer harian
    mengembalikan ['00:00'] bila tanggal tersedia, selain itu [].
    """
    import xml.etree.ElementTree as ET

    cfg = GIBS_LAYERS.get(gibs_key)
    if not cfg:
        return []
    try:
        root = ET.fromstring(_gibs_capabilities())
    except Exception:
        return []

    want = _parse_ts(date_str).date()
    times = []
    for layer in root.iter():
        if not layer.tag.endswith("}Layer") and not layer.tag.endswith("Layer"):
            continue
        ident = None
        for child in layer:
            if child.tag.endswith("Identifier"):
                ident = child.text
                break
        if ident != cfg["layer"]:
            continue
        for elem in layer.iter():
            if not elem.tag.endswith("Dimension"):
                continue
            for val in elem:
                if val.text:
                    for dt in _expand_on_date(val.text, want):
                        times.append(dt)
        break

    return sorted({dt.strftime("%H:%M") for dt in times})


# ---------------------------------------------------------------------------
# Unduh tile dalam AOI -> GeoTIFF
# ---------------------------------------------------------------------------
def _bbox_to_merc(bbox):
    """bbox [W,S,E,N] derajat -> (xmin, ymin, xmax, ymax) EPSG:3857."""
    def to_merc(lon, lat):
        lat = max(min(lat, 85.05112878), -85.05112878)
        x = lon * MERC_HALF / 180.0
        y = math.log(math.tan((90.0 + lat) * math.pi / 360.0)) \
            / (math.pi / 180.0) * MERC_HALF / 180.0
        return x, y

    w, s, e, n = bbox
    x0, y1 = to_merc(w, n)
    x1, y0 = to_merc(e, s)
    return x0, y0, x1, y1


def _tile_url(cfg, z, x, y, time_str):
    return (
        f"{GIBS_WMTS_URL}?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0"
        f"&LAYER={cfg['layer']}&STYLE=default&TILEMATRIXSET={cfg['matrix_set']}"
        f"&FORMAT={cfg['format']}&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}"
        f"&TIME={time_str}"
    )


def _is_blank_tile(img):
    """Tile gelap polos dianggap tanpa data (malam / kosong)."""
    try:
        return max(hi for lo, hi in img.getextrema()) <= 5
    except Exception:
        return False


def _fetch_tile(session, cfg, z, x, y, tval, cache, retries=3):
    """Ambil satu tile GIBS (dengan retry) -> PIL Image RGB atau None."""
    import io
    import time

    from PIL import Image

    key = (z, x, y)
    if key in cache:
        return cache[key]
    img = None
    url = _tile_url(cfg, z, x, y, tval)
    for attempt in range(retries):
        try:
            resp = session.get(url, timeout=60)
            if resp.status_code == 200 and resp.content:
                im = Image.open(io.BytesIO(resp.content)).convert("RGB")
                if im.size != (TILE_PX, TILE_PX):
                    im = im.resize((TILE_PX, TILE_PX), Image.BILINEAR)
                img = im
                break
        except Exception:
            pass
        if attempt + 1 < retries:
            time.sleep(1.0)
    cache[key] = img
    return img


def _parent_fill(session, cfg, z, tx, ty, tval, cache):
    """Cari tile induk terdekat yang berisi data untuk mengisi lubang tile.

    Kuadran anak di-crop dari tile induk lalu diperbesar, sehingga area yang
    tadinya blank terisi citra (lebih kasar) alih-alih hitam polos.
    """
    from PIL import Image

    for pz in range(z - 1, -1, -1):
        shift = z - pz
        pimg = _fetch_tile(session, cfg, pz, tx >> shift, ty >> shift,
                           tval, cache)
        if pimg is None or _is_blank_tile(pimg):
            continue
        k = 2 ** shift
        qx, qy = tx % k, ty % k
        sub = TILE_PX / float(k)
        left = round(qx * sub)
        upper = round(qy * sub)
        right = max(left + 1, round((qx + 1) * sub))
        lower = max(upper + 1, round((qy + 1) * sub))
        try:
            quad = pimg.crop((left, upper, right, lower))
            return quad.resize((TILE_PX, TILE_PX), Image.BILINEAR)
        except Exception:
            continue
    return None


def fetch_aoi_geotiff(gibs_key, bbox, date_str, time_str="00:00",
                      out_dir=None, progress_callback=None, max_tiles=MAX_TILES,
                      zoom=None):
    """Unduh tile GIBS yang menutup bbox dan gabungkan menjadi GeoTIFF EPSG:3857.

    bbox: [W, S, E, N] derajat.
    zoom: paksa level zoom tertentu (0 s/d batas layer) untuk resolusi paling
          detail; None = otomatis (zoom terdalam yang muat anggaran tile).
    return dict {file, tiles, tiles_ok, tiles_empty, zoom, crs} atau {error}.
    """
    import io

    import requests
    from PIL import Image

    cfg = GIBS_LAYERS.get(gibs_key)
    if not cfg:
        return {"error": f"Layer GIBS tidak dikenal: {gibs_key}"}
    if not bbox:
        return {"error": "AOI belum dipilih"}

    try:
        z_max = int(str(cfg["matrix_set"]).rsplit("Level", 1)[-1])
    except (ValueError, IndexError):
        z_max = 8

    x0, y0, x1, y1 = _bbox_to_merc(bbox)

    def tile_range(z):
        n = 2 ** z
        span = 2.0 * MERC_HALF
        tx0 = int((x0 + MERC_HALF) / span * n)
        tx1 = int((x1 + MERC_HALF) / span * n)
        ty0 = int((MERC_HALF - y1) / span * n)
        ty1 = int((MERC_HALF - y0) / span * n)
        tx0 = max(0, min(tx0, n - 1))
        tx1 = max(0, min(tx1, n - 1))
        ty0 = max(0, min(ty0, n - 1))
        ty1 = max(0, min(ty1, n - 1))
        return tx0, ty0, tx1, ty1

    if zoom is not None:
        # zoom dipaksa pengguna (dibatasi kemampuan layer)
        z = max(0, min(int(zoom), z_max))
        tx0, ty0, tx1, ty1 = tile_range(z)
        n_tiles = (tx1 - tx0 + 1) * (ty1 - ty0 + 1)
        if n_tiles == 0:
            return {"error": "AOI tidak menutup tile manapun"}
        if n_tiles > 4096:
            return {"error": (
                f"Zoom z{z} membutuhkan {n_tiles} tile (batas 4096). "
                f"Perkecil AOI atau pilih zoom lebih rendah.")}
        if progress_callback and z != z_max:
            progress_callback(4, f"Zoom z{z} (maks layer z{z_max})")
    else:
        # zoom otomatis: terdalam yang masih muat anggaran tile
        z = z_max
        while z > 0:
            tx0, ty0, tx1, ty1 = tile_range(z)
            if (tx1 - tx0 + 1) * (ty1 - ty0 + 1) <= max_tiles:
                break
            z -= 1
        tx0, ty0, tx1, ty1 = tile_range(z)
        n_tiles = (tx1 - tx0 + 1) * (ty1 - ty0 + 1)
        if n_tiles == 0:
            return {"error": "AOI tidak menutup tile manapun"}

    if progress_callback:
        progress_callback(5, f"Mengunduh {n_tiles} tile GIBS (z{z})...")

    tval = time_value(gibs_key, date_str, time_str)
    width = (tx1 - tx0 + 1) * TILE_PX
    height = (ty1 - ty0 + 1) * TILE_PX
    mode = "RGB"
    mosaic = Image.new(mode, (width, height), (0, 0, 0, 0))

    session = requests.Session()
    tile_cache = {}
    done = 0
    tiles_ok = 0
    tiles_empty = 0
    tiles_filled = 0
    for ty in range(ty0, ty1 + 1):
        for tx in range(tx0, tx1 + 1):
            if progress_callback:
                progress_callback(5 + int(done / max(n_tiles, 1) * 70),
                                  f"Tile {done + 1}/{n_tiles}")
            done += 1
            img = _fetch_tile(session, cfg, z, tx, ty, tval, tile_cache)
            if img is not None and not _is_blank_tile(img):
                tiles_ok += 1
            else:
                if img is not None:
                    tiles_empty += 1
                # tile hilang/gelap -> isi dari tile induk agar tidak blank
                img = _parent_fill(session, cfg, z, tx, ty, tval, tile_cache)
                if img is not None and not _is_blank_tile(img):
                    tiles_filled += 1
                else:
                    img = None
            if img is None:
                continue
            mosaic.paste(img, ((tx - tx0) * TILE_PX, (ty - ty0) * TILE_PX))

    layer_name = str(cfg.get("layer", "")).lower()
    is_visible = any(tok in layer_name for tok in
                     ("visible", "truecolor", "correctedreflectance",
                      "naturalcolor", "red_visible"))
    if tiles_ok + tiles_filled == 0:
        if is_visible:
            return {"error": (
                "Citra gelap/kosong — produk tampak-terlihat (Visible/"
                "TrueColor) hanya memiliki data pada siang hari. "
                "Untuk Indonesia, pilih jam pengamatan sekitar 23:00-13:00 UTC "
                "(06:00-20:00 WIB).")}
        return {"error": "Citra tidak tersedia pada tanggal/wilayah tersebut "
                         "(semua tile kosong). Coba tanggal lain."}

    if progress_callback:
        progress_callback(80, "Menyusun GeoTIFF...")

    out_dir = out_dir or os.getcwd()
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(
        out_dir, f"satelit_{gibs_key}_{date_str.replace('-', '')}_z{z}.tif")

    n = 2 ** z
    span = 2.0 * MERC_HALF
    px_size = span / (n * TILE_PX)
    west = -MERC_HALF + tx0 * TILE_PX * px_size
    north = MERC_HALF - ty0 * TILE_PX * px_size

    from osgeo import gdal, osr

    drv = gdal.GetDriverByName("GTiff")
    ds = drv.Create(out_path, width, height, 3, gdal.GDT_Byte,
                    options=["COMPRESS=LZW", "PHOTOMETRIC=RGB"])
    ds.SetGeoTransform((west, px_size, 0.0, north, 0.0, -px_size))
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(3857)
    ds.SetProjection(srs.ExportToWkt())
    arr = np.array(mosaic)
    for b in range(3):
        ds.GetRasterBand(b + 1).WriteArray(arr[:, :, b])
    ds.FlushCache()
    ds = None

    # potong tepat ke bbox AOI
    try:
        xmin, ymin, xmax, ymax = x0, y0, x1, y1
        cropped = gdal.Warp("", out_path, format="MEM",
                            outputBounds=(xmin, ymin, xmax, ymax),
                            dstSRS="EPSG:3857")
        if cropped and cropped.RasterXSize > 0:
            ds = drv.CreateCopy(out_path, cropped)
            ds = None
    except Exception:
        pass

    if progress_callback:
        progress_callback(
            100,
            f"Satelit AOI selesai ({tiles_ok}/{n_tiles} tile"
            + (f", {tiles_filled} diisi dari tile induk" if tiles_filled else "")
            + (f", {tiles_empty} gelap/kosong" if tiles_empty else "") + ")")

    return {"file": out_path, "tiles": n_tiles, "tiles_ok": tiles_ok,
            "tiles_filled": tiles_filled, "tiles_empty": tiles_empty,
            "zoom": z, "crs": "EPSG:3857",
            "layer": cfg["layer"], "time": tval}
