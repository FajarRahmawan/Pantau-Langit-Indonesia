"""Downloader cuaca NOAA GFS via NOMADS filter CGI (GRIB2)."""

import os
import tempfile
from datetime import datetime, timedelta

from ..params import GFS_BASE_URL, GFS_WAVE_URL, WEATHER_PARAMS


class GFSDownloader:
    def __init__(self, output_dir=None):
        self.output_dir = output_dir or tempfile.mkdtemp()

    @staticmethod
    def _build_request(weather_key, date_str, bbox):
        cfg = WEATHER_PARAMS.get(weather_key)
        if not cfg:
            return None, None
        cycle = "00"
        hour = cfg.get("forecast_hour", "000")
        if cfg["endpoint"] == "wave":
            url = GFS_WAVE_URL
            file_name = f"gfswave.t{cycle}z.global.0p25.f{hour}.grib2"
            dir_path = f"/gfs.{date_str}/{cycle}/wave/gridded"
        else:
            url = GFS_BASE_URL
            file_name = f"gfs.t{cycle}z.pgrb2.0p25.f{hour}"
            dir_path = f"/gfs.{date_str}/{cycle}/atmos"

        west, south, east, north = bbox
        params = {
            "file": file_name,
            "dir": dir_path,
            f"lev_{cfg['level']}": "on",
            "subregion": "",
            "leftlon": str(west),
            "rightlon": str(east),
            "toplat": str(north),
            "bottomlat": str(south),
        }
        for key in cfg["keys"]:
            params[f"var_{key}"] = "on"
        return url, params

    def download_data(self, weather_key, start_date, end_date, bbox=None,
                      progress_callback=None):
        import requests

        cfg = WEATHER_PARAMS.get(weather_key)
        if not cfg:
            return {"error": f"Parameter cuaca tidak dikenal: {weather_key}"}

        if bbox is None:
            bbox = (95.0, -11.0, 141.0, 6.0)

        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
        except ValueError:
            return {"error": "Format tanggal harus YYYY-MM-DD"}

        dates = []
        current = start
        while current <= end:
            dates.append(current)
            current += timedelta(days=1)

        downloaded_files = []
        errors = []
        total = max(len(dates), 1)

        for i, dt in enumerate(dates):
            date_str = dt.strftime("%Y%m%d")
            if progress_callback:
                progress_callback(
                    int(i / total * 100),
                    f"Mengunduh {cfg['label']} {dt.strftime('%Y-%m-%d')}...",
                )

            url, params = self._build_request(weather_key, date_str, bbox)
            output_file = os.path.join(
                self.output_dir,
                f"noaa_gfs_{weather_key}_{date_str}.grib2",
            )

            try:
                resp = requests.get(url, params=params, timeout=180)
                if resp.status_code == 200 and resp.content[:4] == b"GRIB" \
                        and len(resp.content) > 100:
                    with open(output_file, "wb") as f:
                        f.write(resp.content)
                    downloaded_files.append(output_file)
                else:
                    errors.append(f"{dt.strftime('%Y-%m-%d')}: data tidak tersedia")
            except requests.exceptions.ConnectionError:
                errors.append(f"{dt.strftime('%Y-%m-%d')}: koneksi gagal")
            except requests.exceptions.Timeout:
                errors.append(f"{dt.strftime('%Y-%m-%d')}: timeout")
            except Exception as e:
                errors.append(f"{dt.strftime('%Y-%m-%d')}: {str(e)[:100]}")

        if progress_callback:
            progress_callback(100, f"{cfg['label']} selesai ({len(downloaded_files)} file)")

        if not downloaded_files:
            return {"error": f"Tidak ada data {cfg['label']} yang tersedia. "
                             + "; ".join(errors[:3])}

        return {
            "files": downloaded_files,
            "weather_key": weather_key,
            "label": cfg["label"],
            "sym": cfg.get("sym"),
            "errors": errors,
        }

    def download_selected(self, selected_keys, start_date, end_date, bbox=None,
                          progress_callback=None):
        results = {}
        total = max(len(selected_keys), 1)
        for i, key in enumerate(selected_keys):
            if progress_callback:
                progress_callback(
                    int(i / total * 100),
                    f"Mengunduh {WEATHER_PARAMS.get(key, {}).get('label', key)} "
                    f"({i + 1}/{total})...",
                )
            results[key] = self.download_data(key, start_date, end_date, bbox)
        return results
