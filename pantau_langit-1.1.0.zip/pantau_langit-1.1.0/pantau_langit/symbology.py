"""Symbology baku mengikuti chart resmi CAMS (atmosphere.copernicus.eu).

Palet warna diambil dari database resmi Magics/ECMWF
(github.com/ecmwf/magics -> share/magics/styles/palettes.json, gaya "eccharts"),
yaitu palet yang sama dengan yang dipakai chart web CAMS:

- Total column of methane        : putih -> kuning -> jingga -> maroon (1800-2000 ppbv)
- Total column of carbon monoxide: eccharts_rainbow_blue_brown_14
  (0-30 x10^18 molecules/cm2, breaks 0.5 s/d 6, 10, 20, 30)
- Total column of carbon dioxide : eccharts_rainbow_purple_red_27 [ppmv]
- Total column of NO2/SO2/HCHO   : eccharts_rainbow_blue_brown_14 [10^15 molecules/cm2]
- Total column of ozone          : eccharts_rainbow_black_tan_22 [DU]
- Ozone at surface [ppbv]        : eccharts_yellow_blue_14
- PM2.5/PM10 [µg/m3]             : eccharts_white_green_purple_12
- AOD 550nm                      : eccharts_purple_red_14
- UV index                       : eccharts_rainbow_green_blue_14
- Fire radiative power [W/m2]    : eccharts_red_white_16

Nilai raster dikonversi ke satuan tampilan web (lihat effective_scale_offset).
"""

import os

from qgis.core import QgsColorRampShader

# ---------------------------------------------------------------------------
# Palet resmi eccharts (RGB dari share/magics/styles/palettes.json)
# ---------------------------------------------------------------------------
PAL_BLUE_BROWN_14 = [
    "#9BC7EA", "#009EE0", "#007BBF", "#265BA0", "#269170", "#6BB25B", "#A8C96B",
    "#FFF49B", "#F4D138", "#EAB538", "#DD8740", "#CC3533", "#9B1623", "#561919",
]

PAL_PURPLE_RED_27 = [
    "#5E4FA2", "#4E63AC", "#3D79B6", "#3990BA", "#4EA7B0", "#62BDA7", "#7CCAA5",
    "#94D4A4", "#AEDEA3", "#C6E89F", "#DDF19A", "#ECF7A1", "#F6FBB0", "#FFFEBE",
    "#FFF3AC", "#FEE797", "#FED884", "#FDC574", "#FDB163", "#FA9857", "#F7814C",
    "#F26944", "#E55749", "#D9444D", "#C72E4C", "#B11747", "#9E0142",
]

PAL_YELLOW_BLUE_14 = [
    "#F5FBC2", "#E8F6B1", "#D3EEB3", "#B2E1B6", "#89D1BA", "#65C3BF", "#40B5C4",
    "#2CA1C2", "#1E8ABD", "#216DAF", "#2351A2", "#253997", "#182A7A", "#081D58",
]

PAL_GREEN_BLUE_14 = [
    "#42A631", "#A5C600", "#FFF300", "#FFD700", "#F7B200", "#EF8A00", "#E66900",
    "#E63510", "#E62484", "#B565A5", "#847DB5", "#7BA6FF", "#63BEFF", "#4ADBFF",
]

PAL_WHITE_GREEN_PURPLE_12 = [
    "#FFFFFF", "#EDFAC2", "#CDFFCD", "#99F0B2", "#53BD9F", "#32A696", "#3296B4",
    "#0570B0", "#05508C", "#0A1F96", "#2C0246", "#6A2C5A",
]

PAL_PURPLE_RED_14 = [
    "#D3D7EB", "#A8AFD7", "#8892BF", "#A3A891", "#BEBD65", "#D8D239", "#F3E70B",
    "#F4C60A", "#F6A508", "#F88406", "#F96205", "#FB4103", "#FD2001", "#FF0000",
]

PAL_RED_WHITE_16 = [
    "#350000", "#5F0000", "#890000", "#B30000", "#DD0000", "#FF0800", "#FF3200",
    "#FF5C00", "#FF8600", "#FFB000", "#FFDA00", "#FFFF07", "#FFFF46", "#FFFF85",
    "#FFFFC4", "#FFFFFF",
]

# eccharts_rainbow_black_tan_22 (nama warna WMO -> RGB perkiraan)
PAL_O3_COLUMN = [
    "#000000", "#000080", "#0000FF", "#008B8B", "#87CEEB", "#20B2AA", "#3CB371",
    "#9ACD32", "#C6D300", "#FFFF00", "#FFD700", "#FFA500", "#FF8C00", "#FF4500",
    "#FF0000", "#B22222", "#8B4513", "#954535", "#F5F5DC", "#FFFDD0", "#D2B48C",
]

# Rampa metana chart web (1800 -> 2000 ppbv, putih -> kuning -> jingga -> maroon)
PAL_CH4 = [
    "#FFFFFF", "#FFFEF6", "#FFFDEB", "#FFFAD6", "#FFF6B4", "#FFF08A", "#FFE866",
    "#FFDD47", "#FFCE2E", "#FFBC1C", "#FCA814", "#F5900D", "#EC760A", "#E05A08",
    "#CE4006", "#B82A06", "#9E1A08", "#851208", "#6D0C08", "#580808", "#440508",
]

CH4_LEVELS = [1800 + 10 * i for i in range(21)]          # 1800 .. 2000
CO_TC_LEVELS = ([0.5 * i for i in range(13)] + [10.0, 20.0, 30.0])  # 0..6, 10, 20, 30

# Konstanta fisika untuk konversi satuan
N_AVOGADRO = 6.02214076e23
AIR_COLUMN_MASS = 10329.0     # kg/m2 (P0/g) -> kolom terintegrasi ke rata-rata kolom
MOLAR_MASS_AIR = 28.9644      # g/mol
DU_PER_MOLEC_CM2 = 2.687e20   # 1 DU = 2.687e20 molekul/cm2


def _auto_labels(levels, unit=""):
    suffix = f" {unit}" if unit and unit not in ("-", "~") else ""
    labels = []
    for i in range(len(levels)):
        if i + 1 < len(levels):
            labels.append(f"{levels[i]:g} - {levels[i + 1]:g}{suffix}")
        else:
            labels.append(f"> {levels[i]:g}{suffix}")
    return labels


CAMB_SYMBLOGY = {
    # ------------------------------------------------------------------ CH4
    "ch4": {
        "name": "Methane column-mean molar fraction",
        "layer_name": "CAMS | CH4 [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 16.0425,
        "opacity": 0.85,
        "levels": [
            1800, 1825, 1850, 1875,
            1900, 1925, 1950, 1975,
            2000, 2025
        ],
        "colors": [
            "#F7F8F1", "#FFF8B5", "#F8EB7A", "#F5D74D",
            "#F4BC2D", "#ED931D", "#E76B0D", "#C73D08",
            "#941B0D", "#410719"
        ],
        "labels": [
            "1.800 - 1.825", "1.825 - 1.850", "1.850 - 1.875",
            "1.875 - 1.900", "1.900 - 1.925", "1.925 - 1.950",
            "1.950 - 1.975", "1.975 - 2.000", "2.000 - 2.025 (ujung gradasi)",
            "> 2.025 (warna paling gelap)"
        ],
    },
    # ------------------------------------------------------ CO (kolom & profil)
    "co_tc": {
        "name": "Total column of carbon monoxide",
        "layer_name": "CAMS | Total column CO [10^18 molecules/cm2]",
        "display_unit": "10^18 molecules/cm2",
        "molar_mass": 28.0101,
        "opacity": 0.85,
        "levels": [
            0, 0.5, 1, 1.5,
            2, 2.5, 3, 3.5,
            4, 4.5, 5, 5.5,
            6, 10
        ],
        "colors": [
            "#94C4E4", "#0799D5", "#067ABA", "#225A9B",
            "#238F73", "#63AC5D", "#9FC46D", "#FFF2A1",
            "#F4D536", "#EAB73B", "#DE8840", "#C93637",
            "#911628", "#551719"
        ],
        "labels": [
            "0 - 0,5", "0,5 - 1", "1 - 1,5",
            "1,5 - 2", "2 - 2,5", "2,5 - 3",
            "3 - 3,5", "3,5 - 4", "4 - 4,5",
            "4,5 - 5", "5 - 5,5", "5,5 - 6",
            "6 - 10", "10 - 20"
        ],
    },
    "co": {
        "name": "Carbon monoxide",
        "layer_name": "CAMS | CO [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 28.0101,
        "opacity": 0.85,
        "levels": None,
        "colors": [
            "#94C4E4", "#0799D5", "#067ABA", "#225A9B",
            "#238F73", "#63AC5D", "#9FC46D", "#FFF2A1",
            "#F4D536", "#EAB73B", "#DE8840", "#C93637",
            "#911628", "#551719"
        ],
    },
    # ------------------------------------------------------------- CO2
    "co2": {
        "name": "Carbon dioxide column-mean molar fraction",
        "layer_name": "CAMS | CO2 [ppmv]",
        "display_unit": "ppmv",
        "molar_mass": 44.0095,
        "opacity": 0.85,
        "levels": [
            414, 416.5, 419, 421.5,
            424, 426.5, 429, 431.5,
            434
        ],
        "colors": [
            "#10234A", "#17636B", "#39A19C", "#A7C7AC",
            "#E2DEC9", "#F4C9BA", "#D77676", "#A72C6D",
            "#45113F"
        ],
        "labels": [
            "414 - 416,5", "416,5 - 419", "419 - 421,5",
            "421,5 - 424", "424 - 426,5", "426,5 - 429",
            "429 - 431,5", "431,5 - 434 (mendekati batas atas)", "> 434 (ujung gradasi)"
        ],

    },
    # -------------------------------------------------------- NO2/SO2/HCHO
    "no2_tc": {
        "name": "Total column of nitrogen dioxide",
        "layer_name": "CAMS | Total column NO2 [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 46.0055,
        "opacity": 0.85,
        "levels": [
            1, 1.5, 2, 2.5,
            3, 3.5, 4, 4.5,
            5, 7, 10, 20,
            30, 50
        ],
        "colors": [
            "#96C5E4", "#009BDA", "#007EBB", "#225A9B",
            "#218E77", "#66AD5F", "#A3C46B", "#FFF2A0",
            "#F8D139", "#EAB33B", "#DE8741", "#C8333C",
            "#941A2B", "#56191C"
        ],
        "labels": [
            "1 - 1,5", "1,5 - 2", "2 - 2,5",
            "2,5 - 3", "3 - 3,5", "3,5 - 4",
            "4 - 4,5", "4,5 - 5", "5 - 7",
            "7 - 10", "10 - 20", "20 - 30",
            "30 - 50", "> 50 (ujung gradasi)"
        ],

    },
    "no2": {
        "name": "Nitrogen dioxide",
        "layer_name": "CAMS | NO2 [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 46.0055,
        "opacity": 0.85,
        "levels": None,
        "colors": [
            "#96C5E4", "#009BDA", "#007EBB", "#225A9B",
            "#218E77", "#66AD5F", "#A3C46B", "#FFF2A0",
            "#F8D139", "#EAB33B", "#DE8741", "#C8333C",
            "#941A2B", "#56191C"
        ],
    },
    "so2_tc": {
        "name": "Total column of sulphur dioxide",
        "layer_name": "CAMS | Total column SO2 [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 64.066,
        "opacity": 0.85,
        "levels": [
            0.01, 0.02, 0.05, 0.1,
            0.2, 0.5, 1, 2,
            5, 10, 20, 50,
            100, 999
        ],
        "colors": [
            "#94C4E5", "#0399D8", "#067AB8", "#245B9A",
            "#228E75", "#66AE60", "#A0C372", "#FFF0A0",
            "#F5D03B", "#EAB340", "#DE873F", "#C9343C",
            "#95192B", "#54191A"
        ],
        "labels": [
            "0,01 - 0,02", "0,02 - 0,05", "0,05 - 0,10",
            "0,10 - 0,20", "0,20 - 0,50", "0,50 - 1",
            "1 - 2", "2 - 5", "5 - 10",
            "10 - 20", "20 - 50", "50 - 100",
            "100 - 999", "> 999 (ujung gradasi)"
        ],

    },
    "so2": {
        "name": "Sulphur dioxide",
        "layer_name": "CAMS | SO2 [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 64.066,
        "opacity": 0.85,
        "levels": None,
        "colors": [
            "#94C4E5", "#0399D8", "#067AB8", "#245B9A",
            "#228E75", "#66AE60", "#A0C372", "#FFF0A0",
            "#F5D03B", "#EAB340", "#DE873F", "#C9343C",
            "#95192B", "#54191A"
        ],
    },
    "hcho_tc": {
        "name": "Total column of formaldehyde",
        "layer_name": "CAMS | Total column HCHO [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 30.026,
        "opacity": 0.85,
        "levels": [
            1, 2, 3, 4,
            5, 6, 7, 8,
            9, 10, 15, 20,
            50
        ],
        "colors": [
            "#95C6E6", "#009CDB", "#007EB9", "#235994",
            "#218F75", "#64AD61", "#9DC371", "#FFF2A0",
            "#F8D43E", "#EAB440", "#DC8744", "#C9353D",
            "#94192B"
        ],
        "labels": [
            "1 - 2", "2 - 3", "3 - 4",
            "4 - 5", "5 - 6", "6 - 7",
            "7 - 8", "8 - 9", "9 - 10",
            "10 - 15", "15 - 20", "20 - 50",
            "> 50 (batas atas legenda)"
        ],

    },
    "hcho": {
        "name": "Formaldehyde",
        "layer_name": "CAMS | HCHO [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 30.026,
        "opacity": 0.85,
        "levels": None,
        "colors": [
            "#95C6E6", "#009CDB", "#007EB9", "#235994",
            "#218F75", "#64AD61", "#9DC371", "#FFF2A0",
            "#F8D43E", "#EAB440", "#DC8744", "#C9353D",
            "#94192B"
        ],
    },
    # ------------------------------------------- Hydrocarbons & VOCs (NMVOC)
    "c2h6_tc": {
        "name": "Total column of ethane",
        "layer_name": "CAMS | Total column C2H6 [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 30.07,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c2h6": {
        "name": "Ethane",
        "layer_name": "CAMS | C2H6 [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 30.07,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c2h4_tc": {
        "name": "Total column of ethene",
        "layer_name": "CAMS | Total column C2H4 [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 28.05,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c2h4": {
        "name": "Ethene",
        "layer_name": "CAMS | C2H4 [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 28.05,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c2h5oh_tc": {
        "name": "Total column of ethanol",
        "layer_name": "CAMS | Total column C2H5OH [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 46.07,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c2h5oh": {
        "name": "Ethanol",
        "layer_name": "CAMS | C2H5OH [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 46.07,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c3h8_tc": {
        "name": "Total column of propane",
        "layer_name": "CAMS | Total column C3H8 [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 44.095,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c3h8": {
        "name": "Propane",
        "layer_name": "CAMS | C3H8 [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 44.095,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c3h6_tc": {
        "name": "Total column of propene",
        "layer_name": "CAMS | Total column C3H6 [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 42.08,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c3h6": {
        "name": "Propene",
        "layer_name": "CAMS | C3H6 [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 42.08,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c5h8_tc": {
        "name": "Total column of isoprene",
        "layer_name": "CAMS | Total column C5H8 [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 68.117,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "c5h8": {
        "name": "Isoprene",
        "layer_name": "CAMS | C5H8 [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 68.117,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "acetone_tc": {
        "name": "Total column of acetone",
        "layer_name": "CAMS | Total column Acetone [10^15 molecules/cm2]",
        "display_unit": "10^15 molecules/cm2",
        "molar_mass": 58.08,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    "acetone": {
        "name": "Acetone",
        "layer_name": "CAMS | Acetone [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 58.08,
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_BLUE_BROWN_14,
    },
    # ------------------------------------------------------------------ O3
    "o3_tc": {
        "name": "Total column of ozone",
        "layer_name": "CAMS | Total column O3 [DU]",
        "display_unit": "DU",
        "molar_mass": 47.997,
        "opacity": 0.85,
        "levels": [
            100, 125, 150, 175,
            200, 220, 240, 260,
            280, 300, 320, 340,
            360, 380, 400, 425,
            450
        ],
        "colors": [
            "#070707", "#080B72", "#071FFF", "#1397F0",
            "#79B3F5", "#01E4EC", "#00E78B", "#88F321",
            "#F7FC00", "#FFDC00", "#FFAA00", "#FF7900",
            "#FF4900", "#FF1600", "#AD1A0B", "#741304",
            "#460800"
        ],
        "labels": [
            "100 - 125", "125 - 150", "150 - 175",
            "175 - 200", "200 - 220", "220 - 240",
            "240 - 260", "260 - 280", "280 - 300",
            "300 - 320", "320 - 340", "340 - 360",
            "360 - 380", "380 - 400", "400 - 425",
            "425 - 450", "450 - 475"
        ],

    },
    "o3": {
        "name": "Ozone",
        "layer_name": "CAMS | O3 [ppbv]",
        "display_unit": "ppbv",
        "molar_mass": 47.997,
        "opacity": 0.85,
        "levels": None,
        "colors": [
            "#070707", "#080B72", "#071FFF", "#1397F0",
            "#79B3F5", "#01E4EC", "#00E78B", "#88F321",
            "#F7FC00", "#FFDC00", "#FFAA00", "#FF7900",
            "#FF4900", "#FF1600", "#AD1A0B", "#741304",
            "#460800"
        ],
    },
    # ------------------------------------------------------- PM / aerosol
    "pm2p5": {
        "name": "Fine Particulate Matter",
        "layer_name": "CAMS | PM2.5 [µg/m3]",
        "display_unit": "µg/m3",
        "opacity": 0.80,
        "levels": [
            20, 30, 40, 50,
            60, 80, 100, 150,
            200, 300
        ],
        "colors": [
            "#EFF9C1", "#C9F8CA", "#8BE5AF", "#4FB7A4",
            "#2B9F9C", "#318BAE", "#0273A8", "#12579D",
            "#132C92", "#33065B"
        ],
        "labels": [
            "20 - 30", "30 - 40", "40 - 50",
            "50 - 60", "60 - 80", "80 - 100",
            "100 - 150", "150 - 200", "200 - 300",
            "300 - 500"
        ],
    },
    "pm10": {
        "name": "Coarse Particulate Matter",
        "layer_name": "CAMS | PM10 [µg/m3]",
        "display_unit": "µg/m3",
        "opacity": 0.80,
        "levels": [
            20, 30, 40, 50,
            60, 80, 100, 150,
            200, 300
        ],
        "colors": [
            "#EFF9C1", "#C9F8CA", "#8BE5AF", "#4FB7A4",
            "#2B9F9C", "#318BAE", "#0273A8", "#12579D",
            "#132C92", "#33065B"
        ],
        "labels": [
            "20 - 30", "30 - 40", "40 - 50",
            "50 - 60", "60 - 80", "80 - 100",
            "100 - 150", "150 - 200", "200 - 300",
            "300 - 500"
        ],
    },
    "aod550": {
        "name": "Aerosol Optical Depth at 550nm",
        "layer_name": "CAMS | Aerosol OD 550 nm",
        "display_unit": "-",
        "opacity": 0.80,
        "levels": [
            0.1, 0.16, 0.23, 0.29,
            0.36, 0.42, 0.49, 0.55,
            0.61, 0.68, 0.74, 0.94
        ],
        "colors": [
            "#D2D7E9", "#9BA8CF", "#7B8BBE", "#A2A88E",
            "#C5C55F", "#F1E800", "#F5C500", "#F6A000",
            "#F77A00", "#FC5500", "#FA3100", "#FF0800"
        ],
        "labels": [
            "0,10 - 0,16", "0,16 - 0,23", "0,23 - 0,29",
            "0,29 - 0,36", "0,36 - 0,42", "0,42 - 0,49",
            "0,49 - 0,55", "0,55 - 0,61", "0,61 - 0,68",
            "0,68 - 0,74", "0,74 - 0,94", "0,94 - 3,00"
        ],

    },
    "duaod550": {
        "name": "Dust Aerosol Optical Depth",
        "layer_name": "CAMS | Dust Aerosol OD 550 nm",
        "display_unit": "-",
        "opacity": 0.80,
        "levels": [0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0, 1.5, 2.0],
        "colors": PAL_PURPLE_RED_14,
    },
    "omaod550": {
        "name": "Organic Matter Aerosol OD",
        "layer_name": "CAMS | Organic Matter AOD 550 nm",
        "display_unit": "-",
        "opacity": 0.80,
        "levels": [0.01, 0.02, 0.03, 0.05, 0.07, 0.1, 0.15, 0.2, 0.3, 0.5],
        "colors": PAL_PURPLE_RED_14,
    },
    "ssaod550": {
        "name": "Sea-Salt Aerosol OD",
        "layer_name": "CAMS | Sea-Salt Aerosol OD 550 nm",
        "display_unit": "-",
        "opacity": 0.80,
        "levels": [0.01, 0.02, 0.03, 0.05, 0.07, 0.1, 0.15, 0.2, 0.3, 0.5],
        "colors": PAL_PURPLE_RED_14,
    },
    "suaod550": {
        "name": "Sulphate Aerosol OD",
        "layer_name": "CAMS | Sulphate Aerosol OD 550 nm",
        "display_unit": "-",
        "opacity": 0.80,
        "levels": [0.01, 0.02, 0.03, 0.05, 0.07, 0.1, 0.15, 0.2, 0.3, 0.5],
        "colors": PAL_PURPLE_RED_14,
    },
    # ----------------------------------------------------------- UV & FRP
    "uv": {
        "name": "UV Index",
        "layer_name": "CAMS | UV Index",
        "display_unit": "-",
        "opacity": 0.80,
        "levels": [
            0, 1, 2, 3,
            4, 5, 6, 7,
            8, 9, 10, 11,
            13, 15
        ],
        "colors": [
            "#B6B6B6", "#35A83A", "#A4CC00", "#F5DF00",
            "#FFD000", "#FFAC00", "#FF8700", "#FF5900",
            "#E62A32", "#E51A81", "#B35A9B", "#777DBB",
            "#4CAFE1", "#37C7E7"
        ],
        "labels": [
            "0 - 1", "1 - 2", "2 - 3",
            "3 - 4", "4 - 5", "5 - 6",
            "6 - 7", "7 - 8", "8 - 9",
            "9 - 10", "10 - 11", "11 - 13",
            "13 - 15", "15 - 18"
        ],

    },
    "uvbed": {
        "name": "UV Biologically Effective Dose",
        "layer_name": "CAMS | UV Biologically Effective Dose",
        "display_unit": "-",
        "opacity": 0.80,
        "levels": None,
        "colors": PAL_GREEN_BLUE_14,
    },
    "frp": {
        "name": "Fire Radiative Power",
        "layer_name": "CAMS | Fire Radiative Power [W/m2]",
        "display_unit": "W/m2",
        "opacity": 0.90,
        "levels": [
            0.0001, 0.0002, 0.0005, 0.001,
            0.002, 0.005, 0.01, 0.02,
            0.05, 0.1, 0.2, 0.5,
            1, 2, 5, 10
        ],
        "colors": [
            "#400000", "#700000", "#A50000", "#C50000",
            "#E00000", "#F00000", "#FF1300", "#FF3900",
            "#FF6000", "#FF8500", "#FFA300", "#FFC700",
            "#FFE000", "#FFF000", "#FFFF26", "#FFFFAC"
        ],
        "labels": [
            "0,0001 - 0,0002", "0,0002 - 0,0005", "0,0005 - 0,001",
            "0,001 - 0,002", "0,002 - 0,005", "0,005 - 0,01",
            "0,01 - 0,02", "0,02 - 0,05", "0,05 - 0,10",
            "0,10 - 0,20", "0,20 - 0,50", "0,50 - 1",
            "1 - 2", "2 - 5", "5 - 10",
            "> 10 (ujung gradasi)"
        ],

    },
    # --------------------------------------------------------- cuaca GFS
    # --------------------------------------------- Hidrokarbon (HO) / HC
    # Konsentrasi total hidrokarbon [µg/m3] TANPA klasifikasi ISPU:
    # gradasi konsentrasi biasa (breakpoint otomatis mengikuti rentang
    # nilai data). Hitungan ISPU dilakukan di tab Analisis.
    "ho": {
        "name": "Hidrokarbon (HO) - total hidrokarbon",
        "layer_name": "CAMS | Hidrokarbon (HO) [µg/m3]",
        "display_unit": "µg/m3",
        "opacity": 0.85,
        "levels": None,
        "colors": PAL_WHITE_GREEN_PURPLE_12,
    },
    "tp": {
        "name": "Total Precipitation",
        "layer_name": "GFS | Total Precipitation [mm]",
        "display_unit": "mm",
        "scale_factor": 1000.0,
        "offset": 0.0,
        "opacity": 0.80,
        "levels": [0.1, 0.5, 1, 2, 5, 10, 15, 20, 30, 50, 75, 100],
        "colors": [
            "#C6DBEF", "#9ECBE1", "#6BAED6", "#4292C6",
            "#2171B5", "#08519C", "#08306B", "#06204A",
            "#041530", "#020A1A", "#010510", "#000205",
        ],
    },
    "10si": {
        "name": "10m Wind Speed",
        "layer_name": "GFS | Wind Speed 10m [m/s]",
        "display_unit": "m/s",
        "opacity": 0.80,
        "levels": [1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25],
        "colors": PAL_BLUE_BROWN_14,
    },
    "2t": {
        "name": "2m Temperature",
        "layer_name": "GFS | Temperature 2m [deg C]",
        "display_unit": "deg C",
        "scale_factor": 1.0,
        "offset": -273.15,
        "opacity": 0.80,
        "levels": [-30, -25, -20, -15, -10, -5, 0, 5, 10, 15, 20, 25, 30, 35],
        "colors": [
            "#313695", "#4575B4", "#74ADD1", "#ABD9E9",
            "#E0F3F8", "#FFFFBF", "#FEE090", "#FDAE61",
            "#F46D43", "#D73027", "#A50026", "#800020",
            "#4A0010", "#2D0008",
        ],
    },
}

VARIABLE_ALIASES = {
    # CH4 (kolom & profil -> rampa sama)
    "ch4": "ch4", "ch4_c": "ch4", "ch4c": "ch4", "methane": "ch4",
    "tc_ch4": "ch4", "tch4": "ch4", "tcch4": "ch4",
    "total_column_methane": "ch4", "ch4_column_mean_molar_fraction": "ch4",
    # CO
    "co_tc": "co_tc", "tcco": "co_tc", "tc_co": "co_tc", "tcco": "co_tc",
    "total_column_carbon_monoxide": "co_tc",
    "co": "co", "co_c": "co", "coc": "co", "carbon_monoxide": "co",
    # CO2
    "co2": "co2", "co2_c": "co2", "co2c": "co2", "carbon_dioxide": "co2",
    "tcco2": "co2", "tc_co2": "co2", "tcco2": "co2",
    "co2_column_mean_molar_fraction": "co2",
    # NO2
    "no2_tc": "no2_tc", "tcno2": "no2_tc", "tc_no2": "no2_tc",
    "total_column_nitrogen_dioxide": "no2_tc",
    "no2": "no2", "no2_c": "no2", "no2c": "no2", "nitrogen_dioxide": "no2",
    # SO2
    "so2_tc": "so2_tc", "tcso2": "so2_tc", "tc_so2": "so2_tc",
    "total_column_sulphur_dioxide": "so2_tc",
    "so2": "so2", "so2_c": "so2", "so2c": "so2",
    "sulphur_dioxide": "so2", "sulfur_dioxide": "so2",
    # HCHO
    "hcho_tc": "hcho_tc", "tchcho": "hcho_tc", "tc_hcho": "hcho_tc",
    "total_column_formaldehyde": "hcho_tc",
    "hcho": "hcho", "hcho_c": "hcho", "hchoc": "hcho", "formaldehyde": "hcho",
    # O3
    "o3_tc": "o3_tc", "tco3": "o3_tc", "tc_o3": "o3_tc",
    "total_column_ozone": "o3_tc", "gtco3": "o3_tc",
    "o3": "o3", "o3_c": "o3", "o3c": "o3", "ozone": "o3", "go3": "o3",
    # PM
    "pm2p5": "pm2p5", "pm25": "pm2p5", "pm2.5": "pm2p5",
    "particulate_matter_2.5um": "pm2p5",
    "pm10": "pm10", "particulate_matter_10um": "pm10",
    # AOD
    "aod550": "aod550", "aerosol": "aod550",
    "total_aerosol_optical_depth_550nm": "aod550",
    "duaod550": "duaod550", "dust": "duaod550",
    "omaod550": "omaod550", "organic_matter": "omaod550",
    "ssaod550": "ssaod550", "sea_salt": "ssaod550",
    "suaod550": "suaod550", "sulphate": "suaod550",
    # UV / FRP
    "uv": "uv", "uv_index": "uv", "uvindex": "uv",
    "uvbed": "uvbed", "uv_biologically_effective_dose": "uvbed",
    "uv_biologically_effective_dose_clear_sky": "uvbed",
    "frp": "frp", "fire_radiative_power": "frp",
    # cuaca GFS
    "tp": "tp", "precipitation": "tp", "total_precipitation": "tp",
    "10si": "10si", "wind_speed": "10si",
    "2t": "2t", "temperature": "2t", "t2m": "2t",
    # Hydrocarbons & VOCs (NMVOC) — taruh di akhir agar alias lama
    # tetap menang pada pencocokan parsial (mis. "ethane" di dalam "methane")
    "c2h6_tc": "c2h6_tc", "tc_c2h6": "c2h6_tc", "tcc2h6": "c2h6_tc",
    "total_column_ethane": "c2h6_tc",
    "c2h6": "c2h6", "c2h6_c": "c2h6", "c2h6c": "c2h6", "ethane": "c2h6",
    "c2h4_tc": "c2h4_tc", "tc_c2h4": "c2h4_tc", "tcc2h4": "c2h4_tc",
    "total_column_ethene": "c2h4_tc",
    "c2h4": "c2h4", "c2h4_c": "c2h4", "c2h4c": "c2h4",
    "ethene": "c2h4", "ethylene": "c2h4",
    "c2h5oh_tc": "c2h5oh_tc", "tc_c2h5oh": "c2h5oh_tc", "tcc2h5oh": "c2h5oh_tc",
    "total_column_ethanol": "c2h5oh_tc",
    "c2h5oh": "c2h5oh", "ethanol": "c2h5oh",
    "c3h8_tc": "c3h8_tc", "tc_c3h8": "c3h8_tc", "tcc3h8": "c3h8_tc",
    "total_column_propane": "c3h8_tc",
    "c3h8": "c3h8", "c3h8_c": "c3h8", "propane": "c3h8",
    "c3h6_tc": "c3h6_tc", "tc_c3h6": "c3h6_tc", "tcc3h6": "c3h6_tc",
    "total_column_propene": "c3h6_tc",
    "c3h6": "c3h6", "c3h6_c": "c3h6", "propene": "c3h6", "propylene": "c3h6",
    "c5h8_tc": "c5h8_tc", "tc_c5h8": "c5h8_tc", "tcc5h8": "c5h8_tc",
    "total_column_isoprene": "c5h8_tc",
    "c5h8": "c5h8", "c5h8_c": "c5h8", "isoprene": "c5h8",
    "acetone_tc": "acetone_tc", "tc_ch3coch3": "acetone_tc", "tcch3coch3": "acetone_tc",
    "total_column_acetone": "acetone_tc",
    "acetone": "acetone", "ch3coch3": "acetone",
    "ho": "ho", "hidrokarbon": "ho", "hidrokarbon_ho": "ho",
    "hydrocarbon": "ho", "hc": "ho",
}

# Konversi satuan eksplisit (unit ternormalisasi -> (pengali, offset))
EXPLICIT_UNIT_CONVERSIONS = {
    "ugm3": (1.0, 0.0),
    "gm3": (1e6, 0.0),
    "kgm3": (1e9, 0.0),
    "kgm2": (1.0, 0.0),
    "kgkg": (1.0, 0.0),
    "kgkg1": (1.0, 0.0),
    "ppm": (1.0, 0.0),
    "ppmv": (1.0, 0.0),
    "ppbv": (1.0, 0.0),
    "wm2": (1.0, 0.0),
    "percent": (1.0, 0.0),
    "degc": (1.0, 0.0),
    "c": (1.0, 0.0),
    "celsius": (1.0, 0.0),
    "degreescelsius": (1.0, 0.0),
    "m2s2": (1.0, 0.0),
    "ms": (1.0, 0.0),
    "m": (1.0, 0.0),
}


def _unit_key(units):
    s = str(units or "").lower()
    s = s.replace("\u00b5g", "ug").replace("\u03bcg", "ug")
    s = s.replace("\u00b5", "u").replace("\u03bc", "u")
    return "".join(ch for ch in s if ch.isalnum())


def _molec_per_cm2_per_kgm2(molar_mass):
    """Pengali kg/m2 -> molekul/cm2."""
    return (1000.0 / float(molar_mass)) * N_AVOGADRO / 1.0e4


# Normalisasi satuan tampilan -> kunci konversi (teks satuan mengikuti
# legenda chart web: "10^18 molecules/cm2", "10^15 molecules/cm2")
_DISPLAY_KEYS = {
    "1e18moleccm2": "1e18moleccm2", "1018moleculescm2": "1e18moleccm2",
    "1e15moleccm2": "1e15moleccm2", "1015moleculescm2": "1e15moleccm2",
    "1e18moleculescm2": "1e18moleccm2", "1e15moleculescm2": "1e15moleccm2",
}


def effective_scale_offset(units, param_name):
    """(scale, offset): nilai raster -> satuan tampilan chart web."""
    sym = get_symbology(param_name) or {}
    display = _unit_key(sym.get("display_unit", ""))
    display = _DISPLAY_KEYS.get(display, display)
    u = _unit_key(units)

    if u == "m" and display == "mm":
        return 1000.0, 0.0
    if u in ("k", "kelvin") and display in ("degc", "c"):
        return 1.0, -273.15

    mm = sym.get("molar_mass")
    if mm:
        # massa campuran (kg/kg) -> ppmv/ppbv
        if display in ("ppbv", "ppmv") and u in ("kgkg", "kgkg1", "kgm2"):
            scale = (1e9 if display == "ppbv" else 1e6) * MOLAR_MASS_AIR / float(mm)
            if u == "kgm2":
                scale /= AIR_COLUMN_MASS
            return scale, 0.0
        # pecahan mol/mol -> ppmv/ppbv
        if display in ("ppbv", "ppmv") and u in ("molmol", "molmol1", "molfraction"):
            return (1e9 if display == "ppbv" else 1e6), 0.0
        # kolom terintegrasi (kg/m2) -> satuan chart web
        if u == "kgm2":
            molec = _molec_per_cm2_per_kgm2(mm)
            if display == "1e18moleccm2":
                return molec / 1e18, 0.0
            if display == "1e15moleccm2":
                return molec / 1e15, 0.0
            if display == "du":
                return molec / DU_PER_MOLEC_CM2, 0.0
            if display == "kgkg":
                return 1.0 / AIR_COLUMN_MASS, 0.0

    if u in EXPLICIT_UNIT_CONVERSIONS:
        return EXPLICIT_UNIT_CONVERSIONS[u]

    return float(sym.get("scale_factor", 1.0)), float(sym.get("offset", 0.0))


def get_symbology(param_name):
    if param_name in CAMB_SYMBLOGY:
        return CAMB_SYMBLOGY[param_name]

    param_lower = str(param_name).lower().strip()
    if param_lower in VARIABLE_ALIASES:
        return CAMB_SYMBLOGY.get(VARIABLE_ALIASES[param_lower])

    for alias, key in VARIABLE_ALIASES.items():
        if len(alias) >= 3 and alias in param_lower:
            return CAMB_SYMBLOGY.get(key)

    return None


def get_layer_name(param_name):
    sym = get_symbology(param_name)
    if sym:
        return sym.get("layer_name", f"CAMS | {param_name}")
    return f"CAMS | {param_name}"


def get_opacity(param_name):
    sym = get_symbology(param_name)
    return sym.get("opacity", 0.80) if sym else 0.80


def get_legend_items(param_name):
    """Item legenda: list dict {value, label, hex}."""
    sym = get_symbology(param_name)
    if not sym or not sym.get("levels"):
        return []
    levels = sym["levels"]
    colors = sym["colors"]
    labels = sym.get("labels") or []
    items = []
    for i, level in enumerate(levels):
        if i < len(colors):
            items.append({
                "value": level,
                "label": labels[i] if i < len(labels) else str(level),
                "hex": colors[i],
            })
    return items


def _stops_from(levels, colors, labels):
    """Susun henti rampa: (value, warna, label, alpha) per breakpoint.

    Item pertama = transparan untuk nilai di bawah kelas terendah.
    """
    classes = []
    n = min(len(levels), len(colors))
    for i in range(n):
        lo = levels[i]
        hi = levels[i + 1] if i + 1 < n else float("inf")
        if i < len(labels) and labels[i]:
            label = labels[i]
        elif hi == float("inf"):
            label = f"> {lo:g}"
        else:
            label = f"{lo:g} - {hi:g}"
        classes.append((lo, colors[i], label))
    lo0 = classes[0][0]
    eps = max(abs(lo0) * 1e-9, 1e-12)
    stops = [(lo0 - eps, "#000000", f"< {lo0:g} (tidak diwarnai)", 0)]
    for lo, color, label in classes:
        stops.append((lo, color, label, 255))
    return stops


def ramp_stops(param_name, vmin=None, vmax=None):
    """(opacity, [(value, warna_hex, label, alpha), ...]) dari legenda resmi.

    Breakpoint tetap mengikuti legenda; untuk entri tanpa levels tetap,
    breakpoint dibagi merata pada rentang vmin..vmax. (None, []) bila tidak
    ada symbology. Dipakai untuk styling layer dan ekspor QML.
    """
    sym = get_symbology(param_name)
    if not sym:
        return None, []
    colors = sym.get("colors") or []
    labels = sym.get("labels") or []
    opacity = float(sym.get("opacity", 0.80))
    if not colors:
        return None, []
    levels = sym.get("levels")
    if levels:
        levels = [float(v) for v in levels]
    else:
        if vmin is None or vmax is None or not (float(vmax) > float(vmin)):
            return None, []
        vmin, vmax = float(vmin), float(vmax)
        n = len(colors)
        step = (vmax - vmin) / n
        levels = [vmin + i * step for i in range(n)]
    return opacity, _stops_from(levels, colors, labels)


def default_ramp_stops(vmin, vmax):
    """(0.8, stops) ramp fallback biru-merah untuk parameter tak dikenal."""
    if vmin is None or vmax is None or not (float(vmax) > float(vmin)):
        return None, []
    vmin, vmax = float(vmin), float(vmax)
    colors = ["#313695", "#4575B4", "#74ADD1", "#ABD9E9", "#E0F3F8",
              "#FFFFBF", "#FEE090", "#FDAE61", "#F46D43", "#D73027"]
    n = len(colors)
    step = (vmax - vmin) / n
    levels = [vmin + i * step for i in range(n)]
    return 0.8, _stops_from(levels, colors, [])


def build_ramp_items(param_name, vmin=None, vmax=None):
    """Bangun item QgsColorRampShader gradasi HALUS seperti chart web CAMS.

    Breakpoint kelas TETAP mengikuti legenda resmi (bukan min-max data):
    warna colors[i] berada tepat pada batas levels[i], dan antar breakpoint
    warna bergradasi halus (mode Interpolated) — sama seperti tampilan web
    atmosphere.copernicus.eu. Nilai di bawah kelas terendah TIDAK diwarnai
    (transparan); nilai di atas batas atas memakai warna kelas terakhir.
    Untuk entri tanpa levels tetap, breakpoint dibagi merata pada rentang
    data vmin..vmax. Mengembalikan (ramp_type, items, opacity).
    """
    from qgis.PyQt.QtGui import QColor

    opacity, stops = ramp_stops(param_name, vmin, vmax)
    if not stops:
        return None, [], 0.8
    items = []
    for value, color, label, alpha in stops:
        qc = QColor(0, 0, 0, 0) if alpha == 0 else QColor(color)
        items.append(QgsColorRampShader.ColorRampItem(value, qc, label))
    return "interpolated", items, opacity


def build_default_ramp(vmin, vmax):
    """Ramp fallback biru-merah gradasi halus bila parameter tak dikenal.

    Breakpoint merata pada rentang vmin..vmax; nilai di bawah vmin tidak
    diwarnai (transparan).
    """
    from qgis.PyQt.QtGui import QColor

    opacity, stops = default_ramp_stops(vmin, vmax)
    if not stops:
        return None, [], 0.8
    items = []
    for value, color, label, alpha in stops:
        qc = QColor(0, 0, 0, 0) if alpha == 0 else QColor(color)
        items.append(QgsColorRampShader.ColorRampItem(value, qc, label))
    return "interpolated", items, opacity


def write_qml(tif_path, param_name, vmin=None, vmax=None):
    """Tulis file style QGIS (<raster>.qml) di samping raster hasil unduhan.

    File QML terbaca otomatis oleh QGIS saat raster dibuka (bahkan di luar
    plugin): gradasi warna antar breakpoint legenda resmi, nilai di bawah
    kelas terendah transparan, legenda terklasifikasi, dan resampling
    bilinear (tampilan halus). Mengembalikan path .qml, atau None bila
    parameter tidak memiliki symbology.
    """
    import math
    from xml.sax.saxutils import escape

    opacity, stops = ramp_stops(param_name, vmin, vmax)
    if not stops:
        opacity, stops = default_ramp_stops(vmin, vmax)
    if not stops:
        return None

    def num(v):
        return f"{float(v):.12g}"

    items_xml = "\n".join(
        f'          <item value="{num(v)}" color="{color}" '
        f'label="{escape(str(label))}" alpha="{alpha}"/>'
        for v, color, label, alpha in stops)

    cls_attrs = ""
    try:
        if vmin is not None and vmax is not None and math.isfinite(float(vmin)) \
                and math.isfinite(float(vmax)):
            cls_attrs = (f' classificationMin="{num(vmin)}"'
                         f' classificationMax="{num(vmax)}"')
    except (TypeError, ValueError):
        pass

    qml = f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28" styleCategories="AllStyleCategories">
  <pipe>
    <provider>
      <resampling enabled="false" zoomedInResampler="bilinear" zoomedOutResampler="bilinear" maxOversampling="16"/>
    </provider>
    <rasterrenderer type="singlebandpseudocolor" opacity="{opacity:g}" alphaBand="-1" nodataColor="" band="1"{cls_attrs}>
      <rastershader>
        <colorrampshader colorRampType="INTERPOLATED" clip="0" classificationMode="1">
{items_xml}
          <rampLegendSettings useContinuousLegend="0" minimumLabel="" maximumLabel="" prefix="" suffix="" direction="0" orientation="1"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeOn="0" grayscaleMode="0" saturation="0" colorizeGreen="128" colorizeStrength="100" colorizeRed="255" colorizeBlue="128"/>
    <rasterresampler maxOversampling="16.0" zoomedInResampler="bilinear" zoomedOutResampler="bilinear"/>
  </pipe>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
</qgis>
"""
    qml_path = os.path.splitext(str(tif_path))[0] + ".qml"
    with open(qml_path, "w", encoding="utf-8") as f:
        f.write(qml)
    return qml_path
