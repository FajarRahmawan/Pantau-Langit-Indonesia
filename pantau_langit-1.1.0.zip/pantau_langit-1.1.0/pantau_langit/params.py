"""Definisi parameter unduhan: CAMS, cuaca GFS, hotspot FIRMS, satelit GIBS."""

# ---------------------------------------------------------------------------
# CAMS (Copernicus Atmosphere Data Store)
# key -> (variable, pressure_level, nc_var, label, dataset)
# ---------------------------------------------------------------------------
CAMS_DATASET = "cams-global-atmospheric-composition-forecasts"
CAMS_GHG_DATASET = "cams-global-greenhouse-gas-forecasts"

# Struktur waktu unduhan CAMS (agar Temporal Control QGIS rapi, satu band
# per langkah waktu valid tanpa duplikasi):
# - tanggal sebelum tanggal terakhir ("tanggal sebelumnya"): run 00 & 12 UTC
#   dengan leadtime s/d +9 jam -> waktu valid 00:00 s/d 21:00 tanggal itu
#   (8 langkah 3-jam).
# - tanggal terakhir ("tanggal terkini"): leadtime s/d +96 jam -> prediksi
#   kurang lebih 3 hari ke depan. Duplikasi waktu valid antar run dibuang
#   saat konversi (run terbaru menang).
CAMS_LEADTIME_HIST = ["0", "3", "6", "9"]
CAMS_LEADTIME_KINI = ["0", "3", "6", "9", "12", "15", "18", "21", "24",
                      "36", "48", "72", "96"]

# Konfigurasi request per dataset (bentuk request berbeda antar dataset)
CAMS_DATASET_CONFIG = {
    CAMS_DATASET: {
        "data_format": "netcdf",
        "include_time_type": True,
        "leadtime_hour": list(CAMS_LEADTIME_KINI),
    },
    CAMS_GHG_DATASET: {
        "data_format": "netcdf_zip",
        "include_time_type": False,
        "leadtime_hour": list(CAMS_LEADTIME_KINI),
    },
}

_ATM = CAMS_DATASET
_GHG = CAMS_GHG_DATASET

CAMS_PARAM_DEFS = {
    # A. Aerosol
    "aerosol_total": ("total_aerosol_optical_depth_550nm", None, "aod550", "Total Aerosol OD 550nm", _ATM),
    "aerosol_dust": ("dust_aerosol_optical_depth_550nm", None, "duaod550", "Dust Aerosol OD 550nm", _ATM),
    "aerosol_seasalt": ("sea_salt_aerosol_optical_depth_550nm", None, "ssaod550", "Sea-Salt Aerosol OD 550nm", _ATM),
    "aerosol_biomass": ("organic_matter_aerosol_optical_depth_550nm", None, "omaod550", "Biomass-Burning Aerosol OD", _ATM),
    "aerosol_sulphate": ("sulphate_aerosol_optical_depth_550nm", None, "suaod550", "Sulphate Aerosol OD 550nm", _ATM),
    # B. Carbon Dioxide (dataset GHG terpisah)
    "co2_total_column": ("co2_column_mean_molar_fraction", None, "tcco2", "CO2 Total Column", _GHG),
    "co2_surface": ("carbon_dioxide", "1000", "co2", "CO2 Surface", _GHG),
    "co2_850": ("carbon_dioxide", "850", "co2", "CO2 850 hPa", _GHG),
    "co2_500": ("carbon_dioxide", "500", "co2", "CO2 500 hPa", _GHG),
    "co2_300": ("carbon_dioxide", "300", "co2", "CO2 300 hPa", _GHG),
    "co2_50": ("carbon_dioxide", "50", "co2", "CO2 50 hPa", _GHG),
    # C. Carbon Monoxide
    "co_total_column": ("total_column_carbon_monoxide", None, "tc_co", "CO Total Column", _ATM),
    "co_surface": ("carbon_monoxide", "1000", "co", "CO Surface", _ATM),
    "co_850": ("carbon_monoxide", "850", "co", "CO 850 hPa", _ATM),
    "co_500": ("carbon_monoxide", "500", "co", "CO 500 hPa", _ATM),
    "co_300": ("carbon_monoxide", "300", "co", "CO 300 hPa", _ATM),
    "co_50": ("carbon_monoxide", "50", "co", "CO 50 hPa", _ATM),
    # D. Formaldehyde
    "hcho_total_column": ("total_column_formaldehyde", None, "tc_hcho", "HCHO Total Column", _ATM),
    "hcho_surface": ("formaldehyde", "1000", "hcho", "HCHO Surface", _ATM),
    "hcho_850": ("formaldehyde", "850", "hcho", "HCHO 850 hPa", _ATM),
    "hcho_500": ("formaldehyde", "500", "hcho", "HCHO 500 hPa", _ATM),
    "hcho_300": ("formaldehyde", "300", "hcho", "HCHO 300 hPa", _ATM),
    "hcho_50": ("formaldehyde", "50", "hcho", "HCHO 50 hPa", _ATM),
    # E. Methane
    "ch4_total_column": ("total_column_methane", None, "tc_ch4", "CH4 Total Column", _ATM),
    "ch4_surface": ("methane", "1000", "ch4_c", "CH4 Surface", _ATM),
    "ch4_850": ("methane", "850", "ch4_c", "CH4 850 hPa", _ATM),
    "ch4_500": ("methane", "500", "ch4_c", "CH4 500 hPa", _ATM),
    "ch4_300": ("methane", "300", "ch4_c", "CH4 300 hPa", _ATM),
    "ch4_50": ("methane", "50", "ch4_c", "CH4 50 hPa", _ATM),
    # F. Nitrogen Dioxide
    "no2_total_column": ("total_column_nitrogen_dioxide", None, "tc_no2", "NO2 Total Column", _ATM),
    "no2_surface": ("nitrogen_dioxide", "1000", "no2", "NO2 Surface", _ATM),
    "no2_850": ("nitrogen_dioxide", "850", "no2", "NO2 850 hPa", _ATM),
    "no2_500": ("nitrogen_dioxide", "500", "no2", "NO2 500 hPa", _ATM),
    "no2_300": ("nitrogen_dioxide", "300", "no2", "NO2 300 hPa", _ATM),
    "no2_50": ("nitrogen_dioxide", "50", "no2", "NO2 50 hPa", _ATM),
    # G. Ozone
    "o3_total_column": ("total_column_ozone", None, "tc_o3", "O3 Total Column", _ATM),
    "o3_surface": ("ozone", "1000", "o3", "O3 Surface", _ATM),
    "o3_850": ("ozone", "850", "o3", "O3 850 hPa", _ATM),
    "o3_500": ("ozone", "500", "o3", "O3 500 hPa", _ATM),
    "o3_300": ("ozone", "300", "o3", "O3 300 hPa", _ATM),
    "o3_50": ("ozone", "50", "o3", "O3 50 hPa", _ATM),
    # H. Particulate Matter
    "pm25": ("particulate_matter_2.5um", None, "pm2p5", "PM2.5 Fine Particulate Matter", _ATM),
    "pm10": ("particulate_matter_10um", None, "pm10", "PM10 Coarse Particulate Matter", _ATM),
    # I. Sulphur Dioxide
    "so2_total_column": ("total_column_sulphur_dioxide", None, "tc_so2", "SO2 Total Column", _ATM),
    "so2_surface": ("sulphur_dioxide", "1000", "so2", "SO2 Surface", _ATM),
    "so2_850": ("sulphur_dioxide", "850", "so2", "SO2 850 hPa", _ATM),
    "so2_500": ("sulphur_dioxide", "500", "so2", "SO2 500 hPa", _ATM),
    "so2_300": ("sulphur_dioxide", "300", "so2", "SO2 300 hPa", _ATM),
    "so2_50": ("sulphur_dioxide", "50", "so2", "SO2 50 hPa", _ATM),
    # J. UV Index (BED = Biologically Effective Dose)
    "uv_total_sky": ("uv_biologically_effective_dose", None, "uvbed", "UV Biologically Effective Dose", _ATM),
    "uv_clear_sky": ("uv_biologically_effective_dose_clear_sky", None, "uvbed", "UV BED Clear-Sky", _ATM),
    # K. Ethane (C2H6)
    "c2h6_total_column": ("total_column_ethane", None, "tc_c2h6", "C2H6 Total Column", _ATM),
    "c2h6_surface": ("ethane", "1000", "c2h6", "C2H6 Surface", _ATM),
    "c2h6_850": ("ethane", "850", "c2h6", "C2H6 850 hPa", _ATM),
    "c2h6_500": ("ethane", "500", "c2h6", "C2H6 500 hPa", _ATM),
    "c2h6_300": ("ethane", "300", "c2h6", "C2H6 300 hPa", _ATM),
    "c2h6_50": ("ethane", "50", "c2h6", "C2H6 50 hPa", _ATM),
    # L. Ethene (C2H4)
    "c2h4_total_column": ("total_column_ethene", None, "tc_c2h4", "C2H4 Total Column", _ATM),
    "c2h4_surface": ("ethene", "1000", "c2h4", "C2H4 Surface", _ATM),
    "c2h4_850": ("ethene", "850", "c2h4", "C2H4 850 hPa", _ATM),
    "c2h4_500": ("ethene", "500", "c2h4", "C2H4 500 hPa", _ATM),
    "c2h4_300": ("ethene", "300", "c2h4", "C2H4 300 hPa", _ATM),
    "c2h4_50": ("ethene", "50", "c2h4", "C2H4 50 hPa", _ATM),
    # M. Ethanol (C2H5OH)
    "c2h5oh_total_column": ("total_column_ethanol", None, "tc_c2h5oh", "C2H5OH Total Column", _ATM),
    "c2h5oh_surface": ("ethanol", "1000", "c2h5oh", "C2H5OH Surface", _ATM),
    "c2h5oh_850": ("ethanol", "850", "c2h5oh", "C2H5OH 850 hPa", _ATM),
    "c2h5oh_500": ("ethanol", "500", "c2h5oh", "C2H5OH 500 hPa", _ATM),
    "c2h5oh_300": ("ethanol", "300", "c2h5oh", "C2H5OH 300 hPa", _ATM),
    "c2h5oh_50": ("ethanol", "50", "c2h5oh", "C2H5OH 50 hPa", _ATM),
    # N. Propane (C3H8)
    "c3h8_total_column": ("total_column_propane", None, "tc_c3h8", "C3H8 Total Column", _ATM),
    "c3h8_surface": ("propane", "1000", "c3h8", "C3H8 Surface", _ATM),
    "c3h8_850": ("propane", "850", "c3h8", "C3H8 850 hPa", _ATM),
    "c3h8_500": ("propane", "500", "c3h8", "C3H8 500 hPa", _ATM),
    "c3h8_300": ("propane", "300", "c3h8", "C3H8 300 hPa", _ATM),
    "c3h8_50": ("propane", "50", "c3h8", "C3H8 50 hPa", _ATM),
    # O. Propene (C3H6)
    "c3h6_total_column": ("total_column_propene", None, "tc_c3h6", "C3H6 Total Column", _ATM),
    "c3h6_surface": ("propene", "1000", "c3h6", "C3H6 Surface", _ATM),
    "c3h6_850": ("propene", "850", "c3h6", "C3H6 850 hPa", _ATM),
    "c3h6_500": ("propene", "500", "c3h6", "C3H6 500 hPa", _ATM),
    "c3h6_300": ("propene", "300", "c3h6", "C3H6 300 hPa", _ATM),
    "c3h6_50": ("propene", "50", "c3h6", "C3H6 50 hPa", _ATM),
    # P. Isoprene (C5H8)
    "c5h8_total_column": ("total_column_isoprene", None, "tc_c5h8", "C5H8 Total Column", _ATM),
    "c5h8_surface": ("isoprene", "1000", "c5h8", "C5H8 Surface", _ATM),
    "c5h8_850": ("isoprene", "850", "c5h8", "C5H8 850 hPa", _ATM),
    "c5h8_500": ("isoprene", "500", "c5h8", "C5H8 500 hPa", _ATM),
    "c5h8_300": ("isoprene", "300", "c5h8", "C5H8 300 hPa", _ATM),
    "c5h8_50": ("isoprene", "50", "c5h8", "C5H8 50 hPa", _ATM),
    # Q. Acetone (C3H6O)
    "acetone_total_column": ("total_column_acetone", None, "tc_ch3coch3", "Acetone Total Column", _ATM),
    "acetone_surface": ("acetone", "1000", "ch3coch3", "Acetone Surface", _ATM),
    "acetone_850": ("acetone", "850", "ch3coch3", "Acetone 850 hPa", _ATM),
    "acetone_500": ("acetone", "500", "ch3coch3", "Acetone 500 hPa", _ATM),
    "acetone_300": ("acetone", "300", "ch3coch3", "Acetone 300 hPa", _ATM),
    "acetone_50": ("acetone", "50", "ch3coch3", "Acetone 50 hPa", _ATM),
}

CAMS_GROUPS = [
    ("A. Aerosol", ["aerosol_total", "aerosol_dust", "aerosol_seasalt", "aerosol_biomass", "aerosol_sulphate"]),
    ("B. Carbon Dioxide", ["co2_total_column", "co2_surface", "co2_850", "co2_500", "co2_300", "co2_50"]),
    ("C. Carbon Monoxide", ["co_total_column", "co_surface", "co_850", "co_500", "co_300", "co_50"]),
    ("D. Formaldehyde", ["hcho_total_column", "hcho_surface", "hcho_850", "hcho_500", "hcho_300", "hcho_50"]),
    ("E. Methane", ["ch4_total_column", "ch4_surface", "ch4_850", "ch4_500", "ch4_300", "ch4_50"]),
    ("F. Nitrogen Dioxide", ["no2_total_column", "no2_surface", "no2_850", "no2_500", "no2_300", "no2_50"]),
    ("G. Ozone", ["o3_total_column", "o3_surface", "o3_850", "o3_500", "o3_300", "o3_50"]),
    ("H. Particulate Matter", ["pm25", "pm10"]),
    ("I. Sulphur Dioxide", ["so2_total_column", "so2_surface", "so2_850", "so2_500", "so2_300", "so2_50"]),
    ("J. UV Biologically Effective Dose", ["uv_total_sky", "uv_clear_sky"]),
    ("K. Ethane (C2H6)", ["c2h6_total_column", "c2h6_surface", "c2h6_850", "c2h6_500", "c2h6_300", "c2h6_50"]),
    ("L. Ethene (C2H4)", ["c2h4_total_column", "c2h4_surface", "c2h4_850", "c2h4_500", "c2h4_300", "c2h4_50"]),
    ("M. Ethanol (C2H5OH)", ["c2h5oh_total_column", "c2h5oh_surface", "c2h5oh_850", "c2h5oh_500", "c2h5oh_300", "c2h5oh_50"]),
    ("N. Propane (C3H8)", ["c3h8_total_column", "c3h8_surface", "c3h8_850", "c3h8_500", "c3h8_300", "c3h8_50"]),
    ("O. Propene (C3H6)", ["c3h6_total_column", "c3h6_surface", "c3h6_850", "c3h6_500", "c3h6_300", "c3h6_50"]),
    ("P. Isoprene (C5H8)", ["c5h8_total_column", "c5h8_surface", "c5h8_850", "c5h8_500", "c5h8_300", "c5h8_50"]),
    ("Q. Acetone (C3H6O)", ["acetone_total_column", "acetone_surface", "acetone_850", "acetone_500", "acetone_300", "acetone_50"]),
]

# ---------------------------------------------------------------------------
# Cuaca NOAA GFS
# key -> dict(label, keys, level, endpoint, sym, forecast_hour)
# endpoint "atmos": filter_gfs_0p25.pl, file gfs.tCCz.pgrb2.0p25.fHHH
# endpoint "wave" : filter_gfswave.pl,  file gfswave.tCCz.global.0p25.fHHH.grib2
# ---------------------------------------------------------------------------
GFS_BASE_URL = "https://nomads.ncep.noaa.gov/cgi-bin/filter_gfs_0p25.pl"
GFS_WAVE_URL = "https://nomads.ncep.noaa.gov/cgi-bin/filter_gfswave.pl"

WEATHER_PARAMS = {
    "wind": {
        "label": "Kecepatan Angin [m/s]", "keys": ["WIND"],
        "level": "surface", "endpoint": "wave", "sym": "10si",
        "forecast_hour": "000",
    },
    "wind_direction": {
        "label": "Arah Angin [derajat]", "keys": ["WDIR"],
        "level": "surface", "endpoint": "wave", "sym": None,
        "forecast_hour": "000", "arrows": True,
    },
    "cloud_cover": {
        "label": "Cloud Cover (total) [%]", "keys": ["TCDC"],
        "level": "entire_atmosphere", "endpoint": "atmos", "sym": None,
        "forecast_hour": "000",
    },
    "total_precipitation": {
        "label": "Total Precipitation (3h) [mm]", "keys": ["APCP"],
        "level": "surface", "endpoint": "atmos", "sym": "tp",
        "forecast_hour": "003",
    },
    "temperature_2m": {
        "label": "Temperature 2m [deg C]", "keys": ["TMP"],
        "level": "2_m_above_ground", "endpoint": "atmos", "sym": "2t",
        "forecast_hour": "000",
    },
    "mean_sea_level_pressure": {
        "label": "Mean Sea Level Pressure [Pa]", "keys": ["PRMSL"],
        "level": "mean_sea_level", "endpoint": "atmos", "sym": None,
        "forecast_hour": "000",
    },
    "relative_humidity": {
        "label": "Relative Humidity 2m [%]", "keys": ["RH"],
        "level": "2_m_above_ground", "endpoint": "atmos", "sym": None,
        "forecast_hour": "000",
    },
    "significant_height": {
        "label": "Wave - Significant Height [m]", "keys": ["HTSGW"],
        "level": "surface", "endpoint": "wave", "sym": None,
        "forecast_hour": "000",
    },
    "swell": {
        "label": "Wave - Primary Swell Period [s]", "keys": ["PERPW"],
        "level": "surface", "endpoint": "wave", "sym": None,
        "forecast_hour": "000",
    },
    "wind_waves": {
        "label": "Wave - Wind Waves Height [m]", "keys": ["WVHGT"],
        "level": "surface", "endpoint": "wave", "sym": None,
        "forecast_hour": "000",
    },
}

# ---------------------------------------------------------------------------
# NASA FIRMS hotspot
# ---------------------------------------------------------------------------
FIRMS_BASE_URL = "https://firms.modaps.eosdis.nasa.gov/api/area"

FIRMS_SOURCES = {
    "viirs_snpp": ("VIIRS_SNPP_NRT", "VIIRS S-NPP"),
    "viirs_noaa20": ("VIIRS_NOAA20_NRT", "VIIRS NOAA-20"),
    "viirs_noaa21": ("VIIRS_NOAA21_NRT", "VIIRS NOAA-21"),
    "modis": ("MODIS_NRT", "MODIS"),
    "landsat": ("LANDSAT_NRT", "Landsat"),
}

# ---------------------------------------------------------------------------
# Satelit NASA GIBS (WMTS, EPSG:3857)
# key -> dict(label, layer, format, matrix_set, time_type, group)
# time_type: "date" (harian) atau "datetime" (sub-harian Himawari)
# ---------------------------------------------------------------------------
GIBS_WMTS_URL = "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/wmts.cgi"

GIBS_LAYERS = {
    "himawari_air_mass": {
        "label": "Air Mass", "layer": "Himawari_AHI_Air_Mass",
        "format": "image/png", "matrix_set": "GoogleMapsCompatible_Level6",
        "time_type": "datetime", "group": "Himawari (JMA AHI)",
    },
    "himawari_clean_ir": {
        "label": "Clean Infrared", "layer": "Himawari_AHI_Band13_Clean_Infrared",
        "format": "image/png", "matrix_set": "GoogleMapsCompatible_Level6",
        "time_type": "datetime", "group": "Himawari (JMA AHI)",
    },
    "himawari_red_visible": {
        "label": "Red Visible 1km", "layer": "Himawari_AHI_Band3_Red_Visible_1km",
        "format": "image/png", "matrix_set": "GoogleMapsCompatible_Level7",
        "time_type": "datetime", "group": "Himawari (JMA AHI)",
    },
    "modis_terra_tc": {
        "label": "Terra True Color", "layer": "MODIS_Terra_CorrectedReflectance_TrueColor",
        "format": "image/jpeg", "matrix_set": "GoogleMapsCompatible_Level9",
        "time_type": "date", "group": "MODIS (NASA)",
    },
    "modis_aqua_tc": {
        "label": "Aqua True Color", "layer": "MODIS_Aqua_CorrectedReflectance_TrueColor",
        "format": "image/jpeg", "matrix_set": "GoogleMapsCompatible_Level9",
        "time_type": "date", "group": "MODIS (NASA)",
    },
    "viirs_snpp_tc": {
        "label": "Suomi NPP True Color", "layer": "VIIRS_SNPP_CorrectedReflectance_TrueColor",
        "format": "image/jpeg", "matrix_set": "GoogleMapsCompatible_Level9",
        "time_type": "date", "group": "Suomi NPP / NOAA-20 (VIIRS)",
    },
    "viirs_snpp_dnb_gapfilled": {
        "label": "Nighttime Lights (Gap-Filled DNB)", "layer": "VIIRS_SNPP_GapFilled_BRDF_Corrected_DayNightBand_Radiance",
        "format": "image/png", "matrix_set": "GoogleMapsCompatible_Level8",
        "time_type": "date", "group": "Suomi NPP / NOAA-20 (VIIRS)",
    },
    "viirs_snpp_dnb_radiance": {
        "label": "Day/Night Band Radiance", "layer": "VIIRS_SNPP_DayNightBand_At_Sensor_Radiance",
        "format": "image/png", "matrix_set": "GoogleMapsCompatible_Level8",
        "time_type": "date", "group": "Suomi NPP / NOAA-20 (VIIRS)",
    },
    "viirs_noaa20_tc": {
        "label": "NOAA-20 True Color", "layer": "VIIRS_NOAA20_CorrectedReflectance_TrueColor",
        "format": "image/jpeg", "matrix_set": "GoogleMapsCompatible_Level9",
        "time_type": "date", "group": "Suomi NPP / NOAA-20 (VIIRS)",
    },
}

# ---------------------------------------------------------------------------
# Bounding box baku (WGS84)
# ---------------------------------------------------------------------------
INDONESIA_BBOX = [95.0, -11.0, 141.0, 6.0]  # west, south, east, north


def cams_area(bbox):
    """bbox [W,S,E,N] -> area CDS [N,W,S,E]."""
    return [bbox[3], bbox[0], bbox[1], bbox[2]]


def cams_param_keys():
    return list(CAMS_PARAM_DEFS.keys())


def cams_param_label(key):
    return CAMS_PARAM_DEFS.get(key, (None, None, None, key))[3]


def weather_param_keys():
    return list(WEATHER_PARAMS.keys())


def gibs_param_keys():
    return list(GIBS_LAYERS.keys())
