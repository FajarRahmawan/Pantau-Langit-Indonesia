from qgis.core import QgsSettings

SECTION = "PantauLangit"

DEFAULT_CDS_URL = "https://ads.atmosphere.copernicus.eu/api"
DEFAULT_DOWNLOAD_DIR = ""


def _get(key, default, typ=str):
    val = QgsSettings().value(f"{SECTION}/{key}", default)
    if typ is str:
        return str(val) if val is not None else default
    return typ(val) if val is not None else default


def _set(key, value):
    QgsSettings().setValue(f"{SECTION}/{key}", value)


def get_cams_api_key() -> str:
    return _get("cams_api_key", "")


def set_cams_api_key(value: str):
    _set("cams_api_key", value.strip())


def get_cams_api_url() -> str:
    return _get("cams_api_url", DEFAULT_CDS_URL) or DEFAULT_CDS_URL


def set_cams_api_url(value: str):
    _set("cams_api_url", value.strip() or DEFAULT_CDS_URL)


def get_firms_map_key() -> str:
    return _get("firms_map_key", "")


def set_firms_map_key(value: str):
    _set("firms_map_key", value.strip())


def get_download_dir() -> str:
    return _get("download_dir", DEFAULT_DOWNLOAD_DIR)


def set_download_dir(value: str):
    _set("download_dir", value)


def get_dialog_size():
    """Ukuran terakhir dialog unduhan (width, height)."""
    return _get("dialog_width", 980, int), _get("dialog_height", 780, int)


def set_dialog_size(width: int, height: int):
    _set("dialog_width", int(width))
    _set("dialog_height", int(height))
