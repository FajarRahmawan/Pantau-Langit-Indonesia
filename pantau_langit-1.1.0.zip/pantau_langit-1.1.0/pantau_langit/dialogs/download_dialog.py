"""Dialog utama unduhan data Pantau Langit Indonesia."""

import os
from datetime import datetime, timedelta

from qgis.PyQt.QtCore import QDate, QDateTime, Qt, QThread, QTime, QObject, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDateTimeEdit,
    QDialog,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QTimeEdit,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import settings
from ..params import (
    CAMS_GROUPS,
    CAMS_PARAM_DEFS,
    GIBS_LAYERS,
    WEATHER_PARAMS,
    cams_param_label,
)
from .settings_dialog import SettingsDialog


class DownloadWorker(QObject):
    progress = pyqtSignal(int, str)
    log = pyqtSignal(str)
    finished = pyqtSignal(dict)

    def __init__(self, tasks):
        super().__init__()
        self.tasks = tasks

    def _emit_progress(self, pct, msg):
        self.progress.emit(int(pct), str(msg))

    def run(self):
        results = {"cams": [], "weather": [], "hotspot": None,
                   "gibs": [], "errors": []}
        try:
            self._work(results)
        except Exception as e:
            results["errors"].append(f"Error fatal: {e}")
            self.log.emit(f"ERROR: {e}")
        self.finished.emit(results)

    def _work(self, results):
        from qgis.core import QgsGeometry

        from ..aoi import filter_points_in_aoi
        from ..downloaders.cams_downloader import CAMSDownloader
        from ..downloaders.firms_downloader import FIRMSDownloader
        from ..downloaders.gfs_downloader import GFSDownloader
        from ..downloaders.wmts import fetch_aoi_geotiff
        from ..loader import clip_raster_to_aoi, convert_cams, convert_grib

        t = self.tasks
        out_dir = t["output_dir"]
        os.makedirs(out_dir, exist_ok=True)
        cams_bbox = t.get("cams_bbox")
        weather_bbox = t.get("weather_bbox")
        weather_clip = t.get("weather_clip")

        cams_params = t.get("cams_params", [])
        if cams_params:
            self.log.emit(f"=== CAMS: {len(cams_params)} parameter ===")
            dl = CAMSDownloader(t.get("cams_api_key"), t.get("cams_api_url"), out_dir)
            for i, key in enumerate(cams_params):
                label = cams_param_label(key)
                base = int(i / max(len(cams_params), 1) * 100)
                self._emit_progress(base, f"[{i + 1}/{len(cams_params)}] {label}")

                def sub(p, m, _base=base, _span=100 / max(len(cams_params), 1)):
                    self._emit_progress(_base + p / 100.0 * _span, m)

                r = dl.download_parameter(key, t["start_date"], t["end_date"],
                                          cams_bbox, progress_callback=sub,
                                          log_callback=self.log.emit)
                if "error" in r:
                    self.log.emit(f"GAGAL {label}: {r['error']}")
                    results["errors"].append(f"{label}: {r['error']}")
                    continue
                nc_files = r.get("files") or [r["file"]]
                self.log.emit(f"OK {label}: {len(nc_files)} file NetCDF")
                for w in r.get("time_windows", []):
                    self.log.emit(f"   jendela: {w}")
                conv = convert_cams(nc_files, key, r["nc_var"], out_dir,
                                    progress_callback=sub)
                if "error" in conv:
                    self.log.emit(f"GAGAL konversi {label}: {conv['error']}")
                    results["errors"].append(f"{label}: konversi {conv['error']}")
                    continue
                entry = dict(r)
                entry.update(conv)
                results["cams"].append(entry)
                span = ""
                if conv.get("times"):
                    ts = [t for t in conv["times"] if t]
                    if ts:
                        span = (f", {min(ts):%Y-%m-%d %H:%M} s/d "
                                f"{max(ts):%Y-%m-%d %H:%M}")
                self.log.emit(f"   -> {os.path.basename(conv['file'])} "
                              f"({conv['band_count']} band{span})")

        if t.get("hydrocarbon_raster"):
            self.log.emit("=== Raster Hidrokarbon (HO) ===")
            self._emit_progress(80, "Menghitung raster Hidrokarbon (HO)...")
            try:
                from ..analysis import (
                    HYDROCARBON_SURFACE_KEYS,
                    build_hydrocarbon_raster,
                )
                from ..symbology import get_symbology

                specs = []
                for entry in results["cams"]:
                    sp = HYDROCARBON_SURFACE_KEYS.get(entry.get("param_key"))
                    if not sp or any(s["species"] == sp for s in specs):
                        continue
                    unit = (get_symbology(entry.get("variable")) or {}).get(
                        "display_unit") or "ppbv"
                    specs.append({"species": sp, "path": entry["file"],
                                  "unit": unit})
                if not specs:
                    raise RuntimeError(
                        "Tidak ada raster spesies hidrokarbon permukaan "
                        "(C2H6 Surface, dst.) yang berhasil dikonversi. "
                        "Pilih minimal satu parameter hidrokarbon permukaan.")
                hc = build_hydrocarbon_raster(
                    specs, out_dir,
                    progress_callback=lambda p, m: self._emit_progress(
                        80 + p * 0.15, m))
                results["hydrocarbon"] = hc
                self.log.emit(
                    f"OK Hidrokarbon (HO): {os.path.basename(hc['file'])} "
                    f"({len(hc['species_used'])} spesies, "
                    f"{hc['min']:.1f} - {hc['max']:.1f} µg/m3, "
                    f"tanpa klasifikasi ISPU)")
            except Exception as e:
                results["errors"].append(f"Raster Hidrokarbon (HO): {e}")
                self.log.emit(f"GAGAL Raster Hidrokarbon (HO): {e}")

        weather_params = t.get("weather_params", [])
        if weather_params:
            self.log.emit(f"=== Cuaca GFS: {len(weather_params)} parameter ===")
            dl = GFSDownloader(out_dir)
            for i, key in enumerate(weather_params):
                cfg = WEATHER_PARAMS.get(key, {})
                label = cfg.get("label", key)
                base = int(i / max(len(weather_params), 1) * 100)
                self._emit_progress(base, f"[{i + 1}/{len(weather_params)}] {label}")

                def sub(p, m, _base=base, _span=100 / max(len(weather_params), 1)):
                    self._emit_progress(_base + p / 100.0 * _span, m)

                r = dl.download_data(key, t["start_date"], t["end_date"],
                                     weather_bbox, progress_callback=sub)
                if "error" in r:
                    self.log.emit(f"GAGAL {label}: {r['error']}")
                    results["errors"].append(f"{label}: {r['error']}")
                    continue
                for fpath in r.get("files", []):
                    conv = convert_grib(fpath, out_dir, cfg.get("sym"),
                                        progress_callback=sub)
                    if "error" in conv:
                        self.log.emit(f"GAGAL konversi {os.path.basename(fpath)}: "
                                      f"{conv['error']}")
                        continue
                    if weather_clip:
                        clipped = clip_raster_to_aoi(conv["file"], weather_clip)
                        if "error" in clipped:
                            self.log.emit(f"   info: klip AOI: {clipped['error']}")
                        else:
                            self.log.emit("   -> dipotong sesuai poligon AOI")
                    entry = {
                        "file": fpath,
                        "weather_key": key,
                        "label": label,
                        "sym": cfg.get("sym"),
                    }
                    if cfg.get("arrows"):
                        entry["type"] = "wind_arrows"
                    entry.update(conv)
                    results["weather"].append(entry)
                self.log.emit(f"OK {label}: {len(r.get('files', []))} file")
                for err in r.get("errors", []):
                    self.log.emit(f"   info: {err}")

        hotspot = t.get("hotspot") or {}
        if hotspot.get("enabled"):
            self.log.emit("=== Hotspot FIRMS ===")
            dl = FIRMSDownloader(t.get("firms_map_key"), out_dir)
            source = hotspot.get("source", "VIIRS_SNPP_NRT")
            self._emit_progress(10, "Mengunduh hotspot...")
            r = dl.download_hotspot(
                area_coords=hotspot.get("bbox"),
                day_range=int(hotspot.get("day_range", 1)),
                source=source,
                date=hotspot.get("date"),
            )
            if "error" in r:
                self.log.emit(f"GAGAL hotspot: {r['error']}")
                results["errors"].append(f"Hotspot: {r['error']}")
            else:
                file_path, count = r["file"], r["count"]
                clip_wkt = hotspot.get("clip_wkt") or []
                geoms = [g for g in (QgsGeometry.fromWkt(w) for w in clip_wkt)
                         if g is not None and not g.isEmpty()]
                if geoms:
                    clipped_csv = os.path.join(out_dir, "hotspot_aoi.csv")
                    kept = filter_points_in_aoi(file_path, geoms, clipped_csv)
                    if kept is not None:
                        self.log.emit(
                            f"   -> {kept} titik di dalam AOI (dari {count})")
                        file_path, count = clipped_csv, kept
                results["hotspot"] = {
                    "file": file_path,
                    "count": count,
                    "source": source,
                }
                self.log.emit(f"OK hotspot: {count} titik "
                              f"({os.path.basename(file_path)})")
            self._emit_progress(100, "Hotspot selesai")

        gibs = t.get("gibs", [])
        if gibs:
            self.log.emit(f"=== Satelit GIBS: {len(gibs)} layer ===")
            for item in gibs:
                cfg = GIBS_LAYERS.get(item["key"], {})
                entry = {
                    "key": item["key"],
                    "label": cfg.get("label", item["key"]),
                    "date": t.get("gibs_date", ""),
                    "time": t.get("gibs_time", "00:00"),
                }
                if item.get("mode") == "geotiff":
                    self._emit_progress(
                        10, f"Mengunduh citra AOI {entry['label']}...")
                    res = fetch_aoi_geotiff(
                        item["key"], item.get("bbox"), entry["date"],
                        entry["time"], out_dir=item.get("output_dir") or out_dir,
                        zoom=item.get("zoom"))
                    if "error" in res:
                        self.log.emit(f"GAGAL satelit {entry['label']}: "
                                      f"{res['error']}")
                        results["errors"].append(f"Satelit {entry['label']}: "
                                                 f"{res['error']}")
                        continue
                    entry["type"] = "sat_geotiff"
                    entry["file"] = res["file"]
                    self.log.emit(f"OK {entry['label']}: "
                                  f"{os.path.basename(res['file'])} "
                                  f"(z{res['zoom']}, {res['tiles_ok']}/{res['tiles']} tile"
                                  + (f", {res.get('tiles_filled', 0)} diisi induk"
                                     if res.get("tiles_filled") else "")
                                  + (f", {res['tiles_empty']} gelap/malam"
                                     if res.get("tiles_empty") else "") + ")")
                else:
                    entry["type"] = "gibs_wmts"
                    self.log.emit(f"OK {entry['label']}: layer WMTS")
                results["gibs"].append(entry)


class AnalysisWorker(QObject):
    progress = pyqtSignal(int, str)
    log = pyqtSignal(str)
    finished = pyqtSignal(dict)

    def __init__(self, tasks):
        super().__init__()
        self.tasks = tasks

    def run(self):
        results = {}
        try:
            from qgis.core import QgsVectorLayer

            from ..analysis import run_analysis
            from ..loader import clip_raster_to_aoi, mosaic_tifs

            t = self.tasks
            admin_layer = None
            if t.get("admin_source"):
                admin_layer = QgsVectorLayer(t["admin_source"], "admin", "ogr")
                if not admin_layer.isValid():
                    self.log.emit("WARNING: layer admin tidak dapat dibaca; "
                                  "analisis wilayah dilewati")
                    admin_layer = None

            # --- siapkan raster populasi: mosaic folder + clip AOI ---
            pop_path = t.get("pop_path")
            out_dir = t["output_dir"]
            os.makedirs(out_dir, exist_ok=True)
            if t.get("pop_dir"):
                self.log.emit(f"Mosaic TIF penduduk dari: {t['pop_dir']}")
                self.progress.emit(2, "Mosaic raster penduduk...")
                res = mosaic_tifs(t["pop_dir"],
                                  os.path.join(out_dir, "pop_mosaic.tif"))
                if "error" in res:
                    raise RuntimeError(res["error"])
                self.log.emit(f"Mosaic OK: {res['count']} file TIF "
                              f"-> pop_mosaic.tif")
                pop_path = res["file"]

            if pop_path and t.get("aoi_cutline"):
                self.progress.emit(5, "Memotong populasi sesuai AOI...")
                clipped = clip_raster_to_aoi(
                    pop_path, t["aoi_cutline"],
                    out_path=os.path.join(out_dir, "pop_aoi.tif"))
                if "error" in clipped:
                    self.log.emit(f"WARNING: klip AOI populasi: "
                                  f"{clipped['error']}")
                else:
                    pop_path = clipped["file"]
                    self.log.emit("Raster populasi dipotong sesuai AOI")

            time_start = (datetime.fromisoformat(t["time_start"])
                          if t.get("time_start") else None)
            time_end = (datetime.fromisoformat(t["time_end"])
                        if t.get("time_end") else None)
            results = run_analysis(
                t["params"], admin_layer, pop_path,
                t["output_dir"],
                time_start=time_start, time_end=time_end,
                resample_100m=bool(t.get("resample_100m")),
                progress_callback=lambda p, m: self.progress.emit(
                    5 + p * 0.95, m),
            )
            self.log.emit("Analisis ISPU selesai")
        except Exception as e:
            results = {"error": str(e)}
            self.log.emit(f"ERROR: {e}")
        self.finished.emit(results)


class DownloadDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.thread = None
        self.worker = None

        self.setWindowTitle("Unduh Data - Pantau Langit Indonesia")
        self.setMinimumSize(560, 599)
        w, h = settings.get_dialog_size()
        self.resize(max(int(w), 560), max(int(h), 599))

        self._init_ui()
        self._restore_defaults()

    @staticmethod
    def _scroll(widget):
        """Bungkus widget tab dengan scroll area (tinggi jendela minimal 599)."""
        from qgis.PyQt.QtWidgets import QFrame, QScrollArea

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidget(widget)
        return scroll

    def _on_tab_changed(self, index):
        """Sembunyikan elemen yang tidak relevan pada tab tertentu.

        - Analisis & Satelit: tanpa grup 'Waktu & Output'
        - About: hanya gambar (tanpa 'Waktu & Output', baris status, dan kotak log)
        """
        name = self.tabs.tabText(index)
        hide_common = name in ("Analisis", "Satelit (GIBS)", "About")
        self.common_group.setVisible(not hide_common)
        hide_extras = name == "About"
        self.status_label.setVisible(not hide_extras)
        self.progress.setVisible(not hide_extras)
        self.log_box.setVisible(not hide_extras)

    def _build_about_tab(self):
        """Tab About: menampilkan gambar about.jpg."""
        from qgis.PyQt.QtGui import QPixmap

        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)

        self.about_pixmap = QPixmap()
        img_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                                "about.jpg")
        if os.path.exists(img_path):
            self.about_pixmap.load(img_path)

        self.about_label = QLabel()
        self.about_label.setAlignment(Qt.AlignHCenter | Qt.AlignTop)
        if not self.about_pixmap.isNull():
            self.about_label.setPixmap(self.about_pixmap)
        else:
            self.about_label.setText("Gambar About (about.jpg) tidak ditemukan.")
        layout.addWidget(self.about_label)

        self._update_about_pixmap()
        return widget

    def _update_about_pixmap(self):
        """Skalakan gambar About agar muat lebar jendela."""
        if getattr(self, "about_label", None) is None or \
                getattr(self, "about_pixmap", None) is None:
            return
        if self.about_pixmap.isNull():
            return
        width = max(self.width() - 60, 320)
        scaled = self.about_pixmap.scaledToWidth(width, Qt.SmoothTransformation)
        self.about_label.setPixmap(scaled)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_about_pixmap()

    def done(self, result):
        settings.set_dialog_size(self.width(), self.height())
        super().done(result)

    # ------------------------------------------------------------------ UI
    def _init_ui(self):
        layout = QVBoxLayout(self)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._scroll(self._build_cams_tab()), "CAMS (Copernicus)")
        self.tabs.addTab(self._scroll(self._build_hotspot_tab()), "Hotspot (FIRMS)")
        self.tabs.addTab(self._scroll(self._build_weather_tab()), "Cuaca (GFS)")
        self.tabs.addTab(self._scroll(self._build_satellite_tab()), "Satelit (GIBS)")
        self.tabs.addTab(self._scroll(self._build_analysis_tab()), "Analisis")
        self.tabs.addTab(self._scroll(self._build_about_tab()), "About")
        layout.addWidget(self.tabs, stretch=3)
        self.tabs.currentChanged.connect(self._on_tab_changed)

        self.common_group = self._build_common_group()
        layout.addWidget(self.common_group)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        layout.addWidget(self.progress)

        self.status_label = QLabel("Siap.")
        layout.addWidget(self.status_label)

        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMinimumHeight(50)
        layout.addWidget(self.log_box, stretch=1)

        buttons = QHBoxLayout()
        self.btn_settings = QPushButton("Pengaturan API")
        self.btn_settings.clicked.connect(self._open_settings)
        buttons.addWidget(self.btn_settings)
        buttons.addStretch(1)
        self.btn_start = QPushButton("Mulai Download")
        self.btn_start.setDefault(True)
        self.btn_start.clicked.connect(lambda: self._start())
        buttons.addWidget(self.btn_start)
        self.btn_close = QPushButton("Tutup")
        self.btn_close.clicked.connect(self.reject)
        buttons.addWidget(self.btn_close)
        layout.addLayout(buttons)

    def _build_cams_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        from ..aoi import AoiSelector

        self.cams_aoi = AoiSelector()
        layout.addWidget(self.cams_aoi)

        info = QLabel(
            "Parameter atmosfer Copernicus (NetCDF)."
            "Setiap parameter diunduh sebagai file NetCDF."
            "Metadata waktu valid per band."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        self.cams_tree = QTreeWidget()
        self.cams_tree.setHeaderLabels(["Parameter CAMS"])
        self.cams_tree.setRootIsDecorated(True)
        for group_name, keys in CAMS_GROUPS:
            group_item = QTreeWidgetItem([group_name])
            group_item.setFlags(group_item.flags() | Qt.ItemIsUserCheckable)
            group_item.setCheckState(0, Qt.Unchecked)
            for key in keys:
                child = QTreeWidgetItem([CAMS_PARAM_DEFS[key][3]])
                child.setFlags(child.flags() | Qt.ItemIsUserCheckable)
                child.setCheckState(0, Qt.Unchecked)
                child.setData(0, Qt.UserRole, key)
                group_item.addChild(child)
            self.cams_tree.addTopLevelItem(group_item)
        self.cams_tree.itemChanged.connect(self._on_cams_item_changed)
        layout.addWidget(self.cams_tree)

        row = QHBoxLayout()
        btn_all = QPushButton("Centang Semua")
        btn_all.clicked.connect(lambda: self._set_cams_all(True))
        row.addWidget(btn_all)
        btn_none = QPushButton("Kosongkan")
        btn_none.clicked.connect(lambda: self._set_cams_all(False))
        row.addWidget(btn_none)
        row.addStretch(1)
        layout.addLayout(row)

        grp_ho = QGroupBox("Raster Hidrokarbon (HO) untuk ISPU")
        ho_l = QVBoxLayout(grp_ho)
        self.chk_ho = QCheckBox(
            "Download Data Hidrokarbon (HO) [µg/m3]")
        ho_l.addWidget(self.chk_ho)
        note_ho = QLabel(
            "Raster HO = jumlah konsentrasi parameter hidrokarbon (C2H6, C2H4, "
            "C2H5OH, C3H8, C3H6, C5H8, Acetone).")
        note_ho.setWordWrap(True)
        ho_l.addWidget(note_ho)
        layout.addWidget(grp_ho)
        return widget

    def _build_hotspot_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        from ..aoi import AoiSelector

        self.hotspot_aoi = AoiSelector(
            clip_text="Hanya ambil hotspot di dalam poligon AOI",
            clip_default=True)
        layout.addWidget(self.hotspot_aoi)

        self.hotspot_enable = QCheckBox("Unduh titik panas kebakaran (NASA FIRMS)")
        layout.addWidget(self.hotspot_enable)

        form = QFormLayout()
        self.hotspot_source = QComboBox()
        from ..downloaders.firms_downloader import FIRMSDownloader

        for source_id, label in FIRMSDownloader.source_list():
            self.hotspot_source.addItem(label, source_id)
        form.addRow("Satelit sumber", self.hotspot_source)

        self.hotspot_days = QSpinBox()
        self.hotspot_days.setRange(1, 5)
        self.hotspot_days.setValue(1)
        form.addRow("Rentang hari (mundur)", self.hotspot_days)

        self.hotspot_use_date = QCheckBox("Gunakan tanggal spesifik (bukan hari terakhir)")
        form.addRow("", self.hotspot_use_date)
        self.hotspot_date = QDateEdit()
        self.hotspot_date.setCalendarPopup(True)
        self.hotspot_date.setDate(QDate.currentDate().addDays(-1))
        self.hotspot_date.setEnabled(False)
        self.hotspot_use_date.toggled.connect(self.hotspot_date.setEnabled)
        form.addRow("Tanggal", self.hotspot_date)

        layout.addLayout(form)

        note = QLabel(
            "Hasil: file CSV titik panas (latitude, longitude, brightness, frp, "
            "confidence, ...) yang dimuat sebagai layer titik QGIS."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch(1)
        return widget

    def _build_weather_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        from ..aoi import AoiSelector

        self.weather_aoi = AoiSelector(
            clip_text="Potong raster hasil sesuai poligon AOI",
            clip_default=True)
        layout.addWidget(self.weather_aoi)

        info = QLabel(
            "Data cuaca NOAA GFS (GRIB2).")
        info.setWordWrap(True)
        layout.addWidget(info)

        self.weather_checks = {}
        grid = QGridLayout()
        for i, (key, cfg) in enumerate(WEATHER_PARAMS.items()):
            box = QCheckBox(cfg["label"])
            self.weather_checks[key] = box
            grid.addWidget(box, i // 2, i % 2)
        layout.addLayout(grid)
        layout.addStretch(1)
        return widget

    def _build_satellite_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        from ..aoi import AoiSelector

        self.sat_aoi = AoiSelector(
            clip_text="Unduh citra hanya area AOI",
            clip_default=True)
        layout.addWidget(self.sat_aoi)

        info = QLabel(
            "Citra satelit NASA GIBS. Pilih layer yang ingin diunduh lalu "
            "klik <b>Download Citra Satelit</b> di bawah. "
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        form = QFormLayout()
        self.gibs_date = QDateEdit()
        self.gibs_date.setCalendarPopup(True)
        self.gibs_date.setDate(QDate.currentDate())
        form.addRow("Tanggal citra", self.gibs_date)

        row_time = QHBoxLayout()
        row_time.setContentsMargins(0, 0, 0, 0)
        self.gibs_time_combo = QComboBox()
        self.gibs_time_combo.setEditable(True)
        self.gibs_time_combo.addItems(
            [f"{h:02d}:00" for h in range(0, 24, 3)])
        self.gibs_time_combo.setCurrentText("00:00")
        row_time.addWidget(self.gibs_time_combo)
        btn_times = QPushButton("Cek Jam Tersedia")
        btn_times.setToolTip(
            "Ambil daftar jam pengamatan yang benar-benar tersedia "
            "dari katalog GIBS untuk tanggal & layer terpilih")
        btn_times.clicked.connect(self._fetch_sat_times)
        row_time.addWidget(btn_times)
        form.addRow("Jam pengamatan (UTC)", row_time)

        self.gibs_zoom_combo = QComboBox()
        self.gibs_zoom_combo.addItems(["Otomatis"] + [str(z) for z in range(14)])
        self.gibs_zoom_combo.setToolTip(
            "Level zoom tile untuk unduhan mode AOI (GeoTIFF), pilihan z0-z13.\n"
            "Semakin besar z, semakin detail resolusi spasial.\n"
            "Nilai di atas kemampuan layer (mis. MODIS z9, Himawari z6-7) "
            "otomatis dibatasi ke maksimum layer.\n"
            "'Otomatis' = zoom terdalam yang masih wajar.\n"
            "Tile yang gagal/kosong otomatis diisi dari tile induk (lebih "
            "kasar) agar tidak ada area blank di dalam AOI.\n"
            "Catatan: jumlah tile ~4x lipat per kenaikan 1 zoom.")
        form.addRow("Zoom / resolusi (z)", self.gibs_zoom_combo)

        self.sat_dir_edit = QLineEdit()
        self.sat_dir_edit.setPlaceholderText(
            "folder penyimpanan citra hasil unduh")
        btn_sat_dir = QPushButton("Pilih Folder...")
        btn_sat_dir.clicked.connect(self._browse_sat_dir)
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(self.sat_dir_edit)
        row.addWidget(btn_sat_dir)
        form.addRow("Folder penyimpanan", row)
        layout.addLayout(form)

        self.gibs_checks = {}
        grid = QGridLayout()
        row = 0
        groups = {}
        for key, cfg in GIBS_LAYERS.items():
            groups.setdefault(cfg["group"], []).append((key, cfg["label"]))
        col = 0
        for group_name, entries in groups.items():
            label = QLabel(f"<b>{group_name}</b>")
            grid.addWidget(label, row, 0, 1, 2)
            row += 1
            for key, label_text in entries:
                box = QCheckBox(label_text)
                self.gibs_checks[key] = box
                grid.addWidget(box, row, col % 2)
                if col % 2 == 1:
                    row += 1
                col += 1
            if col % 2 == 1:
                row += 1
                col = 0
        layout.addLayout(grid)
        self.btn_sat_download = QPushButton("Download Citra Satelit")
        self.btn_sat_download.setToolTip(
            "Unduh hanya citra satelit yang dicentang di tab ini "
            "(tanpa data CAMS, GFS, maupun hotspot)")
        self.btn_sat_download.clicked.connect(self._start_gibs_only)
        layout.addWidget(self.btn_sat_download)
        layout.addStretch(1)
        return widget

    def _build_analysis_tab(self):
        from qgis.core import QgsMapLayerProxyModel
        from qgis.gui import QgsMapLayerComboBox

        from ..ispu import CATEGORIES, PARAM_LABELS, UNIT_CHOICES
        from ..ispu import category_labels

        widget = QWidget()
        layout = QVBoxLayout(widget)

        info = QLabel(
            "Hitung ISPU sesuai Permen LHK No. 14 Tahun 2020 dari raster "
            "konsentrasi parameter udara, lalu hitung jumlah penduduk "
            "terdampak per wilayah administrasi. Gunakan raster konsentrasi "
            "permukaan."
            "Semua parameter dikonversi ke satuan µg/m3."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        from ..aoi import AoiSelector

        self.analysis_aoi = AoiSelector(
            clip_text="Potong mosaic/populasi sesuai poligon AOI",
            clip_default=True)
        layout.addWidget(self.analysis_aoi)

        grp = QGroupBox("Parameter Udara (raster konsentrasi)")
        grid = QGridLayout(grp)
        grid.addWidget(QLabel("<b>Parameter</b>"), 0, 0)
        grid.addWidget(QLabel("<b>Layer raster</b>"), 0, 1)
        grid.addWidget(QLabel("<b>Satuan</b>"), 0, 2)
        self.analysis_param_rows = {}
        for i, key in enumerate(("pm10", "pm25", "co", "no2", "so2", "o3", "hc"),
                                start=1):
            layer_combo = QgsMapLayerComboBox()
            layer_combo.setFilters(QgsMapLayerProxyModel.RasterLayer)
            layer_combo.setAllowEmptyLayer(True, "(tidak dipakai)")
            unit_combo = QComboBox()
            unit_combo.addItems(UNIT_CHOICES)
            unit_combo.setCurrentText(
                "µg/m3" if key in ("pm10", "pm25") else "ppb")
            grid.addWidget(QLabel(f"<b>{PARAM_LABELS[key]}</b>"), i, 0)
            grid.addWidget(layer_combo, i, 1)
            grid.addWidget(unit_combo, i, 2)
            self.analysis_param_rows[key] = (layer_combo, unit_combo)
        layout.addWidget(grp)

        grp_time = QGroupBox("Waktu Analisis (ISPU = rata-rata 24 jam)")
        gridt = QGridLayout(grp_time)
        self.ispu_time_start = QDateTimeEdit()
        self.ispu_time_start.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.ispu_time_start.setCalendarPopup(True)
        gridt.addWidget(QLabel("Waktu mulai"), 0, 0)
        gridt.addWidget(self.ispu_time_start, 0, 1)
        self.ispu_time_end = QDateTimeEdit()
        self.ispu_time_end.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.ispu_time_end.setCalendarPopup(True)
        gridt.addWidget(QLabel("Waktu akhir"), 1, 0)
        gridt.addWidget(self.ispu_time_end, 1, 1)
        self.chk_resample100 = QCheckBox(
            "Interpolasi ke resolusi 100 m/piksel (butuh RAM besar untuk "
            "area luas; bila tidak muat, resolusi otomatis diperbesar)")
        self.chk_resample100.setChecked(False)
        gridt.addWidget(self.chk_resample100, 2, 0, 1, 2)
        note_time = QLabel(
            "Semua langkah waktu raster di dalam rentang ini dibaca otomatis "
            "dari metadata band (data CAMS per 3 jam: 00, 03, 06, 09, 12, 15, "
            "18, 21, 24) lalu dirata-rata sesuai definisi ISPU 24 jam Permen "
            "LHK 14/2020. Secara bawaan analisis berjalan langsung pada "
            "resolusi asli data (tanpa interpolasi, tampilan sama seperti "
            "unduhan CAMS, jauh lebih ringan)."
        )
        note_time.setWordWrap(True)
        gridt.addWidget(note_time, 3, 0, 1, 2)
        layout.addWidget(grp_time)

        grp2 = QGroupBox("Batas Administrasi (shapefile)")
        grid2 = QGridLayout(grp2)
        self.admin_combo = QgsMapLayerComboBox()
        self.admin_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.admin_combo.setAllowEmptyLayer(True, "(tanpa analisis wilayah)")
        grid2.addWidget(QLabel("Layer poligon"), 0, 0)
        grid2.addWidget(self.admin_combo, 0, 1)
        self.admin_fields_label = QLabel("Field terdeteksi: -")
        self.admin_fields_label.setWordWrap(True)
        grid2.addWidget(self.admin_fields_label, 1, 0, 1, 2)
        self.admin_combo.layerChanged.connect(self._update_admin_fields)
        layout.addWidget(grp2)

        grp3 = QGroupBox("Raster Jumlah Penduduk")
        grid3 = QGridLayout(grp3)
        self.pop_dir_edit = QLineEdit()
        self.pop_dir_edit.setReadOnly(True)
        self.pop_dir_edit.setPlaceholderText(
            "folder berisi file TIF grid populasi...")
        grid3.addWidget(QLabel("Folder TIF"), 0, 0)
        grid3.addWidget(self.pop_dir_edit, 0, 1)
        self.btn_pop_dir = QPushButton("Pilih Folder...")
        self.btn_pop_dir.clicked.connect(self._browse_pop_dir)
        grid3.addWidget(self.btn_pop_dir, 0, 2)

        note = QLabel(
            "Semua file TIF dalam folder (termasuk subfolder) dimuat lalu "
            "di-mosaic lebih dulu, kemudian dipotong sesuai poligon AOI di "
            "atas. Nilai per piksel = jumlah jiwa; penduduk terdampak "
            "dihitung pada area dengan ISPU >= 101. Kosongkan bila tanpa "
            "hitung penduduk."
        )
        note.setWordWrap(True)
        grid3.addWidget(note, 1, 0, 1, 3)
        layout.addWidget(grp3)

        grp4 = QGroupBox("Kategori ISPU (Permen LHK 14/2020 - Lampiran II)")
        grid4 = QGridLayout(grp4)
        for i, (cat, label) in enumerate(zip(CATEGORIES, category_labels())):
            swatch = QLabel()
            swatch.setFixedSize(28, 16)
            swatch.setStyleSheet(
                f"background-color: {cat[4]}; border: 1px solid #666;")
            grid4.addWidget(swatch, i, 0)
            grid4.addWidget(QLabel(label), i, 1)
        layout.addWidget(grp4)

        grp5 = QGroupBox("Penyimpanan Hasil Analisis")
        grid5 = QGridLayout(grp5)
        self.analysis_dir_edit = QLineEdit()
        self.analysis_dir_edit.setPlaceholderText(
            "folder output raster ISPU, kelas, dan GeoPackage admin...")
        grid5.addWidget(QLabel("Folder output"), 0, 0)
        grid5.addWidget(self.analysis_dir_edit, 0, 1)
        btn_out_dir = QPushButton("Pilih Folder...")
        btn_out_dir.clicked.connect(self._browse_analysis_dir)
        grid5.addWidget(btn_out_dir, 0, 2)
        layout.addWidget(grp5)

        self.btn_run_analysis = QPushButton("Jalankan Analisis ISPU")
        self.btn_run_analysis.clicked.connect(self._run_analysis)
        layout.addWidget(self.btn_run_analysis)

        layout.addStretch(1)
        return widget

    def _update_admin_fields(self, layer=None):
        if layer is None:
            self.admin_fields_label.setText("Field terdeteksi: -")
            return
        from ..ispu import detect_admin_fields

        fields = detect_admin_fields(layer)
        text = " | ".join(f"{k.title()}: {v or '-'}" for k, v in fields.items())
        self.admin_fields_label.setText(f"Field terdeteksi: {text}")

    def _browse_pop_dir(self):
        path = QFileDialog.getExistingDirectory(
            self, "Pilih Folder Berisi File TIF Penduduk")
        if path:
            self.pop_dir_edit.setText(path)

    def _browse_analysis_dir(self):
        path = QFileDialog.getExistingDirectory(
            self, "Pilih Folder Penyimpanan Hasil Analisis")
        if path:
            self.analysis_dir_edit.setText(path)

    def _browse_sat_dir(self):
        path = QFileDialog.getExistingDirectory(
            self, "Pilih Folder Penyimpanan Citra Satelit")
        if path:
            self.sat_dir_edit.setText(path)

    def _fetch_sat_times(self):
        """Ambil jam pengamatan yang tersedia dari katalog GIBS."""
        from qgis.PyQt.QtWidgets import QApplication

        from ..downloaders.wmts import fetch_available_times
        from ..params import GIBS_LAYERS

        keys = self._selected_gibs()
        if not keys:
            QMessageBox.warning(self, "Satelit",
                                "Pilih minimal satu layer satelit dahulu.")
            return
        date = self.gibs_date.date().toString("yyyy-MM-dd")

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            times = set()
            for key in keys:
                cfg = GIBS_LAYERS.get(key, {})
                if cfg.get("time_type") != "datetime":
                    continue
                times.update(fetch_available_times(key, date))
        finally:
            QApplication.restoreOverrideCursor()

        if times:
            ordered = sorted(times)
            self.gibs_time_combo.clear()
            self.gibs_time_combo.addItems(ordered)
            self.gibs_time_combo.setCurrentIndex(len(ordered) // 2)
            self._append_log(f"Jam tersedia ({date}): {len(ordered)} opsi "
                             f"({ordered[0]} - {ordered[-1]} UTC)")
            visible = [
                GIBS_LAYERS.get(k, {}).get("label", k) for k in keys
                if any(t in str(GIBS_LAYERS.get(k, {}).get("layer", "")).lower()
                       for t in ("visible", "truecolor", "correctedreflectance",
                                 "naturalcolor", "red_visible"))
            ]
            if visible:
                self._append_log(
                    "INFO: layer tampak-terlihat (Visible/TrueColor) hanya "
                    "berisi citra saat SIANG — untuk Indonesia pilih jam "
                    "23:00-13:00 UTC (06:00-20:00 WIB).")
        else:
            daily = [
                GIBS_LAYERS.get(k, {}).get("label", k) for k in keys
                if GIBS_LAYERS.get(k, {}).get("time_type") != "datetime"
            ]
            if daily:
                self.gibs_time_combo.clear()
                self.gibs_time_combo.addItems(["00:00"])
                self._append_log("Layer harian terpilih — jam pengamatan "
                                 "tidak dipakai.")
            else:
                QMessageBox.information(
                    self, "Satelit",
                    f"Tidak ada jam tersedia pada {date} untuk layer "
                    f"sub-harian terpilih.\nCoba tanggal lain.")

    def _build_common_group(self):
        group = QGroupBox("Waktu & Output")
        layout = QGridLayout(group)

        layout.addWidget(QLabel("Tanggal mulai"), 0, 0)
        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.start_date.setDisplayFormat("yyyy-MM-dd")
        layout.addWidget(self.start_date, 0, 1)

        layout.addWidget(QLabel("Tanggal akhir"), 1, 0)
        self.end_date = QDateEdit()
        self.end_date.setCalendarPopup(True)
        self.end_date.setDisplayFormat("yyyy-MM-dd")
        layout.addWidget(self.end_date, 1, 1)

        layout.addWidget(QLabel("Folder unduhan"), 2, 0)
        self.output_dir = QLineEdit()
        layout.addWidget(self.output_dir, 2, 1)
        browse = QPushButton("...")
        browse.setFixedWidth(32)
        browse.clicked.connect(self._browse_output)
        layout.addWidget(browse, 2, 2)

        return group

    def _restore_defaults(self):
        today = QDate.currentDate()
        self.start_date.setDate(today.addDays(-3))
        self.end_date.setDate(today.addDays(-1))
        out = settings.get_download_dir()
        if not out:
            out = os.path.join(os.path.expanduser("~"), "PantauLangitDownload")
        self.output_dir.setText(out)
        self.analysis_dir_edit.setText(os.path.join(out, "analisis_ispu"))
        self.sat_dir_edit.setText(os.path.join(out, "satelit"))
        now = QDateTime.currentDateTime()
        self.ispu_time_end.setDateTime(now)
        self.ispu_time_start.setDateTime(now.addSecs(-24 * 3600))

    # ------------------------------------------------------------- helpers
    def _on_cams_item_changed(self, item, column):
        if item.childCount() > 0:
            state = item.checkState(0)
            self.cams_tree.blockSignals(True)
            for i in range(item.childCount()):
                item.child(i).setCheckState(0, state)
            self.cams_tree.blockSignals(False)

    def _set_cams_all(self, checked):
        state = Qt.Checked if checked else Qt.Unchecked
        self.cams_tree.blockSignals(True)
        for i in range(self.cams_tree.topLevelItemCount()):
            group = self.cams_tree.topLevelItem(i)
            group.setCheckState(0, state)
            for j in range(group.childCount()):
                group.child(j).setCheckState(0, state)
        self.cams_tree.blockSignals(False)

    def _selected_cams(self):
        keys = []
        for i in range(self.cams_tree.topLevelItemCount()):
            group = self.cams_tree.topLevelItem(i)
            for j in range(group.childCount()):
                child = group.child(j)
                if child.checkState(0) == Qt.Checked:
                    keys.append(child.data(0, Qt.UserRole))
        return keys

    def _selected_weather(self):
        return [k for k, box in self.weather_checks.items() if box.isChecked()]

    def _selected_gibs(self):
        return [k for k, box in self.gibs_checks.items() if box.isChecked()]

    def _browse_output(self):
        path = QFileDialog.getExistingDirectory(self, "Pilih Folder Unduhan")
        if path:
            self.output_dir.setText(path)

    def _open_settings(self):
        dlg = SettingsDialog(self)
        dlg.exec_()

    def _append_log(self, text):
        self.log_box.appendPlainText(text)

    # -------------------------------------------------------------- start
    def _start(self, only_gibs=False):
        from ..aoi import export_cutline
        from ..params import INDONESIA_BBOX

        cams_params = self._selected_cams()
        hydrocarbon_raster = self.chk_ho.isChecked()
        if hydrocarbon_raster:
            from ..analysis import HYDROCARBON_SURFACE_KEYS

            added = [k for k in HYDROCARBON_SURFACE_KEYS
                     if k not in cams_params]
            if added:
                cams_params.extend(added)
                self._append_log(
                    "INFO: parameter hidrokarbon permukaan otomatis "
                    f"ditambahkan: {', '.join(added)}")
        weather_params = self._selected_weather()
        gibs = self._selected_gibs()
        hotspot_enabled = self.hotspot_enable.isChecked()

        if only_gibs:
            # unduh hanya citra satelit (tanpa CAMS/GFS/hotspot)
            cams_params = []
            hydrocarbon_raster = False
            weather_params = []
            hotspot_enabled = False

        if not any([cams_params, weather_params, gibs, hotspot_enabled]):
            QMessageBox.warning(self, "Unduh Data",
                                "Tidak ada parameter yang dipilih.")
            return

        # --- AOI per tab ---
        cams_bbox = self.cams_aoi.bbox()
        if cams_params and cams_bbox is None:
            self._append_log("INFO: AOI CAMS belum dipilih -> extent Indonesia")
            cams_bbox = list(INDONESIA_BBOX)

        weather_bbox = self.weather_aoi.bbox()
        weather_clip = None
        if weather_params:
            if weather_bbox is None:
                self._append_log("INFO: AOI Cuaca belum dipilih -> extent Indonesia")
                weather_bbox = list(INDONESIA_BBOX)
            if self.weather_aoi.clip_enabled():
                weather_clip = export_cutline(self.weather_aoi.current_layer())

        hotspot_bbox = self.hotspot_aoi.bbox()
        clip_wkt = []
        if hotspot_enabled:
            if hotspot_bbox is None:
                self._append_log("INFO: AOI Hotspot belum dipilih -> extent Indonesia")
                hotspot_bbox = list(INDONESIA_BBOX)
            if self.hotspot_aoi.clip_enabled():
                clip_wkt = [g.asWkt() for g in self.hotspot_aoi.geometries()]

        sat_bbox = self.sat_aoi.bbox()
        sat_clip = self.sat_aoi.clip_enabled()
        if gibs and sat_clip and sat_bbox is None:
            QMessageBox.warning(
                self, "Unduh Data",
                "Opsi \"Unduh citra hanya area AOI\" aktif tetapi AOI belum "
                "dipilih.\nPilih/muat layer poligon AOI pada tab Satelit, "
                "atau matikan opsi tersebut.")
            return

        # --- validasi API key ---
        if cams_params and not settings.get_cams_api_key():
            QMessageBox.warning(
                self, "API Key",
                "CDS API Key belum dikonfigurasi!\nBuka 'Pengaturan API'.")
            return

        if hotspot_enabled and not settings.get_firms_map_key():
            QMessageBox.warning(
                self, "API Key",
                "NASA FIRMS MAP_KEY belum dikonfigurasi!\nBuka 'Pengaturan API'.")
            return

        output_dir = self.output_dir.text().strip()
        if not output_dir:
            QMessageBox.warning(self, "Unduh Data", "Folder unduhan belum dipilih.")
            return

        start = self.start_date.date().toString("yyyy-MM-dd")
        end = self.end_date.date().toString("yyyy-MM-dd")
        if self.start_date.date() > self.end_date.date():
            QMessageBox.warning(self, "Unduh Data",
                                "Tanggal mulai harus sebelum tanggal akhir.")
            return

        hotspot = {
            "enabled": hotspot_enabled,
            "source": self.hotspot_source.currentData(),
            "day_range": self.hotspot_days.value(),
            "date": (self.hotspot_date.date().toString("yyyy-MM-dd")
                     if self.hotspot_use_date.isChecked() else None),
            "bbox": hotspot_bbox,
            "clip_wkt": clip_wkt,
        }

        sat_dir = self.sat_dir_edit.text().strip()
        if not sat_dir:
            base = (settings.get_download_dir()
                    or os.path.join(os.path.expanduser("~"),
                                    "PantauLangitDownload"))
            sat_dir = os.path.join(base, "satelit")

        zoom_text = self.gibs_zoom_combo.currentText().strip()
        sat_zoom = int(zoom_text) if zoom_text.isdigit() else None

        gibs_tasks = [
            {"key": k,
             "mode": "geotiff" if (sat_clip and sat_bbox) else "wmts",
             "bbox": sat_bbox,
             "output_dir": sat_dir,
             "zoom": sat_zoom}
            for k in gibs
        ]

        if only_gibs and gibs_tasks and gibs_tasks[0]["mode"] == "wmts":
            jawab = QMessageBox.question(
                self, "Satelit GIBS",
                "Opsi \"Unduh citra hanya area AOI\" belum aktif, sehingga "
                "citra akan ditambahkan sebagai layer WMTS (streaming online) "
                "tanpa file yang diunduh.\n\n"
                "Lanjutkan sebagai layer WMTS?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if jawab != QMessageBox.Yes:
                return

        tasks = {
            "cams_params": cams_params,
            "cams_bbox": cams_bbox,
            "weather_params": weather_params,
            "weather_bbox": weather_bbox,
            "weather_clip": weather_clip,
            "hotspot": hotspot,
            "gibs": gibs_tasks,
            "start_date": start,
            "end_date": end,
            "gibs_date": self.gibs_date.date().toString("yyyy-MM-dd"),
            "gibs_time": self.gibs_time_combo.currentText().strip() or "00:00",
            "output_dir": output_dir,
            "cams_api_key": settings.get_cams_api_key(),
            "cams_api_url": settings.get_cams_api_url(),
            "firms_map_key": settings.get_firms_map_key(),
            "hydrocarbon_raster": hydrocarbon_raster,
        }

        settings.set_download_dir(output_dir)

        self.btn_start.setEnabled(False)
        self.btn_sat_download.setEnabled(False)
        self.btn_run_analysis.setEnabled(False)
        self.btn_close.setEnabled(False)
        self.progress.setValue(0)
        self.log_box.clear()
        self._append_log(f"Mulai unduhan {datetime.now():%Y-%m-%d %H:%M:%S}")
        if cams_params:
            self._append_log(f"AOI CAMS (W,S,E,N): {cams_bbox}")
        if weather_params:
            self._append_log(f"AOI Cuaca (W,S,E,N): {weather_bbox}")
        if hotspot_enabled:
            self._append_log(f"AOI Hotspot (W,S,E,N): {hotspot_bbox}")
        if gibs:
            mode = tasks["gibs"][0]["mode"]
            self._append_log(f"Mode satelit: {mode}")
        self._append_log(f"Rentang tanggal: {start} s/d {end}")
        rencana = []
        if cams_params:
            rencana.append(f"CAMS {len(cams_params)} parameter")
        if hydrocarbon_raster:
            rencana.append("raster Hidrokarbon (HO)")
        if weather_params:
            rencana.append(f"Cuaca GFS {len(weather_params)} parameter")
        if hotspot_enabled:
            rencana.append("Hotspot FIRMS")
        if gibs:
            ket = ("GeoTIFF (diunduh)" if gibs_tasks[0]["mode"] == "geotiff"
                   else "WMTS (streaming, tanpa file)")
            rencana.append(f"Satelit GIBS {len(gibs)} layer [{ket}]")
        self._append_log("Rencana unduh: " + " | ".join(rencana))

        self.thread = QThread()
        self.worker = DownloadWorker(tasks)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self._on_progress)
        self.worker.log.connect(self._append_log)
        self.worker.finished.connect(self._on_finished)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()


    def _start_gibs_only(self):
        """Unduh hanya citra satelit yang dicentang (tanpa CAMS/GFS/hotspot)."""
        if not self._selected_gibs():
            QMessageBox.warning(self, "Satelit GIBS",
                                "Belum ada layer satelit yang dicentang.")
            return
        self._start(only_gibs=True)

    def _run_analysis(self):
        from ..ispu import PARAM_LABELS

        params = []
        for key, (layer_combo, unit_combo) in \
                self.analysis_param_rows.items():
            layer = layer_combo.currentLayer()
            if layer is None:
                continue
            src = layer.source()
            if not src or not os.path.exists(src):
                QMessageBox.warning(
                    self, "Analisis",
                    f"Layer {PARAM_LABELS[key]} harus berupa file raster "
                    f"yang tersimpan di disk.")
                return
            params.append({"key": key, "path": src,
                           "unit": unit_combo.currentText()})

        if not params:
            QMessageBox.warning(self, "Analisis",
                                "Pilih minimal satu parameter udara.")
            return

        time_start = self.ispu_time_start.dateTime().toPyDateTime()
        time_end = self.ispu_time_end.dateTime().toPyDateTime()
        if time_start >= time_end:
            QMessageBox.warning(
                self, "Analisis",
                "Waktu mulai harus lebih awal daripada waktu akhir.")
            return

        admin_source = None
        admin_layer = self.admin_combo.currentLayer()
        if admin_layer is not None:
            admin_source = admin_layer.source()
            if not admin_source or not os.path.exists(admin_source):
                QMessageBox.warning(
                    self, "Analisis",
                    "Layer batas administrasi harus berupa file (shapefile) "
                    "yang tersimpan di disk.")
                return

        pop_dir = self.pop_dir_edit.text().strip()
        if pop_dir:
            if not os.path.isdir(pop_dir):
                QMessageBox.warning(
                    self, "Analisis",
                    f"Folder TIF penduduk tidak ditemukan:\n{pop_dir}")
                return
            has_tif = any(n.lower().endswith((".tif", ".tiff"))
                          for _r, _d, names in os.walk(pop_dir) for n in names)
            if not has_tif:
                QMessageBox.warning(
                    self, "Analisis",
                    f"Tidak ada file .tif/.tiff di folder:\n{pop_dir}")
                return

        # cutline AOI untuk memotong mosaic/raster populasi
        aoi_cutline = None
        if pop_dir and self.analysis_aoi.clip_enabled():
            from ..aoi import export_cutline

            aoi_cutline = export_cutline(self.analysis_aoi.current_layer())

        out = self.analysis_dir_edit.text().strip()
        if not out:
            base = (settings.get_download_dir()
                    or os.path.join(os.path.expanduser("~"),
                                    "PantauLangitDownload"))
            out = os.path.join(base, "analisis_ispu")

        tasks = {
            "params": params,
            "admin_source": admin_source,
            "pop_dir": pop_dir or None,
            "aoi_cutline": aoi_cutline,
            "time_start": time_start.isoformat(sep=" "),
            "time_end": time_end.isoformat(sep=" "),
            "resample_100m": self.chk_resample100.isChecked(),
            "output_dir": out,
        }

        self.btn_start.setEnabled(False)
        self.btn_sat_download.setEnabled(False)
        self.btn_run_analysis.setEnabled(False)
        self.btn_close.setEnabled(False)
        self.progress.setValue(0)
        self._append_log("=== Analisis ISPU (Permen LHK 14/2020) ===")
        self._append_log(f"  Waktu: {time_start:%Y-%m-%d %H:%M} s/d "
                         f"{time_end:%Y-%m-%d %H:%M} (rata-rata 24 jam)")
        for p in params:
            self._append_log(
                f"  {PARAM_LABELS[p['key']]}: {os.path.basename(p['path'])} "
                f"({p['unit']})")
        self._append_log("  Interpolasi ke 100 m/piksel")
        self._append_log(f"  Output: {out}")

        self.thread = QThread()
        self.worker = AnalysisWorker(tasks)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self._on_progress)
        self.worker.log.connect(self._append_log)
        self.worker.finished.connect(self._on_analysis_finished)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def _on_analysis_finished(self, results):
        self.btn_start.setEnabled(True)
        self.btn_sat_download.setEnabled(True)
        self.btn_run_analysis.setEnabled(True)
        self.btn_close.setEnabled(True)

        if results.get("error"):
            self.progress.setValue(0)
            QMessageBox.critical(self, "Analisis",
                                 f"Analisis gagal:\n{results['error']}")
            self.thread = None
            self.worker = None
            return

        self.progress.setValue(100)
        self.status_label.setText("Analisis ISPU selesai.")

        from ..analysis import make_result_layers
        from ..ispu import CATEGORIES

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        group_name = f"Analisis ISPU | Permen LHK 14/2020 | {timestamp}"
        count = make_result_layers(results, group_name)

        lines = [f"Analisis selesai. {count} layer masuk ke group:"]
        lines.append(f"{group_name}")
        if results.get("resolution_note"):
            lines.append("")
            lines.append(f"Catatan: {results['resolution_note']}")
        stats = results.get("stats") or {}
        if stats:
            fpk = stats.get("fitur_per_kategori", {})
            lines.append("")
            lines.append(f"Wilayah dianalisis : {stats.get('fitur', 0)}")
            lines.append("Per kategori       : " + ", ".join(
                f"{c[0]}={fpk.get(c[2], 0)}" for c in CATEGORIES))
            lines.append(f"Total penduduk     : {int(stats.get('pop_total', 0))} jiwa")
            lines.append(f"Penduduk terdampak (ISPU >= 101): "
                         f"{int(stats.get('pop_terdampak', 0))} jiwa")
        QMessageBox.information(self, "Analisis ISPU", "\n".join(lines))

        self.thread = None
        self.worker = None

    def _on_progress(self, pct, msg):
        self.progress.setValue(max(0, min(100, int(pct))))
        self.status_label.setText(msg)

    def _on_finished(self, results):
        self.btn_start.setEnabled(True)
        self.btn_sat_download.setEnabled(True)
        self.btn_close.setEnabled(True)
        self.progress.setValue(100)
        self.status_label.setText("Selesai.")

        loaded = self._load_results(results)

        lines = [f"Selesai. {loaded} layer ditambahkan ke proyek."]
        if results.get("errors"):
            lines.append(f"{len(results['errors'])} error:")
            lines.extend(" - " + e[:160] for e in results["errors"][:8])
        QMessageBox.information(self, "Unduh Data", "\n".join(lines))

        self.thread = None
        self.worker = None

    def _load_results(self, results):
        from qgis.core import QgsProject

        from ..loader import (
            configure_temporal_controller,
            make_hotspot_layer,
            make_raster_layer,
            make_wmts_layer,
        )

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        root = QgsProject.instance().layerTreeRoot()
        group = root.insertGroup(0, f"Pantau Langit | {timestamp}")
        count = 0

        def add(layer):
            nonlocal count
            if layer is not None:
                QgsProject.instance().addMapLayer(layer, False)
                group.addLayer(layer)
                count += 1

        for item in results.get("cams", []):
            layer = make_raster_layer(item.get("file"), item.get("label", "CAMS"),
                                      item.get("nc_var"),
                                      item.get("min"), item.get("max"))
            if layer is None:
                results.setdefault("errors", []).append(
                    f"Gagal memuat {item.get('file')}")
            add(layer)

        hc = results.get("hydrocarbon")
        if hc and hc.get("file"):
            layer = make_raster_layer(hc["file"], "Hidrokarbon (HO) [µg/m3]",
                                      "ho", hc.get("min"), hc.get("max"))
            if layer is None:
                results.setdefault("errors", []).append(
                    f"Gagal memuat {hc['file']}")
            add(layer)

        for item in results.get("weather", []):
            if item.get("type") == "wind_arrows":
                from ..loader import make_wind_arrow_layer

                layer = make_wind_arrow_layer(
                    item.get("file"), item.get("label", "Arah Angin"))
                if layer is None:
                    results.setdefault("errors", []).append(
                        f"Gagal membuat panah {item.get('label')}")
                add(layer)
                continue
            layer = make_raster_layer(item.get("file"), item.get("label", "GFS"),
                                      item.get("sym"),
                                      item.get("min"), item.get("max"))
            if layer is None:
                results.setdefault("errors", []).append(
                    f"Gagal memuat {item.get('file')}")
            add(layer)

        hotspot = results.get("hotspot")
        if hotspot and hotspot.get("file"):
            label = f"Hotspot | {hotspot.get('source', '')} ({hotspot.get('count', 0)} titik)"
            layer = make_hotspot_layer(hotspot["file"], label)
            if layer is not None:
                try:
                    layer.saveNamedStyle(
                        os.path.splitext(hotspot["file"])[0] + ".qml")
                except Exception:
                    pass
            add(layer)

        for item in results.get("gibs", []):
            if item.get("type") == "sat_geotiff" and item.get("file"):
                from qgis.core import QgsRasterLayer

                name = (f"Satelit | {item.get('label')} "
                        f"({item.get('date', '')})")
                layer = QgsRasterLayer(item["file"], name)
                add(layer if layer.isValid() else None)
            else:
                layer = make_wmts_layer(item["key"], item.get("date", ""),
                                        item.get("time", "00:00"))
                if layer is None:
                    results.setdefault("errors", []).append(
                        f"Gagal memuat layer satelit {item.get('label')}")
                add(layer)

        # --- Temporal Control: setel controller ke rentang waktu data ---
        all_times = []
        for item in results.get("cams", []):
            all_times.extend(item.get("times") or [])
        for item in results.get("weather", []):
            all_times.extend(item.get("times") or [])
        if all_times and configure_temporal_controller(self.iface, all_times):
            ts = sorted({t for t in all_times if t})
            self._append_log(
                "Temporal Control QGIS disetel ke rentang "
                f"{ts[0]:%Y-%m-%d %H:%M} s/d {ts[-1]:%Y-%m-%d %H:%M} "
                "(langkah mengikuti data). Buka panel Temporal Controller "
                "lalu tekan Play untuk animasi.")

        return count

    def closeEvent(self, event):
        if self.thread is not None and self.thread.isRunning():
            QMessageBox.warning(self, "Unduh Data",
                                "Unduhan masih berlangsung. Tunggu hingga selesai.")
            event.ignore()
            return
        event.accept()
