from qgis.PyQt.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)

from .. import settings


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pengaturan API - Pantau Langit Indonesia")
        self.setMinimumWidth(520)

        layout = QVBoxLayout(self)

        info = QLabel(
            "API key disimpan di profil QGIS Anda (QgsSettings) dan tidak "
            "dibagikan ke pihak lain."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        form = QFormLayout()

        self.cds_key = QLineEdit()
        self.cds_key.setEchoMode(QLineEdit.Password)
        self.cds_key.setText(settings.get_cams_api_key())
        self.cds_key.setToolTip(
            "API Key Copernicus Climate Data Store.\n"
            "Dapatkan di: https://cds.climate.copernicus.eu/how-to-api"
        )
        form.addRow("CDS API Key", self._with_show(self.cds_key))

        self.cds_url = QLineEdit()
        self.cds_url.setText(settings.get_cams_api_url())
        self.cds_url.setToolTip(
            "URL API CDS/ADS. Default:\nhttps://ads.atmosphere.copernicus.eu/api"
        )
        form.addRow("CDS API URL", self.cds_url)

        self.firms_key = QLineEdit()
        self.firms_key.setEchoMode(QLineEdit.Password)
        self.firms_key.setText(settings.get_firms_map_key())
        self.firms_key.setToolTip(
            "NASA FIRMS MAP_KEY.\n"
            "Dapatkan di: https://firms.modaps.eosdis.nasa.gov/api/map_key"
        )
        form.addRow("FIRMS MAP_KEY", self._with_show(self.firms_key))

        self.download_dir = QLineEdit()
        self.download_dir.setText(settings.get_download_dir())
        browse = QPushButton("...")
        browse.setFixedWidth(32)
        browse.clicked.connect(self._browse_dir)
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(self.download_dir)
        row.addWidget(browse)
        form.addRow("Folder Unduhan", row)

        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    @staticmethod
    def _with_show(line_edit):
        toggle = QPushButton("Tampilkan")
        toggle.setCheckable(True)
        toggle.setFixedWidth(88)
        toggle.toggled.connect(
            lambda on: line_edit.setEchoMode(
                QLineEdit.Normal if on else QLineEdit.Password
            )
        )
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(line_edit)
        row.addWidget(toggle)
        from qgis.PyQt.QtWidgets import QWidget

        w = QWidget()
        w.setLayout(row)
        return w

    def _browse_dir(self):
        path = QFileDialog.getExistingDirectory(self, "Pilih Folder Unduhan")
        if path:
            self.download_dir.setText(path)

    def _save(self):
        settings.set_cams_api_key(self.cds_key.text())
        settings.set_cams_api_url(self.cds_url.text())
        settings.set_firms_map_key(self.firms_key.text())
        settings.set_download_dir(self.download_dir.text())
        self.accept()
