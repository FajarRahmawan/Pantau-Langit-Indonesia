"""Analisis ISPU (Permen LHK 14/2020) + penduduk terdampak per wilayah administrasi."""

import math
import os
import re
from datetime import datetime, timedelta

import numpy as np

from .ispu import (
    CATEGORIES,
    NODATA,
    PARAM_LABELS,
    classify_ispu,
    compute_ispu,
    detect_admin_fields,
    unit_factor,
)

GRID_TOL = 1e-9
RES_M = 100.0            # resolusi opsional analisis: 100 m/piksel
MAX_GRID_CELLS = 32_000_000   # batas sel aman RAM; resolusi otomatis
                             # diperbesar bila terlampaui (mode 100 m)

BAND_TIME_RE = re.compile(r"(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})")
LEAD_RE = re.compile(r"\+(\d+)h")


# ---------------------------------------------------------------------------
# Utilitas raster (GDAL)
# ---------------------------------------------------------------------------
def _open_raster(path):
    from osgeo import gdal

    ds = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f"Gagal membuka raster: {path}")
    return ds


def _read_band(path, band_idx):
    """Baca satu band sebagai array float64 + (geotransform, proj, nodata)."""
    ds = _open_raster(path)
    if band_idx < 1 or band_idx > ds.RasterCount:
        raise RuntimeError(
            f"{os.path.basename(path)}: band {band_idx} tidak ada "
            f"(jumlah band: {ds.RasterCount})")
    band = ds.GetRasterBand(band_idx)
    arr = band.ReadAsArray().astype(np.float64)
    nodata = band.GetNoDataValue()
    if nodata is not None:
        arr[arr == nodata] = np.nan
    arr[~np.isfinite(arr)] = np.nan
    return arr, ds.GetGeoTransform(), ds.GetProjection(), ds


def _warp_to_grid(path, band_idx, bounds, width, height, proj):
    """Resample band ke grid referensi (bilinear) -> array float64."""
    from osgeo import gdal

    xmin, ymin, xmax, ymax = bounds
    warped = gdal.Warp(
        "", _open_raster(path), format="MEM", bandList=[band_idx],
        outputBounds=(xmin, ymin, xmax, ymax), width=width, height=height,
        resampleAlg="bilinear",
    )
    arr = warped.GetRasterBand(1).ReadAsArray().astype(np.float64)
    nodata = warped.GetRasterBand(1).GetNoDataValue()
    if nodata is not None:
        arr[arr == nodata] = np.nan
    arr[~np.isfinite(arr)] = np.nan
    return arr


def _write_tif(path, arr, geotransform, proj, dtype="float32", nodata=NODATA):
    from osgeo import gdal

    drv = gdal.GetDriverByName("GTiff")
    h, w = arr.shape
    gdt = gdal.GDT_Float32 if dtype == "float32" else gdal.GDT_Byte
    ds = drv.Create(path, w, h, 1, gdt, options=["COMPRESS=LZW", "TILED=NO"])
    ds.SetGeoTransform(geotransform)
    ds.SetProjection(proj)
    band = ds.GetRasterBand(1)
    out = np.array(arr, dtype=np.float32 if dtype == "float32" else np.uint8)
    if dtype == "float32":
        out[~np.isfinite(out)] = nodata
        band.SetNoDataValue(nodata)
    else:
        band.SetNoDataValue(0)
    band.WriteArray(out)
    ds.FlushCache()
    ds = None
    return path


# ---------------------------------------------------------------------------
# Waktu band (data multi-temporal) & interpolasi grid 100 m
# ---------------------------------------------------------------------------
def parse_band_time(description):
    """Waktu valid band dari deskripsi ('YYYY-MM-DD HH:MM [+Nh]')."""
    if not description:
        return None
    m = BAND_TIME_RE.search(str(description))
    if not m:
        return None
    try:
        dt = datetime.strptime(f"{m.group(1)} {m.group(2)}", "%Y-%m-%d %H:%M")
    except ValueError:
        return None
    m2 = LEAD_RE.search(str(description))
    if m2:
        dt += timedelta(hours=int(m2.group(1)))
    return dt


def select_time_bands(path, time_start=None, time_end=None):
    """Pilih band berdasarkan waktu valid pada metadata band.

    return (list band 1-based, list waktu per band, ada_metadata_waktu).
    Bila tidak ada metadata waktu -> semua band (fallback).
    """
    ds = _open_raster(path)
    times = [parse_band_time(ds.GetRasterBand(b).GetDescription())
             for b in range(1, ds.RasterCount + 1)]
    if not any(t is not None for t in times):
        return list(range(1, ds.RasterCount + 1)), times, False
    sel = []
    for b, t in zip(range(1, ds.RasterCount + 1), times):
        if t is None:
            continue
        if time_start is not None and t < time_start:
            continue
        if time_end is not None and t > time_end:
            continue
        sel.append(b)
    return sel, times, True


def _average_bands(path, bands):
    """Rata-rata (nanmean) beberapa band -> array, (gt, proj)."""
    ds = _open_raster(path)
    arrays = []
    for b in bands:
        band = ds.GetRasterBand(b)
        arr = band.ReadAsArray().astype(np.float64)
        nodata = band.GetNoDataValue()
        if nodata is not None:
            arr[arr == nodata] = np.nan
        arr[~np.isfinite(arr)] = np.nan
        arrays.append(arr)
    with np.errstate(invalid="ignore"):
        avg = np.nanmean(np.stack(arrays), axis=0)
    return avg, ds.GetGeoTransform(), ds.GetProjection()


def _reference_grid_100m(bounds, center_lat, res_m=RES_M):
    """Grid referensi ~100 m (derajat sesuai lintang pusat)."""
    import math

    lat = min(max(center_lat, -80.0), 80.0)
    lon_res = res_m / (111320.0 * math.cos(math.radians(lat)))
    lat_res = res_m / 110574.0
    xmin, ymin, xmax, ymax = bounds
    width = max(1, int(math.ceil((xmax - xmin) / lon_res)))
    height = max(1, int(math.ceil((ymax - ymin) / lat_res)))
    gt = (xmin, lon_res, 0.0, ymax, 0.0, -lat_res)
    return gt, width, height


def _native_reference_grid(bounds, gts):
    """Grid referensi beresolusi ASLI data (union extent, piksel terhalus).

    Sama seperti tampilan unduhan CAMS — tanpa interpolasi ke 100 m,
    jauh lebih ringan. Mengembalikan (geotransform, width, height).
    """
    import math

    xmin, ymin, xmax, ymax = bounds
    dx = min(abs(gt[1]) for gt in gts)
    dy = min(abs(gt[5]) for gt in gts)
    if not (dx > 0 and dy > 0):
        raise RuntimeError("Resolusi raster sumber tidak valid.")
    width = max(1, int(math.ceil((xmax - xmin) / dx - 1e-9)))
    height = max(1, int(math.ceil((ymax - ymin) / dy - 1e-9)))
    return (xmin, dx, 0.0, ymax, 0.0, -dy), width, height


def plan_analysis_grid(bounds, center_lat, res_m=RES_M,
                       budget=MAX_GRID_CELLS):
    """Rencanakan grid mode 100 m dengan penjaga RAM.

    Bila jumlah piksel melebihi budget, resolusi otomatis diperbesar
    (bukan error) agar analisis tetap berjalan. Mengembalikan
    (geotransform, width, height, res_m_terpakai, catatan|None).
    """
    import math

    gt, width, height = _reference_grid_100m(bounds, center_lat, res_m=res_m)
    if width * height <= budget:
        return gt, width, height, res_m, None
    factor = math.sqrt((width * height) / float(budget))
    res_m = math.ceil(res_m * factor / 10.0) * 10.0
    while True:
        gt, width, height = _reference_grid_100m(bounds, center_lat,
                                                 res_m=res_m)
        if width * height <= budget:
            break
        res_m = math.ceil(res_m * 1.1 / 10.0) * 10.0
    note = (f"area terlalu luas untuk 100 m pada RAM yang tersedia -> "
            f"resolusi otomatis diperbesar ke {res_m:g} m/piksel "
            f"({width}x{height} piksel)")
    return gt, width, height, res_m, note


def _resample_to_grid(arr, src_gt, src_proj, ref_gt, ref_w, ref_h):
    """Interpolasi bilinear array ke grid referensi (via GDAL MEM)."""
    from osgeo import gdal

    h, w = arr.shape
    src = gdal.GetDriverByName("MEM").Create("", w, h, 1, gdal.GDT_Float32)
    src.SetGeoTransform(src_gt)
    if src_proj:
        src.SetProjection(src_proj)
    band = src.GetRasterBand(1)
    out = np.array(arr, dtype=np.float32)
    out[~np.isfinite(out)] = NODATA
    band.WriteArray(out)
    band.SetNoDataValue(NODATA)

    xmin, ymax = ref_gt[0], ref_gt[3]
    xmax = xmin + ref_gt[1] * ref_w
    ymin = ymax + ref_gt[5] * ref_h
    dst = gdal.Warp("", src, format="MEM",
                    outputBounds=(xmin, ymin, xmax, ymax),
                    width=ref_w, height=ref_h, resampleAlg="bilinear")
    res = dst.GetRasterBand(1).ReadAsArray().astype(np.float64)
    res[res == NODATA] = np.nan
    return res


# ---------------------------------------------------------------------------
# Analisis utama
# ---------------------------------------------------------------------------
def run_analysis(param_specs, admin_layer=None, pop_path=None,
                 output_dir=None, time_start=None, time_end=None,
                 resample_100m=False, progress_callback=None):
    """Jalankan analisis ISPU.

    param_specs : list dict {key, path, unit} - key pm10/pm25/so2/co/o3/no2/hc.
    time_start/
    time_end    : datetime - rentang waktu VALID band yang dipakai. Semua
                  langkah waktu dalam rentang dibaca otomatis dari metadata
                  band lalu dirata-rata (ISPU = rata-rata 24 jam; data CAMS
                  3-jam -> 9 langkah waktu 00,03,...,24). None = semua band.
    resample_100m : False (bawaan) -> analisis langsung pada resolusi ASLI
                  data (seperti tampilan unduhan CAMS, tanpa interpolasi,
                  jauh lebih ringan). True -> interpolasi ke 100 m/piksel;
                  bila area terlalu luas untuk RAM, resolusi otomatis
                  diperbesar (lihat catatan hasil).
    return      : dict {"rasters": {...}, "admin": path|None, "stats": {...}}
    """
    import time

    def progress(pct, msg):
        if progress_callback:
            progress_callback(int(pct), str(msg))

    if not param_specs:
        raise RuntimeError("Tidak ada parameter udara yang dipilih.")
    if not output_dir:
        raise RuntimeError("Folder output belum dipilih.")

    os.makedirs(output_dir, exist_ok=True)
    t0 = time.time()

    # ---- 1. rata-rata band pada rentang waktu untuk tiap parameter
    source = {}
    for spec in param_specs:
        key = spec["key"]
        label = PARAM_LABELS.get(key, key)
        progress(2, f"Membaca {label}...")
        bands, times, parsed = select_time_bands(spec["path"], time_start,
                                                 time_end)
        if not bands:
            raise RuntimeError(
                f"{label}: tidak ada langkah waktu dalam rentang "
                f"{time_start} s/d {time_end}")
        avg, gt, proj = _average_bands(spec["path"], bands)
        factor = unit_factor(key, spec.get("unit", "µg/m3"))
        source[key] = {
            "conc": avg * factor, "gt": gt, "proj": proj,
            "bands": len(bands), "parsed": parsed, "label": label,
        }
        if parsed:
            progress(6, f"{label}: {len(bands)} langkah waktu dirata-rata")
        else:
            progress(6, f"{label}: metadata waktu tidak ada -> semua band "
                        f"({len(bands)}) dirata-rata")

    # ---- 2. grid referensi 100 m (cakupan parameter, dipotong extent admin)
    bounds_list = []
    for s in source.values():
        h, w = s["conc"].shape
        gt = s["gt"]
        xmin, ymax = gt[0], gt[3]
        bounds_list.append((xmin, ymax + gt[5] * h, xmin + gt[1] * w, ymax))
    xmin = min(b[0] for b in bounds_list)
    ymin = min(b[1] for b in bounds_list)
    xmax = max(b[2] for b in bounds_list)
    ymax = max(b[3] for b in bounds_list)

    if admin_layer is not None:
        try:
            from qgis.core import (
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsProject,
            )

            ext = admin_layer.extent()
            crs = admin_layer.crs()
            if crs.isValid() and crs.authid().upper() != "EPSG:4326":
                xf = QgsCoordinateTransform(
                    crs, QgsCoordinateReferenceSystem("EPSG:4326"),
                    QgsProject.instance())
                ext = xf.transformBoundingBox(ext)
            ixmin, ixmax = max(xmin, ext.xMinimum()), min(xmax, ext.xMaximum())
            iymin, iymax = max(ymin, ext.yMinimum()), min(ymax, ext.yMaximum())
            if ixmax > ixmin and iymax > iymin:
                xmin, ymin, xmax, ymax = ixmin, iymin, ixmax, iymax
        except Exception:
            pass

    center_lat = (ymin + ymax) / 2.0
    res_note = None
    if resample_100m:
        ref_gt, width, height, res_m, res_note = plan_analysis_grid(
            (xmin, ymin, xmax, ymax), center_lat, budget=MAX_GRID_CELLS)
        res_label = f"{res_m:g} m"
    else:
        ref_gt, width, height = _native_reference_grid(
            (xmin, ymin, xmax, ymax), [s["gt"] for s in source.values()])
        res_label = f"{abs(ref_gt[5]) * 110574.0:.0f} m (resolusi asli)"
    ref_proj = list(source.values())[0]["proj"] or ""
    if res_note:
        progress(11, f"Catatan: {res_note}")
    progress(12, f"Grid analisis {res_label}: {width}x{height} piksel")

    # ---- 3. hitung ISPU tiap parameter pada grid analisis
    param_grid = {}
    overall = np.full((height, width), np.nan, dtype=np.float32)
    for spec in param_specs:
        key = spec["key"]
        s = source[key]
        progress(15, f"ISPU {s['label']}...")
        if np.allclose(s["gt"], ref_gt) and s["conc"].shape == (height, width):
            conc = s["conc"]          # grid sudah sama -> tanpa interpolasi
        else:
            conc = _resample_to_grid(s["conc"], s["gt"], s["proj"],
                                     ref_gt, width, height)
        ispu = compute_ispu(conc, key).astype(np.float32)
        param_grid[key] = {"conc": np.asarray(conc, dtype=np.float32),
                           "ispu": ispu}
        np.fmax(overall, ispu, out=overall)

        out = os.path.join(output_dir, f"ispu_{key}.tif")
        _write_tif(out, ispu, ref_gt, ref_proj)
        spec["out"] = out
        spec["bands_used"] = s["bands"]
        progress(45, f"ISPU {s['label']}: {np.nanmin(ispu):.0f} - "
                     f"{np.nanmax(ispu):.0f}")

    progress(50, "Menghitung ISPU gabungan (nilai tertinggi)...")
    overall[~np.isfinite(overall)] = np.nan

    kelas = classify_ispu(overall)
    ispu_path = os.path.join(output_dir, "ispu.tif")
    _write_tif(ispu_path, overall, ref_gt, ref_proj)

    results = {
        "rasters": {
            "ispu": ispu_path,
            **{s["key"]: s["out"] for s in param_specs},
        },
        "grid": {"geotransform": ref_gt, "proj": ref_proj,
                 "width": width, "height": height,
                 "bounds": (xmin, ymin, xmax, ymax)},
        "resolution_note": res_note,
        "overall": overall,
        "kelas": kelas,
        "admin": None,
        "stats": {},
    }

    # ---- 4. zonal penduduk per wilayah administrasi
    if admin_layer is not None and pop_path:
        progress(55, "Menghitung penduduk terdampak per wilayah administrasi...")
        admin_path = os.path.join(output_dir, "admin_ispu_penduduk.gpkg")
        stats = zonal_population(admin_layer, pop_path, overall, kelas,
                                 ref_gt, ref_proj, admin_path,
                                 param_grid=param_grid,
                                 progress_callback=lambda p, m: progress(
                                     55 + p * 0.43, m))
        results["admin"] = admin_path
        results["stats"] = stats

    progress(100, f"Analisis selesai ({time.time() - t0:.1f} detik)")
    return results


# ---------------------------------------------------------------------------
# Raster Hidrokarbon (HO): gabungan spesies hidrokarbon -> konsentrasi µg/m3
# ---------------------------------------------------------------------------
# key spesies -> (label, massa molar g/mol). Massa molar dipakai untuk
# konversi ppbv -> µg/m3 (gas ideal 25 C, 1 atm: 1 mol = 24.45 L).
HYDROCARBON_SPECIES = {
    "c2h6": {"label": "Ethane (C2H6)", "molar_mass": 30.07},
    "c2h4": {"label": "Ethene (C2H4)", "molar_mass": 28.05},
    "c2h5oh": {"label": "Ethanol (C2H5OH)", "molar_mass": 46.07},
    "c3h8": {"label": "Propane (C3H8)", "molar_mass": 44.095},
    "c3h6": {"label": "Propene (C3H6)", "molar_mass": 42.08},
    "c5h8": {"label": "Isoprene (C5H8)", "molar_mass": 68.117},
    "acetone": {"label": "Acetone (C3H6O)", "molar_mass": 58.08},
}

# Kunci parameter CAMS permukaan per spesies (lihat params.py)
HYDROCARBON_SURFACE_KEYS = {f"{sp}_surface": sp for sp in HYDROCARBON_SPECIES}


def species_to_ugm3(values, unit, molar_mass):
    """Nilai raster spesies hidrokarbon -> konsentrasi massa (µg/m3).

    Satuan yang didukung: µg/m3, mg/m3, kg/kg, ppm, ppb (dan variasi
    ejaannya). Satuan kolom (molekul/cm2, DU) tidak dapat dikonversi
    menjadi konsentrasi permukaan -> ValueError.
    """
    u = str(unit or "µg/m3").lower().replace("\u00b5", "u").replace("\u03bc", "u")
    u = "".join(ch for ch in u if ch.isalnum())
    arr = np.asarray(values, dtype=np.float64)
    if u in ("ugm3", "ug", "ug"):
        return arr
    if u == "mgm3":
        return arr * 1000.0
    if u in ("kgkg", "kgkg1"):
        return arr * 1e9
    if u in ("ppm", "ppmv"):
        return arr * float(molar_mass) / 24.45 * 1000.0
    if u in ("ppb", "ppbv"):
        return arr * float(molar_mass) / 24.45
    raise ValueError(
        f"Satuan '{unit}' tidak dapat dikonversi ke µg/m3. Gunakan raster "
        f"spesies hidrokarbon level permukaan (satuan ppbv), bukan total "
        f"kolom.")


def build_hydrocarbon_raster(species_specs, output_dir,
                             time_start=None, time_end=None,
                             progress_callback=None):
    """Bangun raster gabungan Hidrokarbon (HO) dari raster spesies hidrokarbon.

    species_specs : list dict {species, path, unit}
                    - species : kunci HYDROCARBON_SPECIES
                                (c2h6, c2h4, c2h5oh, c3h8, c3h6, c5h8, acetone)
                    - unit    : satuan raster sumber (ppbv, µg/m3, mg/m3,
                                kg/kg, ppm)
    time_start/
    time_end    : rentang waktu VALID band (rata-rata 24 jam seperti ISPU);
                  None = semua band dirata-rata.
    Setiap spesies dikonversi ke µg/m3, diinterpolasi (bilinear) ke grid
    bersama beresolusi asli (mengikuti resolusi data sumber CAMS, bukan
    100 m/piksel seperti tab Analisis), lalu dijumlahkan menjadi total
    hidrokarbon. Output berupa raster konsentrasi saja TANPA klasifikasi
    ISPU — untuk hitungan ISPU pilih raster ini sebagai parameter
    Hidrokarbon (HO) pada tab Analisis.

    return      : dict {"file", "species_used", "min", "max",
                        "bands_used", "grid"}
                  - file : hidrokarbon_ho.tif (µg/m3)
    """
    import time as _time

    def progress(pct, msg):
        if progress_callback:
            progress_callback(int(pct), str(msg))

    if not species_specs:
        raise RuntimeError("Tidak ada spesies hidrokarbon yang dipilih.")
    if not output_dir:
        raise RuntimeError("Folder output belum dipilih.")
    os.makedirs(output_dir, exist_ok=True)
    t0 = _time.time()

    # ---- 1. rata-rata waktu + konversi ke µg/m3 per spesies
    source = []
    for spec in species_specs:
        sp = spec.get("species")
        info = HYDROCARBON_SPECIES.get(sp)
        if info is None:
            raise RuntimeError(f"Spesies hidrokarbon tidak dikenal: {sp}")
        label = info["label"]
        progress(2, f"Membaca {label}...")
        bands, times, parsed = select_time_bands(spec["path"], time_start,
                                                 time_end)
        if not bands:
            raise RuntimeError(
                f"{label}: tidak ada langkah waktu dalam rentang "
                f"{time_start} s/d {time_end}")
        avg, gt, proj = _average_bands(spec["path"], bands)
        conc = species_to_ugm3(avg, spec.get("unit", "ppbv"),
                               info["molar_mass"])
        source.append({"conc": conc, "gt": gt, "proj": proj,
                       "label": label, "bands": len(bands)})
        progress(10, f"{label}: {len(bands)} langkah waktu dirata-rata "
                     f"-> µg/m3")

    # ---- 2. grid bersama resolusi ASLI data (union extent semua spesies)
    bounds_list = []
    for s in source:
        h, w = s["conc"].shape
        gt = s["gt"]
        xmin, ymax = gt[0], gt[3]
        bounds_list.append((xmin, ymax + gt[5] * h, xmin + gt[1] * w, ymax))
    xmin = min(b[0] for b in bounds_list)
    ymin = min(b[1] for b in bounds_list)
    xmax = max(b[2] for b in bounds_list)
    ymax = max(b[3] for b in bounds_list)

    # resolusi piksel mengikuti data sumber (resolusi asli CAMS),
    # bukan 100 m/piksel seperti mode interpolasi tab Analisis
    ref_gt, width, height = _native_reference_grid(
        (xmin, ymin, xmax, ymax), [s["gt"] for s in source])
    ref_proj = source[0]["proj"] or ""
    progress(25, f"Grid resolusi asli: {width}x{height} piksel")

    # ---- 3. interpolasi tiap spesies ke grid bersama + jumlahkan
    total = np.zeros((height, width), dtype=np.float64)
    valid_count = np.zeros((height, width), dtype=np.int32)
    for i, s in enumerate(source):
        progress(35 + i * 10, f"Interpolasi {s['label']}...")
        conc = _resample_to_grid(s["conc"], s["gt"], s["proj"],
                                 ref_gt, width, height)
        mask = np.isfinite(conc)
        total[mask] += conc[mask]
        valid_count[mask] += 1
    total[valid_count == 0] = np.nan

    progress(85, "Menulis raster Hidrokarbon (HO)...")
    ho_path = os.path.join(output_dir, "hidrokarbon_ho.tif")
    _write_tif(ho_path, total, ref_gt, ref_proj)

    finite = total[np.isfinite(total)]
    stats = {
        "file": ho_path,
        "species_used": [s["label"] for s in source],
        "bands_used": {s["label"]: s["bands"] for s in source},
        "min": float(finite.min()) if finite.size else None,
        "max": float(finite.max()) if finite.size else None,
        "grid": {"geotransform": ref_gt, "proj": ref_proj,
                 "width": width, "height": height,
                 "bounds": (xmin, ymin, xmax, ymax)},
    }
    try:
        from .symbology import write_qml

        write_qml(ho_path, "ho", stats["min"], stats["max"])
    except Exception:
        pass
    progress(100, f"Raster Hidrokarbon (HO) selesai "
                  f"({_time.time() - t0:.1f} detik)")
    return stats


# ---------------------------------------------------------------------------
# Zonal: penduduk & ISPU per fitur administrasi
# ---------------------------------------------------------------------------
# Field atribut per parameter pada output zonal:
#   v_<SUF>   : rentang nilai (MIN - MAX) konsentrasi dalam µg/m3
#   kls_<SUF> : kategori kelas ISPU (Baik..Berbahaya) dari nilai ISPU tertinggi
#   m_<SUF>   : nilai majority (modus nilai ISPU, 2 desimal)
PARAM_FIELDS = (
    ("pm10", "PM10", "PM10", "PM10"),
    ("pm25", "PM25", "PM25", "PM25"),
    ("co", "CO", "CO", "CO"),
    ("no2", "NO2", "NO2", "NO2"),
    ("so2", "SO2", "SO2", "SO2"),
    ("o3", "O3", "O3", "O3"),
    ("hc", "HC", "HC", "HC"),
)


def ispu_zone_fields(ispu, mask):
    """Statistik ISPU gabungan untuk satu zona (poligon administrasi).

    return : {"value_range": "MIN - MAX" | None,       -> field v_ISPU
              "majority": modus nilai ISPU (2 desimal), -> field m_ISPU
              "kelas": kategori dari nilai m_ISPU}      -> field kls_ISPU
    """
    out = {"value_range": None, "majority": None, "kelas": None}
    mask = np.asarray(mask, dtype=bool)
    sel = mask & np.isfinite(ispu)
    if not sel.any():
        return out
    vals = np.asarray(ispu)[sel]
    out["value_range"] = f"{float(vals.min()):.4g} - {float(vals.max()):.4g}"
    rounded = np.round(vals, 2)
    uniq, counts = np.unique(rounded, return_counts=True)
    m = float(uniq[int(np.argmax(counts))])
    out["majority"] = m
    kat = int(np.clip(np.digitize(m, [0, 51, 101, 201, 301]), 1, 5))
    out["kelas"] = CATEGORIES[kat - 1][0]
    return out


def param_zone_fields(conc, ispu, mask):
    """Hitung field per parameter untuk satu zona (poligon administrasi).

    conc, ispu : array hasil sampling pada jaringan analisis (nilai per sel).
    mask       : boolean array sel yang berada di dalam poligon.

    return : {"value_range": "MIN - MAX" (µg/m3) | None,
              "kelas": nama kategori ISPU | None,
              "majority": modus nilai ISPU (2 desimal) | None}
    """
    out = {"value_range": None, "kelas": None, "majority": None}
    mask = np.asarray(mask, dtype=bool)

    sel_c = mask & np.isfinite(conc)
    if sel_c.any():
        vals = np.asarray(conc)[sel_c]
        out["value_range"] = f"{float(vals.min()):.4g} - {float(vals.max()):.4g}"

    sel_i = mask & np.isfinite(ispu)
    if sel_i.any():
        isel = np.asarray(ispu)[sel_i]
        ispu_max = float(np.max(isel))
        kat = int(np.clip(np.digitize(ispu_max, [0, 51, 101, 201, 301]), 1, 5))
        out["kelas"] = CATEGORIES[kat - 1][0]
        rounded = np.round(isel, 2)
        uniq, counts = np.unique(rounded, return_counts=True)
        out["majority"] = float(uniq[int(np.argmax(counts))])
    return out


def zonal_population(admin_layer, pop_path, overall_ispu, kelas_arr,
                     ref_gt, ref_proj, out_path, param_grid=None,
                     progress_callback=None):
    from osgeo import gdal, ogr, osr

    def progress(pct, msg):
        if progress_callback:
            progress_callback(int(pct), str(msg))

    pop_ds = _open_raster(pop_path)
    pop_band = pop_ds.GetRasterBand(1)
    pop_nodata = pop_band.GetNoDataValue()
    pop_gt = pop_ds.GetGeoTransform()
    pop_w, pop_h = pop_ds.RasterXSize, pop_ds.RasterYSize

    def _make_srs(wkt):
        srs = osr.SpatialReference()
        if wkt:
            srs.ImportFromWkt(wkt)
            try:
                srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
            except AttributeError:
                pass
        return srs

    pop_srs = _make_srs(pop_ds.GetProjection())
    class_srs = _make_srs(ref_proj)
    admin_wkt = admin_layer.crs().toWkt() if admin_layer.crs().isValid() else ""
    admin_srs = _make_srs(admin_wkt)

    # transformasi geometri: CRS layer admin -> CRS raster penduduk
    to_pop = None
    if pop_ds.GetProjection() and admin_wkt and not admin_srs.IsSame(pop_srs):
        to_pop = osr.CoordinateTransformation(admin_srs, pop_srs)
    # transformasi koordinat sel: CRS penduduk -> CRS grid analisis
    to_class = None
    if pop_ds.GetProjection() and ref_proj and not pop_srs.IsSame(class_srs):
        to_class = osr.CoordinateTransformation(pop_srs, class_srs)

    class_h, class_w = kelas_arr.shape

    def sample_grid(arr, xs, ys):
        """Sampling nearest satu array jaringan analisis (NaN di luar grid)."""
        xs = np.asarray(xs, dtype=np.float64)
        ys = np.asarray(ys, dtype=np.float64)
        with np.errstate(invalid="ignore"):
            cols = np.where(np.isfinite(xs),
                            np.floor((xs - ref_gt[0]) / ref_gt[1]),
                            -1).astype(np.int64)
            rows = np.where(np.isfinite(ys),
                            np.floor((ys - ref_gt[3]) / ref_gt[5]),
                            -1).astype(np.int64)
        ok = (cols >= 0) & (cols < class_w) & (rows >= 0) & (rows < class_h)
        out = np.full(xs.shape, np.nan)
        out[ok] = arr[rows[ok], cols[ok]]
        return out

    def sample_class_ispu(xs, ys):
        """Sampling nearest kelas & ISPU pada koordinat (grid CRS)."""
        xs = np.asarray(xs, dtype=np.float64)
        ys = np.asarray(ys, dtype=np.float64)
        with np.errstate(invalid="ignore"):
            cols = np.where(np.isfinite(xs),
                            np.floor((xs - ref_gt[0]) / ref_gt[1]),
                            -1).astype(np.int64)
            rows = np.where(np.isfinite(ys),
                            np.floor((ys - ref_gt[3]) / ref_gt[5]),
                            -1).astype(np.int64)
        valid = (cols >= 0) & (cols < class_w) & (rows >= 0) & (rows < class_h)
        k = np.zeros(xs.shape, dtype=np.uint8)
        v = np.full(xs.shape, np.nan)
        k[valid] = kelas_arr[rows[valid], cols[valid]]
        v[valid] = overall_ispu[rows[valid], cols[valid]]
        return k, v

    fields_def = detect_admin_fields(admin_layer)
    names = [v for v in fields_def.values() if v]

    # buat output GPKG
    if os.path.exists(out_path):
        ogr.GetDriverByName("GPKG").DeleteDataSource(out_path)
    drv = ogr.GetDriverByName("GPKG")
    out_ds = drv.CreateDataSource(out_path)
    out_srs = osr.SpatialReference()
    wkt = admin_layer.crs().toWkt() if admin_layer.crs().isValid() else ""
    if wkt:
        out_srs.ImportFromWkt(wkt)
    out_lyr = out_ds.CreateLayer("admin_ispu", srs=out_srs,
                                 geom_type=ogr.wkbMultiPolygon)

    def add_field(name, ftype, width=0):
        fd = ogr.FieldDefn(name, ftype)
        if width:
            fd.SetWidth(width)
        out_lyr.CreateField(fd)

    for key in ("desa", "kecamatan", "kabupaten", "provinsi"):
        add_field(key, ogr.OFTString, 80)
    add_field("kategori", ogr.OFTInteger)
    add_field("kategori_nm", ogr.OFTString, 32)
    add_field("ispu_max", ogr.OFTReal)
    add_field("ispu_mean", ogr.OFTReal)
    add_field("v_ISPU", ogr.OFTString, 32)
    add_field("kls_ISPU", ogr.OFTString, 32)
    add_field("m_ISPU", ogr.OFTReal)
    # statistik per parameter: rentang nilai (µg/m3), kelas ISPU, modus ISPU
    for _key, v_suf, kls_suf, m_suf in PARAM_FIELDS:
        add_field(f"v_{v_suf}", ogr.OFTString, 32)
        add_field(f"kls_{kls_suf}", ogr.OFTString, 32)
        add_field(f"m_{m_suf}", ogr.OFTReal)
    for name, _, kode, _, _ in CATEGORIES:
        add_field(f"pop_{_slug(name)}", ogr.OFTInteger64)
    add_field("pop_terdampak", ogr.OFTInteger64)
    add_field("pop_total", ogr.OFTInteger64)

    defn = out_lyr.GetLayerDefn()
    n_feat = admin_layer.featureCount()
    processed = 0
    summary = {"pop_terdampak": 0.0, "pop_total": 0.0,
               "fitur": n_feat, "terdampak": 0,
               "fitur_per_kategori": {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}}

    for feat in admin_layer.getFeatures():
        if progress_callback and n_feat:
            if processed % 20 == 0:
                progress(processed / max(n_feat, 1) * 100,
                         f"Zonal {processed + 1}/{n_feat}...")
        processed += 1

        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        geom_ogr = ogr.CreateGeometryFromWkb(bytes(geom.asWkb()))
        if geom_ogr is None:
            continue
        if to_pop is not None:
            try:
                geom_ogr.Transform(to_pop)
            except Exception:
                continue
        env = geom_ogr.GetEnvelope()  # (xmin, xmax, ymin, ymax) CRS penduduk

        # window pada raster penduduk
        px = pop_gt[1]
        py = pop_gt[5]
        x0 = int(np.floor((env[0] - pop_gt[0]) / px))
        x1 = int(np.ceil((env[1] - pop_gt[0]) / px))
        y0 = int(np.floor((env[3] - pop_gt[3]) / py))
        y1 = int(np.ceil((env[2] - pop_gt[3]) / py))
        x0c, y0c = max(x0, 0), max(y0, 0)
        x1c, y1c = min(x1, pop_w), min(y1, pop_h)
        if x1c <= x0c or y1c <= y0c:
            continue
        wwin, hwin = x1c - x0c, y1c - y0c

        pop = pop_band.ReadAsArray(x0c, y0c, wwin, hwin).astype(np.float64)
        if pop_nodata is not None:
            pop[pop == pop_nodata] = np.nan
        pop[~np.isfinite(pop)] = np.nan
        pop[pop < 0] = np.nan

        # rasterisasi geometri fitur pada window
        mask_ds = gdal.GetDriverByName("MEM").Create("", wwin, hwin, 1,
                                                     gdal.GDT_Byte)
        wgt = (pop_gt[0] + x0c * px, px, 0.0, pop_gt[3] + y0c * py, 0.0, py)
        mask_ds.SetGeoTransform(wgt)
        if pop_ds.GetProjection():
            mask_ds.SetProjection(pop_ds.GetProjection())
        mem_drv = ogr.GetDriverByName("Memory")
        mem_ds = mem_drv.CreateDataSource("mem") if mem_drv else None
        if mem_ds is None:
            raise RuntimeError("Gagal membuat layer memori OGR untuk rasterisasi")
        mem_lyr = mem_ds.CreateLayer("f", srs=pop_srs, geom_type=ogr.wkbUnknown)
        f2 = ogr.Feature(mem_lyr.GetLayerDefn())
        f2.SetGeometry(geom_ogr)
        mem_lyr.CreateFeature(f2)
        gdal.RasterizeLayer(mask_ds, [1], mem_lyr, burn_values=[1])
        inside = mask_ds.GetRasterBand(1).ReadAsArray() == 1
        mask_ds = None
        mem_ds = None

        valid = inside & np.isfinite(pop)
        if not valid.any():
            continue

        # koordinat sel (CRS penduduk) -> grid analisis (nearest)
        xs1d = pop_gt[0] + (x0c + np.arange(wwin) + 0.5) * px
        ys1d = pop_gt[3] + (y0c + np.arange(hwin) + 0.5) * py
        XX, YY = np.meshgrid(xs1d, ys1d)
        if to_class is not None:
            flat_x = XX.ravel()
            flat_y = YY.ravel()
            out_x = np.empty(flat_x.shape, dtype=np.float64)
            out_y = np.empty(flat_y.shape, dtype=np.float64)
            chunk = 20000
            for s0 in range(0, flat_x.size, chunk):
                pts = list(zip(flat_x[s0:s0 + chunk].tolist(),
                               flat_y[s0:s0 + chunk].tolist()))
                try:
                    res = to_class.TransformPoints(pts)
                    arrp = np.asarray([(p[0], p[1]) for p in res],
                                      dtype=np.float64)
                except Exception:
                    arrp = np.asarray(pts, dtype=np.float64)
                out_x[s0:s0 + chunk] = arrp[:, 0]
                out_y[s0:s0 + chunk] = arrp[:, 1]
            XX = out_x.reshape(XX.shape)
            YY = out_y.reshape(YY.shape)
        k, v = sample_class_ispu(XX, YY)

        ksel = k[valid]
        vsel = v[valid]
        popsel = pop[valid]

        out_feat = ogr.Feature(defn)
        for i, key in enumerate(("desa", "kecamatan", "kabupaten", "provinsi")):
            src = fields_def[key]
            if src:
                out_feat.SetField(key, str(feat[src] or ""))
        ok = vsel[np.isfinite(vsel)]
        ispu_max = float(np.max(ok)) if ok.size else None
        ispu_mean = float(np.mean(ok)) if ok.size else None
        if ispu_max is None:
            continue
        kat = int(np.clip(np.digitize(ispu_max, [0, 51, 101, 201, 301]), 1, 5))
        out_feat.SetField("kategori", kat)
        out_feat.SetField("kategori_nm", CATEGORIES[kat - 1][0])
        out_feat.SetField("ispu_max", ispu_max)
        out_feat.SetField("ispu_mean", ispu_mean)

        # ISPU gabungan: v_ISPU (rentang), m_ISPU (modus),
        # kls_ISPU (kelas dari nilai m_ISPU / majority)
        zispu = ispu_zone_fields(v, inside)
        if zispu["value_range"]:
            out_feat.SetField("v_ISPU", zispu["value_range"])
        if zispu["kelas"]:
            out_feat.SetField("kls_ISPU", zispu["kelas"])
        if zispu["majority"] is not None:
            out_feat.SetField("m_ISPU", zispu["majority"])

        # statistik per parameter: v_ (rentang µg/m3), kls_ (kelas ISPU),
        # m_ (modus nilai ISPU) — dihitung untuk semua sel di dalam poligon
        for key, v_suf, kls_suf, m_suf in PARAM_FIELDS:
            arrays = (param_grid or {}).get(key)
            if arrays is None:
                continue
            pfields = param_zone_fields(
                sample_grid(arrays["conc"], XX, YY),
                sample_grid(arrays["ispu"], XX, YY),
                inside)
            if pfields["value_range"]:
                out_feat.SetField(f"v_{v_suf}", pfields["value_range"])
            if pfields["kelas"]:
                out_feat.SetField(f"kls_{kls_suf}", pfields["kelas"])
            if pfields["majority"] is not None:
                out_feat.SetField(f"m_{m_suf}", pfields["majority"])

        total = 0.0
        terdampak = 0.0
        for (name, _, kode, _, _), slug in zip(
                CATEGORIES, [_slug(c[0]) for c in CATEGORIES]):
            sel = popsel[ksel == kode]
            val = float(np.nansum(sel)) if sel.size else 0.0
            out_feat.SetField(f"pop_{slug}", int(round(val)))
            total += val
            if kode >= 3:
                terdampak += val
        out_feat.SetField("pop_total", int(round(total)))
        out_feat.SetField("pop_terdampak", int(round(terdampak)))
        out_geom = ogr.CreateGeometryFromWkb(bytes(geom.asWkb()))
        out_feat.SetGeometry(ogr.ForceToMultiPolygon(out_geom))
        out_lyr.CreateFeature(out_feat)

        summary["pop_total"] += total
        summary["pop_terdampak"] += terdampak
        summary["fitur_per_kategori"][kat] = \
            summary["fitur_per_kategori"].get(kat, 0) + 1
        if kat >= 3:
            summary["terdampak"] += 1

    out_ds = None
    progress(100, f"Zonal selesai: {summary['fitur']} wilayah")
    return summary


def _slug(name):
    return (name.lower()
            .replace(" ", "_")
            .replace("sangat_tidak_sehat", "sangat_tidak_sehat"))


# ---------------------------------------------------------------------------
# Pembuatan layer hasil
# ---------------------------------------------------------------------------
def make_result_layers(results, group_name):
    """Tambahkan hasil analisis ke proyek dalam satu layer group."""
    from qgis.core import QgsProject, QgsRasterLayer, QgsVectorLayer

    from . import ispu as ispu_mod

    root = QgsProject.instance().layerTreeRoot()
    group = root.insertGroup(0, group_name)
    count = 0

    def add(layer):
        nonlocal count
        if layer is not None and layer.isValid():
            QgsProject.instance().addMapLayer(layer, False)
            group.addLayer(layer)
            count += 1

    rasters = results.get("rasters", {})

    if rasters.get("ispu"):
        layer = QgsRasterLayer(rasters["ispu"], "ISPU")
        if layer.isValid():
            ispu_mod.style_ispu_raster(layer)
        add(layer)

    for key in ("pm10", "pm25", "co", "no2", "so2", "o3", "hc"):
        if rasters.get(key):
            layer = QgsRasterLayer(rasters[key],
                                   f"{ispu_mod.PARAM_LABELS[key]} (ISPU)")
            if layer.isValid():
                ispu_mod.style_ispu_raster(layer)
            add(layer)

    if results.get("admin"):
        layer = QgsVectorLayer(results["admin"],
                               "Admin | ISPU & Penduduk Terdampak", "ogr")
        if layer.isValid():
            ispu_mod.style_admin_layer(layer)
        add(layer)

    return count
