import os
import sys

_vendor = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor")
if _vendor not in sys.path:
    sys.path.append(_vendor)


def classFactory(iface):
    from .plugin import PantauLangitPlugin

    return PantauLangitPlugin(iface)
