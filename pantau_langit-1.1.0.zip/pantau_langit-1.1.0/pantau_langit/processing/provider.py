import os

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .algorithms.add_satellite import AddSatelliteAlgorithm
from .algorithms.download_cams import DownloadCamsAlgorithm
from .algorithms.download_gfs import DownloadGfsAlgorithm
from .algorithms.download_hotspot import DownloadHotspotAlgorithm


class PantauLangitProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        self.addAlgorithm(DownloadCamsAlgorithm())
        self.addAlgorithm(DownloadHotspotAlgorithm())
        self.addAlgorithm(DownloadGfsAlgorithm())
        self.addAlgorithm(AddSatelliteAlgorithm())

    def id(self):
        return "pantau_langit"

    def name(self):
        return "Pantau Langit Indonesia"

    def longName(self):
        return self.name()

    def icon(self):
        path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.png")
        if os.path.exists(path):
            return QIcon(path)
        return super().icon()
