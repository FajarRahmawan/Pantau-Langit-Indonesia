import os

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingMultiStepFeedback,
    QgsProcessingOutputMultipleLayers,
    QgsProcessingParameterEnum,
    QgsProcessingParameterExtent,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterString,
)
from qgis.PyQt.QtCore import QCoreApplication

from ... import settings as plugin_settings
from ...loader import convert_cams, make_raster_layer
from ...params import CAMS_PARAM_DEFS, cams_param_keys, cams_param_label
from .common import default_dates, extent_to_bbox, register_layer, validate_date


class DownloadCamsAlgorithm(QgsProcessingAlgorithm):
    PARAMS = "PARAMS"
    START_DATE = "START_DATE"
    END_DATE = "END_DATE"
    AREA = "AREA"
    OUTPUT_DIR = "OUTPUT_DIR"
    OUTPUT = "OUTPUT"

    def tr(self, string):
        return QCoreApplication.translate("PantauLangit", string)

    def createInstance(self):
        return DownloadCamsAlgorithm()

    def name(self):
        return "download_cams"

    def displayName(self):
        return self.tr("Download CAMS (Copernicus)")

    def group(self):
        return self.tr("Download")

    def groupId(self):
        return "download"

    def shortHelpString(self):
        return self.tr(
            "Mengunduh parameter atmosfer Copernicus CAMS (NetCDF) untuk area "
            "tertentu, lalu mengonversinya menjadi GeoTIFF multi-band dengan "
            "symbology baku dan menambahkannya ke proyek.\n\n"
            "Membutuhkan CDS API Key pada menu Pantau Langit > Pengaturan API."
        )

    def initAlgorithm(self, config=None):
        options = [cams_param_label(k) for k in cams_param_keys()]
        self.addParameter(
            QgsProcessingParameterEnum(
                self.PARAMS, self.tr("Parameter CAMS"),
                options=options, allowMultiple=True,
            )
        )
        start, end = default_dates()
        self.addParameter(
            QgsProcessingParameterString(
                self.START_DATE, self.tr("Tanggal mulai (YYYY-MM-DD)"),
                defaultValue=start,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.END_DATE, self.tr("Tanggal akhir (YYYY-MM-DD)"),
                defaultValue=end,
            )
        )
        self.addParameter(
            QgsProcessingParameterExtent(
                self.AREA, self.tr("Area (bbox)"), optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_DIR, self.tr("Folder unduhan"),
            )
        )
        self.addOutput(QgsProcessingOutputMultipleLayers(self.OUTPUT, self.tr("Layer CAMS")))

    def processAlgorithm(self, parameters, context, feedback):
        from ...downloaders.cams_downloader import CAMSDownloader

        selected_idx = self.parameterAsEnums(parameters, self.PARAMS, context)
        keys = cams_param_keys()
        selected = [keys[i] for i in selected_idx if i < len(keys)]
        if not selected:
            raise QgsProcessingException("Tidak ada parameter yang dipilih.")

        api_key = plugin_settings.get_cams_api_key()
        if not api_key:
            raise QgsProcessingException(
                "CDS API Key belum dikonfigurasi. Buka menu "
                "Pantau Langit > Pengaturan API.")

        start = validate_date(
            self.parameterAsString(parameters, self.START_DATE, context), "tanggal mulai")
        end = validate_date(
            self.parameterAsString(parameters, self.END_DATE, context), "tanggal akhir")

        bbox = extent_to_bbox(self, parameters, self.AREA, context)
        output_dir = self.parameterAsString(parameters, self.OUTPUT_DIR, context)
        os.makedirs(output_dir, exist_ok=True)

        feedback.pushInfo(f"Parameter: {len(selected)} | Area: {bbox} | {start} -> {end}")

        sub = QgsProcessingMultiStepFeedback(len(selected) * 2, feedback)
        downloader = CAMSDownloader(
            api_key, plugin_settings.get_cams_api_url(), output_dir)

        layer_ids = []
        for i, key in enumerate(selected):
            if feedback.isCanceled():
                break
            label = cams_param_label(key)
            sub.setCurrentStep(i * 2)
            sub.setProgressText(f"Mengunduh {label}...")

            def cb(pct, msg):
                if not feedback.isCanceled():
                    sub.setProgress(int(pct))

            result = downloader.download_parameter(key, start, end, bbox,
                                                   progress_callback=cb,
                                                   log_callback=feedback.pushInfo)
            if "error" in result:
                feedback.reportError(f"{label}: {result['error']}", fatalError=False)
                continue

            sub.setCurrentStep(i * 2 + 1)
            conv = convert_cams(result.get("files") or [result["file"]], key,
                                result["nc_var"], output_dir)
            if "error" in conv:
                feedback.reportError(f"{label}: konversi gagal - {conv['error']}",
                                     fatalError=False)
                continue

            layer = make_raster_layer(conv["file"], label, result["nc_var"],
                                      conv.get("min"), conv.get("max"))
            lid = register_layer(layer, context)
            if lid:
                layer_ids.append(lid)
            feedback.pushInfo(f"OK {label}: {os.path.basename(conv['file'])}")

        return {self.OUTPUT: layer_ids}
