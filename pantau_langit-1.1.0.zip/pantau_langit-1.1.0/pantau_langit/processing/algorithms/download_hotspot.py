import csv
import os

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterEnum,
    QgsProcessingParameterExtent,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QCoreApplication, QVariant

from ... import settings as plugin_settings
from ...params import FIRMS_SOURCES
from .common import default_dates, extent_to_bbox, validate_date


class DownloadHotspotAlgorithm(QgsProcessingAlgorithm):
    SOURCE = "SOURCE"
    DAY_RANGE = "DAY_RANGE"
    USE_DATE = "USE_DATE"
    DATE = "DATE"
    AREA = "AREA"
    OUTPUT_DIR = "OUTPUT_DIR"
    OUTPUT = "OUTPUT"

    def tr(self, string):
        return QCoreApplication.translate("PantauLangit", string)

    def createInstance(self):
        return DownloadHotspotAlgorithm()

    def name(self):
        return "download_hotspot"

    def displayName(self):
        return self.tr("Download Hotspot (NASA FIRMS)")

    def group(self):
        return self.tr("Download")

    def groupId(self):
        return "download"

    def shortHelpString(self):
        return self.tr(
            "Mengunduh titik panas kebakaran (active fire) dari NASA FIRMS "
            "sebagai CSV, lalu menyimpannya sebagai layer titik (GeoPackage).\n\n"
            "Membutuhkan NASA FIRMS MAP_KEY pada menu "
            "Pantau Langit > Pengaturan API."
        )

    def initAlgorithm(self, config=None):
        sources = list(FIRMS_SOURCES.values())
        self.addParameter(
            QgsProcessingParameterEnum(
                self.SOURCE, self.tr("Satelit sumber"),
                options=[s[1] for s in sources], defaultValue=0,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DAY_RANGE, self.tr("Rentang hari (mundur dari sekarang)"),
                QgsProcessingParameterNumber.Integer, defaultValue=1, minValue=1,
                maxValue=5,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_DATE, self.tr("Gunakan tanggal spesifik"), defaultValue=False,
            )
        )
        start, _ = default_dates()
        self.addParameter(
            QgsProcessingParameterString(
                self.DATE, self.tr("Tanggal (YYYY-MM-DD, opsional)"),
                defaultValue=start, optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterExtent(self.AREA, self.tr("Area (bbox)"), optional=True)
        )
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_DIR, self.tr("Folder unduhan CSV"),
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(self.OUTPUT, self.tr("Hotspot"))
        )

    def processAlgorithm(self, parameters, context, feedback):
        from ...downloaders.firms_downloader import FIRMSDownloader

        map_key = plugin_settings.get_firms_map_key()
        if not map_key:
            raise QgsProcessingException(
                "NASA FIRMS MAP_KEY belum dikonfigurasi. Buka menu "
                "Pantau Langit > Pengaturan API.")

        sources = list(FIRMS_SOURCES.values())
        idx = self.parameterAsEnum(parameters, self.SOURCE, context)
        source_id = sources[idx][0] if idx < len(sources) else sources[0][0]

        day_range = self.parameterAsInt(parameters, self.DAY_RANGE, context)
        use_date = self.parameterAsBool(parameters, self.USE_DATE, context)
        date = None
        if use_date:
            raw = self.parameterAsString(parameters, self.DATE, context).strip()
            if raw:
                date = validate_date(raw, "tanggal")

        bbox = extent_to_bbox(self, parameters, self.AREA, context)
        output_dir = self.parameterAsString(parameters, self.OUTPUT_DIR, context)
        os.makedirs(output_dir, exist_ok=True)

        fields = QgsFields()
        for name, typ in (
            ("latitude", QVariant.Double), ("longitude", QVariant.Double),
            ("brightness", QVariant.Double), ("frp", QVariant.Double),
            ("confidence", QVariant.String), ("acq_date", QVariant.String),
            ("acq_time", QVariant.String), ("satellite", QVariant.String),
            ("daynight", QVariant.String),
        ):
            fields.append(QgsField(name, typ))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields,
            QgsWkbTypes.Point,
            QgsCoordinateReferenceSystem("EPSG:4326"),
        )
        if sink is None:
            raise QgsProcessingException("Output sink tidak valid.")

        feedback.pushInfo(f"Area: {bbox} | sumber: {source_id} | hari: {day_range}")

        def cb(pct, msg):
            if not feedback.isCanceled():
                feedback.setProgress(int(pct))
                feedback.setProgressText(msg)

        downloader = FIRMSDownloader(map_key, output_dir)
        result = downloader.download_hotspot(
            area_coords=bbox, day_range=day_range, source=source_id,
            date=date, progress_callback=cb,
        )
        if "error" in result:
            raise QgsProcessingException(result["error"])

        feedback.pushInfo(f"CSV: {result['file']} ({result['count']} titik)")

        # Salin isi CSV ke sink
        with open(result["file"], newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if feedback.isCanceled():
                    break
                try:
                    lat = float(row.get("latitude", 0))
                    lon = float(row.get("longitude", 0))
                except (TypeError, ValueError):
                    continue
                feat = QgsFeature(fields)
                feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
                feat.setAttributes([
                    lat, lon,
                    self._float(row.get("brightness")),
                    self._float(row.get("frp")),
                    str(row.get("confidence", "")),
                    str(row.get("acq_date", "")),
                    str(row.get("acq_time", "")),
                    str(row.get("satellite", "")),
                    str(row.get("daynight", "")),
                ])
                sink.addFeature(feat)

        return {self.OUTPUT: dest_id}

    @staticmethod
    def _float(value):
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0
