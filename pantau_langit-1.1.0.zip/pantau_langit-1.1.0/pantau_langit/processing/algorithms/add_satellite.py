from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingOutputMultipleLayers,
    QgsProcessingParameterEnum,
    QgsProcessingParameterString,
)
from qgis.PyQt.QtCore import QCoreApplication

from ...loader import make_wmts_layer
from ...params import GIBS_LAYERS, gibs_param_keys
from .common import register_layer


class AddSatelliteAlgorithm(QgsProcessingAlgorithm):
    LAYERS = "LAYERS"
    DATE = "DATE"
    TIME = "TIME"
    OUTPUT = "OUTPUT"

    def tr(self, string):
        return QCoreApplication.translate("PantauLangit", string)

    def createInstance(self):
        return AddSatelliteAlgorithm()

    def name(self):
        return "add_satellite_gibs"

    def displayName(self):
        return self.tr("Tambah Citra Satelit (NASA GIBS)")

    def group(self):
        return self.tr("Download")

    def groupId(self):
        return "download"

    def shortHelpString(self):
        return self.tr(
            "Menambahkan layer citra satelit NASA GIBS (WMTS) ke proyek QGIS: "
            "Himawari AHI, MODIS Terra/Aqua, dan VIIRS Suomi NPP/NOAA-20.\n\n"
            "Layer WMTS membutuhkan koneksi internet untuk menampilkan tile. "
            "Waktu digunakan untuk layer sub-harian Himawari."
        )

    def initAlgorithm(self, config=None):
        keys = gibs_param_keys()
        self.addParameter(
            QgsProcessingParameterEnum(
                self.LAYERS, self.tr("Layer satelit"),
                options=[GIBS_LAYERS[k]["label"] for k in keys],
                allowMultiple=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.DATE, self.tr("Tanggal citra (YYYY-MM-DD)"),
                defaultValue="2026-01-01",
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.TIME, self.tr("Waktu Himawari (HH:MM)"),
                defaultValue="00:00", optional=True,
            )
        )
        self.addOutput(
            QgsProcessingOutputMultipleLayers(self.OUTPUT, self.tr("Layer satelit"))
        )

    def processAlgorithm(self, parameters, context, feedback):
        keys = gibs_param_keys()
        selected_idx = self.parameterAsEnums(parameters, self.LAYERS, context)
        selected = [keys[i] for i in selected_idx if i < len(keys)]
        if not selected:
            raise QgsProcessingException("Tidak ada layer satelit yang dipilih.")

        date = self.parameterAsString(parameters, self.DATE, context).strip()
        if len(date) != 10:
            raise QgsProcessingException(
                f"Format tanggal tidak valid: '{date}' (harus YYYY-MM-DD)")
        time_str = self.parameterAsString(parameters, self.TIME, context).strip() or "00:00"

        layer_ids = []
        for key in selected:
            if feedback.isCanceled():
                break
            label = GIBS_LAYERS[key]["label"]
            feedback.setProgressText(f"Menambahkan {label}...")
            layer = make_wmts_layer(key, date, time_str)
            if layer is None:
                feedback.reportError(f"Gagal memuat layer {label}", fatalError=False)
                continue
            lid = register_layer(layer, context)
            if lid:
                layer_ids.append(lid)
            feedback.pushInfo(f"OK {label} ({date})")

        return {self.OUTPUT: layer_ids}
