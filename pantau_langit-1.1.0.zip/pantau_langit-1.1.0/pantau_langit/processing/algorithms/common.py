"""Utilitas bersama untuk algoritma Processing."""

from datetime import datetime, timedelta

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProcessingException,
)

from ...params import INDONESIA_BBOX

DATE_FORMAT = "%Y-%m-%d"


def default_dates():
    end = datetime.now() - timedelta(days=1)
    start = end - timedelta(days=2)
    return start.strftime(DATE_FORMAT), end.strftime(DATE_FORMAT)


def validate_date(value, name):
    try:
        datetime.strptime(value, DATE_FORMAT)
    except ValueError:
        raise QgsProcessingException(
            f"Format {name} tidak valid: '{value}' (harus YYYY-MM-DD)")
    return value


def extent_to_bbox(algorithm, parameters, name, context):
    """Ambil parameter extent -> bbox [W,S,E,N] EPSG:4326 (default Indonesia)."""
    extent = algorithm.parameterAsExtent(parameters, name, context)
    if extent is None or extent.isEmpty():
        return list(INDONESIA_BBOX)

    crs = algorithm.parameterAsExtentCrs(parameters, name, context)
    if crs is not None and crs.isValid() and crs.authid().upper() != "EPSG:4326":
        xform = QgsCoordinateTransform(
            crs,
            QgsCoordinateReferenceSystem("EPSG:4326"),
            context.transformContext(),
        )
        extent = xform.transformBoundingBox(extent)
    return [extent.xMinimum(), extent.yMinimum(),
            extent.xMaximum(), extent.yMaximum()]


def register_layer(layer, context):
    """Simpan layer di temporary store, kembalikan id-nya."""
    if layer is None:
        return None
    store = context.temporaryLayerStore()
    store.addMapLayer(layer)
    return layer.id()
