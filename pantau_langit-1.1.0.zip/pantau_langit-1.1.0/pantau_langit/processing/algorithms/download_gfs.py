import os

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingMultiStepFeedback,
    QgsProcessingOutputMultipleLayers,
    QgsProcessingParameterEnum,
    QgsProcessingParameterExtent,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterString,
)
from qgis.PyQt.QtCore import QCoreApplication

from ...loader import convert_grib, make_raster_layer
from ...params import WEATHER_PARAMS, weather_param_keys
from .common import default_dates, extent_to_bbox, register_layer, validate_date


class DownloadGfsAlgorithm(QgsProcessingAlgorithm):
    PARAMS = "PARAMS"
    START_DATE = "START_DATE"
    END_DATE = "END_DATE"
    AREA = "AREA"
    OUTPUT_DIR = "OUTPUT_DIR"
    OUTPUT = "OUTPUT"

    def tr(self, string):
        return QCoreApplication.translate("PantauLangit", string)

    def createInstance(self):
        return DownloadGfsAlgorithm()

    def name(self):
        return "download_gfs"

    def displayName(self):
        return self.tr("Download Cuaca (NOAA GFS)")

    def group(self):
        return self.tr("Download")

    def groupId(self):
        return "download"

    def shortHelpString(self):
        return self.tr(
            "Mengunduh data cuaca NOAA GFS (GRIB2) melalui server NOMADS: "
            "angin, curah hujan, suhu, tekanan, kelembapan, tutupan awan, dan "
            "gelombang. Tidak membutuhkan API key.\n\n"
            "Hasil dikonversi ke GeoTIFF dan ditambahkan ke proyek."
        )

    def initAlgorithm(self, config=None):
        keys = weather_param_keys()
        self.addParameter(
            QgsProcessingParameterEnum(
                self.PARAMS, self.tr("Parameter cuaca"),
                options=[WEATHER_PARAMS[k]["label"] for k in keys],
                allowMultiple=True,
            )
        )
        start, end = default_dates()
        self.addParameter(
            QgsProcessingParameterString(
                self.START_DATE, self.tr("Tanggal mulai (YYYY-MM-DD)"),
                defaultValue=start,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.END_DATE, self.tr("Tanggal akhir (YYYY-MM-DD)"),
                defaultValue=end,
            )
        )
        self.addParameter(
            QgsProcessingParameterExtent(self.AREA, self.tr("Area (bbox)"), optional=True)
        )
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_DIR, self.tr("Folder unduhan"),
            )
        )
        self.addOutput(
            QgsProcessingOutputMultipleLayers(self.OUTPUT, self.tr("Layer cuaca"))
        )

    def processAlgorithm(self, parameters, context, feedback):
        from ...downloaders.gfs_downloader import GFSDownloader

        keys = weather_param_keys()
        selected_idx = self.parameterAsEnums(parameters, self.PARAMS, context)
        selected = [keys[i] for i in selected_idx if i < len(keys)]
        if not selected:
            raise QgsProcessingException("Tidak ada parameter yang dipilih.")

        start = validate_date(
            self.parameterAsString(parameters, self.START_DATE, context), "tanggal mulai")
        end = validate_date(
            self.parameterAsString(parameters, self.END_DATE, context), "tanggal akhir")

        bbox = extent_to_bbox(self, parameters, self.AREA, context)
        output_dir = self.parameterAsString(parameters, self.OUTPUT_DIR, context)
        os.makedirs(output_dir, exist_ok=True)

        feedback.pushInfo(f"Parameter: {len(selected)} | Area: {bbox} | {start} -> {end}")

        sub = QgsProcessingMultiStepFeedback(len(selected) * 2, feedback)
        downloader = GFSDownloader(output_dir)

        layer_ids = []
        for i, key in enumerate(selected):
            if feedback.isCanceled():
                break
            cfg = WEATHER_PARAMS[key]
            label = cfg["label"]
            sub.setCurrentStep(i * 2)
            sub.setProgressText(f"Mengunduh {label}...")

            def cb(pct, msg):
                if not feedback.isCanceled():
                    sub.setProgress(int(pct))

            result = downloader.download_data(key, start, end, bbox,
                                              progress_callback=cb)
            if "error" in result:
                feedback.reportError(f"{label}: {result['error']}", fatalError=False)
                continue

            sub.setCurrentStep(i * 2 + 1)
            for fpath in result.get("files", []):
                if feedback.isCanceled():
                    break
                conv = convert_grib(fpath, output_dir, cfg.get("sym"))
                if "error" in conv:
                    feedback.reportError(
                        f"{os.path.basename(fpath)}: {conv['error']}", fatalError=False)
                    continue
                layer = make_raster_layer(conv["file"], label, cfg.get("sym"),
                                          conv.get("min"), conv.get("max"))
                lid = register_layer(layer, context)
                if lid:
                    layer_ids.append(lid)
            feedback.pushInfo(f"OK {label}: {len(result.get('files', []))} file")

        return {self.OUTPUT: layer_ids}
